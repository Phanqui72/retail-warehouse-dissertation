"""4 diagram draw.io: Pipeline DAG, Sequence, Error handling flowchart, Data lineage (sinh từ spec)."""
import html, os, sys
import pandas as pd
sys.path.insert(0, "/tmp/claude-0/-home-claude/0dde401e-4337-590a-809c-7c4cee3b276a/scratchpad")
src = open("/tmp/claude-0/-home-claude/0dde401e-4337-590a-809c-7c4cee3b276a/scratchpad/gen_drawio.py", encoding="utf-8").read().split("# ---------------------------------------------------------------- layout")[0]
os.chdir("/tmp/claude-0/-home-claude/0dde401e-4337-590a-809c-7c4cee3b276a/scratchpad")
G_ = {"__file__": os.path.abspath("gen_drawio.py")}
exec(src, G_)
icon_svg, data_uri = G_["icon_svg"], G_["data_uri"]
os.chdir("/tmp/claude-0/-home-claude/0dde401e-4337-590a-809c-7c4cee3b276a/scratchpad/vnb")
import gold_spec as GS

esc = lambda s: html.escape(s, quote=True)
DARK = "#1A1A1A"
C = dict(sensor=("#E8F1FB", "#2F6FB0"), python=("#F3EEFB", "#6B4FBB"), spark=("#FDECEC", "#C0392B"), trino=("#FCE8F6", "#B0087F"),
         branch=("#FFF4CC", "#B7950B"), dq=("#EAF6EF", "#2E7D4F"), fail=("#FDE2E2", "#C00000"), end=("#E8E8E8", "#555555"), note=("#FFFFFF", "#888888"))


class Page:
    def __init__(self, pid, name, w, h):
        self.pid, self.name, self.w, self.h, self.cells, self.n = pid, name, w, h, [], 0

    def nid(self):
        self.n += 1
        return f"{self.pid}-{self.n}"

    def v(self, value, x, y, w, h, style, parent="1"):
        i = self.nid()
        self.cells.append(f'<mxCell id="{i}" value="{esc(value)}" style="{style}" vertex="1" parent="{parent}"><mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
        return i

    def e(self, s, t, label="", style="", pts=None, exit=None, entry=None):
        i = self.nid()
        st = "edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;endArrow=block;endFill=1;fontSize=10;labelBackgroundColor=#FFFFFF;strokeWidth=1.5;" + style
        if exit: st += f"exitX={exit[0]};exitY={exit[1]};exitDx=0;exitDy=0;"
        if entry: st += f"entryX={entry[0]};entryY={entry[1]};entryDx=0;entryDy=0;"
        p = ('<Array as="points">' + "".join(f'<mxPoint x="{a}" y="{b}"/>' for a, b in pts) + "</Array>") if pts else ""
        self.cells.append(f'<mxCell id="{i}" value="{esc(label)}" style="{st}" edge="1" parent="1" source="{s}" target="{t}"><mxGeometry relative="1" as="geometry">{p}</mxGeometry></mxCell>')
        return i

    def line(self, x1, y1, x2, y2, label="", style=""):
        i = self.nid()
        st = "html=1;endArrow=block;endFill=1;fontSize=10;labelBackgroundColor=#FFFFFF;strokeWidth=1.3;" + style
        self.cells.append(f'<mxCell id="{i}" value="{esc(label)}" style="{st}" edge="1" parent="1"><mxGeometry relative="1" as="geometry">'
                          f'<mxPoint x="{x1}" y="{y1}" as="sourcePoint"/><mxPoint x="{x2}" y="{y2}" as="targetPoint"/></mxGeometry></mxCell>')
        return i

    def box(self, text, x, y, w, h, kind, extra=""):
        f, s = C[kind]
        shape = "rhombus;" if kind == "branch" else ("ellipse;" if kind == "end" else "rounded=1;arcSize=12;")
        return self.v(text, x, y, w, h, f"{shape}whiteSpace=wrap;html=1;fillColor={f};strokeColor={s};strokeWidth=1.5;fontSize=11;fontColor={DARK};{extra}")

    def group(self, title, x, y, w, h, stroke="#7F7F7F", fill="#FAFAFA"):
        return self.v(f"<b>{title}</b>", x, y, w, h, f"rounded=1;arcSize=3;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};dashed=1;verticalAlign=top;align=left;spacingLeft=8;spacingTop=4;fontSize=12;fontColor={stroke};")

    def text(self, t, x, y, w, h, size=11, extra=""):
        return self.v(t, x, y, w, h, f"text;html=1;whiteSpace=wrap;strokeColor=none;fillColor=none;align=left;verticalAlign=top;fontSize={size};fontColor={DARK};{extra}")

    def icon(self, key, x, y, s=28):
        return self.v("", x, y, s, s, f"shape=image;html=1;imageAspect=1;aspect=fixed;image={data_uri(icon_svg(key))};")

    def xml(self):
        return (f'<diagram id="{self.pid}" name="{esc(self.name)}"><mxGraphModel dx="1400" dy="900" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" '
                f'page="1" pageScale="1" pageWidth="{self.w}" pageHeight="{self.h}" math="0" shadow="0"><root><mxCell id="0"/><mxCell id="1" parent="0"/>'
                + "".join(self.cells) + "</root></mxGraphModel></diagram>")


def legend(p, x, y):
    p.text("<b>Chú giải loại task</b>", x, y, 200, 20)
    for k, (kind, lab) in enumerate([("sensor", "Sensor (chờ file / DAG khác)"), ("python", "Python task"), ("spark", "Spark job"), ("trino", "Trino SQL"),
                                     ("dq", "Kiểm tra chất lượng"), ("branch", "Rẽ nhánh / cổng"), ("fail", "Xử lý lỗi")]):
        p.box("", x, y + 26 + k * 26, 22, 18, kind if kind != "branch" else "python", "rounded=1;" + (f"fillColor={C['branch'][0]};strokeColor={C['branch'][1]};" if kind == "branch" else ""))
        p.text(lab, x + 30, y + 24 + k * 26, 220, 20, 10)

# =========================================================== 1. PIPELINE DAG
p1 = Page("dag", "1. Pipeline DAG (Airflow)", 2600, 1300)
p1.text("<b style='font-size:20px'>vnb_daily_batch</b> — schedule 0 2 * * * (dt = ngày hôm trước) · catchup · max_active_runs=1 · depends_on_past · SLA 4h · retries 2 (backoff 5m)", 20, 10, 1500, 30, 12)
p1.icon("airflow", 1530, 8, 32)
Y = 70
g = p1.group("sense", 20, Y, 200, 300, C["sensor"][1])
s1 = p1.box("<b>wait_for_success</b><br>S3KeySensor<br>daily/dt={ds}/_SUCCESS<br><i>poke 10m · timeout 6h</i>", 35, Y + 40, 170, 84, "sensor")
s2 = p1.box("<b>wait_master_refresh</b><br>ExternalTaskSensor<br>vnb_master_refresh", 35, Y + 160, 170, 64, "sensor")
g = p1.group("validate_landing", 250, Y, 230, 420, C["python"][1])
cm = p1.box("<b>check_manifest</b><br>file đủ · số dòng · md5 · schema_version · file trùng · file muộn", 265, Y + 40, 200, 80, "python")
br = p1.box("<b>route_on_manifest</b>", 290, Y + 150, 150, 80, "branch")
qb = p1.box("<b>quarantine_batch</b><br>→ landing/_quarantine<br>alert High · FAILED", 265, Y + 290, 200, 64, "fail")
p1.e(s1, cm, "", exit=(1, .5), entry=(0, .5)); p1.e(s2, cm, "", "dashed=1;", exit=(1, .5), entry=(0, .8))
p1.e(cm, br); p1.e(br, qb, "fail", f"strokeColor={C['fail'][1]};")
# bronze
bx = 510
p1.group("bronze — Spark batch", bx, Y, 250, 590, C["spark"][1])
p1.icon("spark", bx + 210, Y + 4, 26)
ids_b = []
for k, ds in enumerate(GS.INCR):
    ids_b.append(p1.box(f"load_bronze_<b>{ds}</b>", bx + 15, Y + 36 + k * 41, 220, 32, "spark", "fontSize=10;"))
p1.e(br, ids_b[0], "ok / degraded", exit=(1, .5), entry=(0, .5))
for i in ids_b[1:]:
    p1.e(br, i, "", "strokeColor=#BBBBBB;strokeWidth=1;", exit=(1, .5), entry=(0, .5))
dqb = p1.box("<b>dq_bronze_counts</b><br>rows = manifest · corrupt < 0,1% · đủ cột", 790, Y + 250, 180, 70, "dq")
for i in ids_b:
    p1.e(i, dqb, "", "strokeColor=#BBBBBB;strokeWidth=1;", exit=(1, .5), entry=(0, .5))
# silver
sx = 1000
gs = p1.group("silver — Spark: ép kiểu · chuẩn hóa · dedup · MERGE · quarantine", sx, Y, 430, 590, C["spark"][1])
so = p1.box("silver_<b>orders</b>", sx + 15, Y + 40, 180, 32, "spark", "fontSize=10;")
child = []
for k, ds in enumerate(["order_items", "order_payments", "order_status_history", "order_reviews"]):
    child.append(p1.box(f"silver_<b>{ds}</b>" + (" (che PII)" if ds == "order_reviews" else ""), sx + 230, Y + 40 + k * 41, 185, 32, "spark", "fontSize=10;"))
    p1.e(so, child[-1], "", "strokeColor=#BBBBBB;strokeWidth=1;", exit=(1, .5), entry=(0, .5))
others = ["customers", "inventory_movements", "inventory_snapshots_daily", "purchase_orders", "stock_counts", "listing_traffic_daily", "ads_spend_daily", "market_prices"]
ids_s = [so]
for k, ds in enumerate(others):
    ids_s.append(p1.box(f"silver_<b>{ds}</b>", sx + 15, Y + 220 + k * 41, 230, 32, "spark", "fontSize=10;"))
for i in ids_s:
    p1.e(dqb, i, "", "strokeColor=#BBBBBB;strokeWidth=1;", exit=(1, .5), entry=(0, .5))
p1.text("<i>Bản ghi lỗi → silver_quarantine.&lt;dataset&gt;<br>kèm issue_id (xem error policy)</i>", sx + 260, Y + 230, 160, 60, 10)
# dq silver + gate
dx = 1460
p1.group("dq_silver", dx, Y, 210, 420, C["dq"][1])
dq1 = p1.box("<b>dq_field_rules</b><br>298 luật cột → ops.dq_results", dx + 15, Y + 40, 180, 56, "dq")
dq2 = p1.box("<b>dq_cross_rules</b><br>XR-01…06, 08…10", dx + 15, Y + 120, 180, 56, "dq")
gate = p1.box("<b>dq_gate</b><br>Critical vượt ngưỡng?", dx + 25, Y + 210, 160, 90, "branch")
stop = p1.box("<b>skip gold + publish</b><br>giữ số liệu ngày trước<br>alert Critical", dx + 15, Y + 330, 180, 70, "fail")
p1.e(gs, dq1, "", exit=(1, .07), entry=(0, .5))
p1.e(gs, dq2, "", exit=(1, .2), entry=(0, .5))
p1.e(dq1, gate, "", exit=(.5, 1), entry=(.5, 0), pts=[(dx + 105, Y + 108)]); p1.e(dq2, gate, "")
p1.e(gate, stop, "có", f"strokeColor={C['fail'][1]};")
# gold
gx = 1700
p1.group("gold — Trino SQL (facts → marts)", gx, Y, 560, 590, C["trino"][1])
p1.icon("trino", gx + 520, Y + 4, 26)
facts = ["fct_order", "fct_order_line", "fct_order_line_component", "fct_order_status_event", "fct_review", "fct_inventory_movement", "fct_inventory_daily",
         "fct_purchase_order_line", "fct_listing_traffic_daily", "fct_ads_daily", "fct_market_price"]
marts = ["mart_sales_daily", "mart_product_attribute_perf", "mart_inventory_health", "mart_channel_funnel", "mart_order_sla", "mart_customer_rfm", "mart_demand_forecast_input"]
fid = {}
for k, t in enumerate(facts):
    fid[t] = p1.box(t, gx + 15, Y + 36 + k * 42, 220, 32, "trino", "fontSize=10;")
mid = {}
for k, t in enumerate(marts):
    deps_txt = {"mart_sales_daily": "← line_component", "mart_product_attribute_perf": "← order_line, review", "mart_inventory_health": "← inventory_daily, sales_daily",
                "mart_channel_funnel": "← traffic, ads, order", "mart_order_sla": "← status_event", "mart_customer_rfm": "← order",
                "mart_demand_forecast_input": "← sales_daily, inventory_health"}[t]
    mid[t] = p1.box(f"<b>{t}</b><br><span style='font-size:9px;color:#555'>{deps_txt}</span>", gx + 320, Y + 50 + k * 72, 225, 44, "trino", "fontSize=10;")
p1.e(gate, fid["fct_order"], "không", exit=(1, .5), entry=(0, .5))
dep = {"mart_sales_daily": ["fct_order_line_component"], "mart_product_attribute_perf": ["fct_order_line", "fct_review"],
       "mart_inventory_health": ["fct_inventory_daily", "mart_sales_daily"], "mart_channel_funnel": ["fct_listing_traffic_daily", "fct_ads_daily", "fct_order"],
       "mart_order_sla": ["fct_order_status_event"], "mart_customer_rfm": ["fct_order"], "mart_demand_forecast_input": ["mart_sales_daily", "mart_inventory_health"]}
p1.e(fid["fct_order"], fid["fct_order_line"], "", "strokeColor=#B0087F;strokeWidth=1;", exit=(.5, 1), entry=(.5, 0))
p1.e(fid["fct_order_line"], fid["fct_order_line_component"], "", "strokeColor=#B0087F;strokeWidth=1;", exit=(.5, 1), entry=(.5, 0))
p1.line(gx + 250, Y + 300, gx + 310, Y + 300, "facts → marts", "strokeColor=#B0087F;strokeWidth=2;")
# dq gold + publish
px = 2290
dqg = p1.box("<b>dq_reconcile</b><br>XR-07 tồn kho · XR-11 · XR-13/14<br>Σ gold = Σ silver", px, Y + 200, 190, 80, "dq")
for m in mid.values():
    p1.e(m, dqg, "", "strokeColor=#DDDDDD;strokeWidth=1;", exit=(1, .5), entry=(0, .5))
pub = p1.group("publish", px, Y + 320, 190, 250, C["python"][1])
w1 = p1.box("<b>write_run_log</b><br>ops.pipeline_run_log", px + 10, Y + 355, 170, 46, "python")
w2 = p1.box("<b>refresh_powerbi</b> (tùy chọn)", px + 10, Y + 425, 170, 40, "python")
w3 = p1.box("<b>notify_success</b>", px + 10, Y + 490, 170, 36, "python")
p1.icon("powerbi", px + 150, Y + 428, 26)
p1.e(dqg, w1, "", exit=(.5, 1), entry=(.5, 0)); p1.e(w1, w2, ""); p1.e(w2, w3, "")
# DAG phụ
oy = 720
p1.group("Các DAG khác", 20, oy, 1900, 270, "#555555")
m1 = p1.box("<b>vnb_master_refresh</b> · 30 1 * * *<br>wait_master_success → validate_master_manifest → load_bronze_master → silver_master (SCD2 products) → dq_master → build_gold_dims (9 dim)", 40, oy + 40, 560, 70, "python")
m2 = p1.box("<b>vnb_backfill</b> · thủ công<br>plan_dates → trigger vnb_daily_batch từng dt (wait) → rebuild_gold_full", 640, oy + 40, 420, 70, "python")
m3 = p1.box("<b>vnb_iceberg_maintenance</b> · 0 4 * * 0<br>optimize → expire_snapshots (7d) → remove_orphan_files", 1100, oy + 40, 400, 70, "trino")
m4 = p1.box("<b>vnb_crawl_demo</b> · thủ công<br>crawl_listing_pages → write_landing_crawl → load_bronze_market_prices", 40, oy + 150, 560, 70, "spark")
m5 = p1.box("<b>vnb_forecast_weekly</b> · 0 5 * * 1<br>wait_daily_batch → build_features → train_and_predict (cập nhật sau) → write_forecast → gold.fct_demand_forecast", 640, oy + 150, 860, 70, "python")
p1.e(m1, s2, "cung cấp dim", "dashed=1;strokeColor=#2F6FB0;", exit=(.2, 0), entry=(.5, 1))
legend(p1, 1960, oy + 10)

# =========================================================== 2. SEQUENCE
p2 = Page("seq", "2. Sequence — nạp batch hằng ngày", 2000, 1500)
p2.text("<b style='font-size:20px'>Sequence: vnb_daily_batch cho ngày dt</b> — S1 happy path + S2 lỗi manifest (khung alt)", 20, 10, 1400, 30, 12)
parts = [("Hệ thống nguồn<br>(extract)", "ui"), ("Landing<br>(MinIO)", "minio"), ("Airflow<br>Scheduler", "airflow"), ("Spark", "spark"),
         ("Iceberg REST<br>Catalog", "iceberg"), ("Lakehouse<br>(MinIO, Parquet)", "minio"), ("Trino", "trino"), ("ops.dq_results /<br>pipeline_run_log", "schema"), ("Power BI", "powerbi")]
X0, DX, TOP, BOT = 80, 205, 60, 1420
xs = []
for k, (name, ic) in enumerate(parts):
    x = X0 + k * DX
    xs.append(x + 70)
    p2.v(f"<b>{name}</b>", x, TOP, 140, 54, "rounded=1;whiteSpace=wrap;html=1;fillColor=#F2F2F2;strokeColor=#555555;fontSize=11;spacingLeft=30;fontColor=#1A1A1A;")
    p2.icon(ic, x + 6, TOP + 13, 28)
    p2.v("", x + 69, TOP + 54, 2, BOT - TOP - 54, "html=1;shape=line;direction=south;dashed=1;strokeColor=#999999;fillColor=none;")
steps = [
    (0, 1, "1. ghi daily/dt=D/*.csv + _manifest.json + _SUCCESS (01:30, D+1)"),
    (2, 1, "2. S3KeySensor: poke _SUCCESS (10 phút / lần)"),
    (1, 2, "3. _SUCCESS tồn tại", "dashed=1;"),
    (2, 1, "4. check_manifest: đọc manifest, đếm dòng, md5"),
    (2, 2, "5. route_on_manifest → ok"),
    (2, 3, "6. spark-submit bronze_load --ds D (13 dataset)"),
    (3, 1, "7. đọc CSV (header, PERMISSIVE)"),
    (3, 4, "8. loadTable bronze.&lt;ds&gt;"),
    (3, 5, "9. ghi Parquet partition _dt=D"),
    (3, 4, "10. commit snapshot (overwrite _dt)"),
    (3, 2, "11. job thành công", "dashed=1;"),
    (2, 3, "12. spark-submit silver_&lt;ds&gt; (MERGE, dedup, quarantine)"),
    (3, 5, "13. đọc bronze, ghi silver + silver_quarantine"),
    (3, 4, "14. commit snapshot silver"),
    (2, 6, "15. chạy DQ SQL (field rules, XR-…)"),
    (6, 7, "16. ghi kết quả kiểm tra"),
    (2, 2, "17. dq_gate → không có lỗi Critical"),
    (2, 6, "18. gold SQL: facts → marts (CTAS / MERGE theo dt)"),
    (6, 4, "19. commit gold.*"),
    (2, 6, "20. dq_reconcile (XR-07, XR-11, XR-13)"),
    (2, 7, "21. write_run_log (SUCCESS, số dòng, thời gian)"),
    (8, 6, "22. refresh: SELECT gold.* (Import / DirectQuery)"),
    (6, 8, "23. kết quả truy vấn", "dashed=1;"),
]
y = 150
for st in steps:
    a, b, lab = st[:3]
    sty = st[3] if len(st) > 3 else ""
    if a == b:
        x = xs[a]
        p2.v("", x - 6, y - 6, 12, 30, f"rounded=0;html=1;fillColor={C['branch'][0]};strokeColor={C['branch'][1]};")
        p2.text(lab, x + 12, y - 8, 260, 30, 10)
        y += 44
        continue
    p2.line(xs[a], y, xs[b], y, lab, sty + "verticalAlign=bottom;" + ("strokeColor=#2F6FB0;" if a == 2 else "strokeColor=#555555;"))
    y += 44
# alt frame S2
ay = y + 10
p2.v("", 40, ay, 1880, 230, f"rounded=0;html=1;fillColor=none;strokeColor={C['fail'][1]};strokeWidth=1.5;dashed=1;")
p2.v("<b>alt</b> [manifest lệch số dòng / md5 — FILE-02]", 40, ay, 330, 24, f"shape=mxgraph.sysml.package;html=1;fillColor={C['fail'][0]};strokeColor={C['fail'][1]};fontSize=11;align=left;spacingLeft=6;")
y2 = ay + 50
for (a, b, lab) in [(2, 2, "S2.1 check_manifest phát hiện lệch → branch fail"), (2, 1, "S2.2 chuyển dt=D sang landing/_quarantine"),
                    (2, 7, "S2.3 ghi ops.dq_results (E1, High) + run FAILED"), (2, 0, "S2.4 alert email/chat: yêu cầu gửi lại file"),
                    (0, 1, "S2.5 gửi lại file → kỹ sư Clear task → chạy lại idempotent từ bước 4")]:
    if a == b:
        p2.text(lab, xs[a] + 12, y2 - 8, 300, 30, 10); y2 += 40; continue
    p2.line(xs[a], y2, xs[b], y2, lab, f"verticalAlign=bottom;strokeColor={C['fail'][1]};")
    y2 += 40

# =========================================================== 3. ERROR HANDLING FLOWCHART
p3 = Page("err", "3. Error handling flowchart", 2100, 1500)
p3.text("<b style='font-size:20px'>Xử lý lỗi trong vnb_daily_batch</b> — không nạp nửa vời · job idempotent theo dt · lỗi dữ liệu không retry, lỗi hạ tầng mới retry · Critical chặn publish", 20, 10, 1700, 30, 12)
cx = 340
st = p3.box("<b>Bắt đầu</b><br>02:00 · run dt", cx - 70, 60, 140, 60, "end")
d1 = p3.box("_SUCCESS có?", cx - 80, 150, 160, 80, "branch")
w = p3.box("chờ (poke 10m)", cx + 170, 165, 140, 50, "sensor")
d1b = p3.box("quá 6h?", cx + 170, 250, 140, 70, "branch")
f1 = p3.box("<b>E1 · FILE-08</b><br>alert High · run FAILED<br>không nạp nửa vời", cx + 360, 250, 200, 70, "fail")
p3.e(st, d1); p3.e(d1, w, "không", exit=(1, .5), entry=(0, .5)); p3.e(w, d1b, "", exit=(.5, 1), entry=(.5, 0))
p3.e(d1b, d1, "chưa", exit=(0, .5), entry=(1, .8), pts=[(cx + 140, 285), (cx + 140, 214)]); p3.e(d1b, f1, "rồi", exit=(1, .5), entry=(0, .5))
d2 = p3.box("Có manifest?", cx - 80, 270, 160, 80, "branch")
dg = p3.box("<b>FILE-09 · degraded</b><br>nạp theo file thực có<br>gắn cờ · alert Medium", cx - 300, 275, 190, 70, "fail")
p3.e(d1, d2, "có"); p3.e(d2, dg, "không", exit=(0, .5), entry=(1, .5))
d3 = p3.box("Số dòng + md5<br>khớp?", cx - 80, 390, 160, 90, "branch")
q1 = p3.box("<b>FILE-01/02/06</b><br>file muộn → nạp đúng dt gốc<br>file trùng → bỏ bản trùng<br>lệch → quarantine_batch<br>alert High · FAILED", cx + 170, 385, 230, 100, "fail")
p3.e(d2, d3, "có"); p3.e(dg, d3, "", exit=(.5, 1), entry=(0, .5), pts=[(cx - 205, 435)]); p3.e(d3, q1, "không", exit=(1, .5), entry=(0, .5))
d4 = p3.box("schema_version<br>đã biết?", cx - 80, 520, 160, 90, "branch")
sv = p3.box("<b>FILE-03/04</b><br>thêm cột: ADD COLUMN Iceberg<br>đọc theo tên cột · alert Medium", cx + 170, 525, 230, 80, "python")
p3.e(d3, d4, "khớp"); p3.e(d4, sv, "mới", exit=(1, .5), entry=(0, .5))
bl = p3.box("<b>Bronze load</b> (Spark, PERMISSIVE)<br>encoding UTF-8 → thử cp1258 (FILE-07)", cx - 120, 650, 240, 60, "spark")
p3.e(d4, bl, "có"); p3.e(sv, bl, "", exit=(.5, 1), entry=(1, .5), pts=[(cx + 285, 680)])
d5 = p3.box("Task lỗi kỹ thuật?<br>(OOM, timeout,<br>commit conflict)", cx - 90, 740, 180, 100, "branch")
rt = p3.box("<b>E7 · retry</b><br>tối đa 2 lần (commit: 4)<br>backoff 5m → 10m", cx + 170, 750, 200, 80, "python")
f7 = p3.box("<b>FAILED</b> · alert High<br>depends_on_past<br>chặn ngày sau", cx + 400, 750, 160, 80, "fail")
p3.e(bl, d5); p3.e(d5, rt, "có", exit=(1, .5), entry=(0, .5)); p3.e(rt, f7, "vẫn lỗi", exit=(1, .5), entry=(0, .5))
p3.e(rt, bl, "thử lại", "dashed=1;", exit=(.5, 0), entry=(1, .3), pts=[(cx + 270, 668)])
d6 = p3.box("_corrupt_record<br>> 0,1%?", cx - 80, 880, 160, 90, "branch")
c5 = p3.box("<b>FILE-05</b><br>dòng hỏng → bronze._corrupt<br>alert High, vẫn tiếp tục", cx + 170, 885, 230, 80, "fail")
p3.e(d5, d6, "không"); p3.e(d6, c5, "có", exit=(1, .5), entry=(0, .5))
# phân loại bản ghi ở silver
sx = 960
p3.group("Silver: phân loại từng bản ghi (theo issue catalog)", sx, 60, 1150, 900, "#2E7D4F", "#F7FBF8")
rec = p3.box("<b>Bản ghi từ Bronze</b>", sx + 40, 110, 180, 50, "spark")
p3.e(d6, rec, "không", exit=(.5, 1), entry=(0, .5), pts=[(cx, 1000), (sx - 30, 1000), (sx - 30, 135)])
p3.e(c5, rec, "", "dashed=1;", exit=(1, .5), entry=(0, .7), pts=[(sx - 10, 925), (sx - 10, 145)])
checks = [("Trùng khóa?", "<b>E3 · dedup</b><br>giữ bản mới nhất theo updated_at / modified_at<br>ORD-01, REV-04, INV-01, MKT-03…", "dq"),
          ("Sai miền / kiểu /<br>FK không tồn tại?", "<b>E2 · quarantine</b><br>silver_quarantine.&lt;ds&gt; + issue_id<br>FK thiếu ở gold → −1<br>ITM-01/02/03, ORD-02, REV-01…", "fail"),
          ("Chứa PII?", "<b>E6 · che PII</b><br>regex SĐT / email (REV-02)<br>còn sót ở Gold → Critical", "fail"),
          ("Cần chuẩn hóa?", "<b>E5 · chuẩn hóa</b><br>TRIM/UPPER/LOWER, từ điển màu<br>ITM-05, CUS-01, PRD-02…", "python"),
          ("Phi logic /<br>lệch đối soát?", "<b>E4 · gắn cờ is_*_anomaly</b><br>tính lại nếu được (total, discount)<br>ORD-03/06, SNP-01, PO-02…", "branch")]
prev = rec
for k, (q, a, kind) in enumerate(checks):
    y = 190 + k * 140
    d = p3.box(q, sx + 40, y, 180, 100, "branch")
    p3.e(prev, d, "không" if k else "", exit=(.5, 1), entry=(.5, 0))
    r = p3.box(a, sx + 300, y + 10, 320, 80, kind if kind != "branch" else "python",
               f"fillColor={C['branch'][0]};strokeColor={C['branch'][1]};" if kind == "branch" else "")
    p3.e(d, r, "có", exit=(1, .5), entry=(0, .5))
    prev = d
ok = p3.box("<b>Ghi silver</b> (MERGE)<br>+ ops.dq_results", sx + 40, 900, 180, 50, "spark")
p3.e(prev, ok, "không", exit=(.5, 1), entry=(.5, 0))
for k in range(len(checks)):
    p3.line(sx + 620, 240 + k * 140, sx + 680, 240 + k * 140, "", "strokeColor=#999999;dashed=1;")
p3.v("", sx + 680, 240, 2, 560, "html=1;shape=line;direction=south;strokeColor=#999999;dashed=1;fillColor=none;")
p3.text("tất cả đều được ghi<br>vào ops.dq_results<br>(issue_id, số dòng)", sx + 700, 500, 160, 60, 10)
# gate
gy = 1040
g1 = p3.box("<b>dq_gate</b><br>lỗi Critical vượt ngưỡng?", sx + 20, gy, 220, 100, "branch")
p3.e(ok, g1, "", exit=(.5, 1), entry=(.5, 0), pts=[(sx + 130, 1000)]) if False else p3.e(ok, g1, "")
sk = p3.box("<b>E8</b> · skip gold + publish<br>Power BI giữ số liệu ngày trước<br>alert Critical (4h)", sx + 300, gy + 10, 260, 80, "fail")
p3.e(g1, sk, "có", exit=(1, .5), entry=(0, .5))
gd = p3.box("<b>Gold build</b> (Trino)", sx + 40, gy + 150, 180, 50, "trino")
p3.e(g1, gd, "không")
g2 = p3.box("dq_reconcile<br>lệch (XR-07/11)?", sx + 20, gy + 240, 220, 90, "branch")
wn = p3.box("<b>High</b> · publish kèm cảnh báo<br>trên dashboard", sx + 300, gy + 245, 260, 70, "fail")
p3.e(gd, g2); p3.e(g2, wn, "có", exit=(1, .5), entry=(0, .5))
pb = p3.box("<b>Publish</b><br>run_log · notify", sx + 40, gy + 370, 180, 50, "python")
en = p3.box("<b>SUCCESS</b>", sx + 610, gy + 365, 140, 60, "end")
p3.e(g2, pb, "không"); p3.e(wn, pb, "", exit=(.5, 1), entry=(1, .5), pts=[(sx + 430, gy + 395)]); p3.e(pb, en, "", exit=(1, .5), entry=(0, .5))
sla = p3.box("<b>E9</b> · quá 06:00 chưa xong<br>sla_miss_callback → alert High", 40, 1100, 260, 70, "fail")
p3.text("Áp dụng cho mọi task, độc lập với luồng trên", 40, 1176, 300, 20, 10)

# =========================================================== 4. DATA LINEAGE
p4 = Page("lin", "4. Data lineage", 2500, 1500)
p4.text("<b style='font-size:20px'>Data lineage (mức bảng)</b> — landing → bronze → silver → gold → Power BI · sinh từ vn_beauty_source_to_target_mapping.xlsx", 20, 10, 1800, 30, 12)
edf = pd.read_csv("specs/_lineage_edges.csv")
REF = set(GS.MASTER[5:])
rows = GS.INCR + GS.MASTER[:5] + ["reference"]
LX = {"landing": 30, "bronze": 300, "silver": 560}
hdrs = [("Landing (CSV)", 30, "#555555"), ("Bronze (Iceberg)", 300, "#C8691C"), ("Silver (Iceberg)", 560, "#666666"),
        ("Gold · dim", 900, "#C9A400"), ("Gold · fact", 1210, "#C9A400"), ("Gold · mart", 1560, "#C9A400"), ("Power BI", 1950, "#6B4FBB")]
for t, x, c in hdrs:
    p4.v(f"<b>{t}</b>", x, 50, 220 if x < 1900 else 240, 30, f"rounded=0;html=1;fillColor={c};strokeColor={c};fontColor=#FFFFFF;fontSize=12;")
node = {}
for k, ds in enumerate(rows):
    y = 100 + k * 50
    lab = "reference (11 bảng danh mục)" if ds == "reference" else ds
    node[("landing", ds)] = p4.v(f"{lab}.csv" if ds != "reference" else "master/*.csv (11 danh mục)", 30, y, 220, 34,
                                 "rounded=1;html=1;whiteSpace=wrap;fillColor=#F2F2F2;strokeColor=#888888;fontSize=10;fontColor=#1A1A1A;" + ("dashed=1;" if ds in GS.MASTER or ds == "reference" else ""))
    node[("bronze", ds)] = p4.v(f"bronze.{lab}", 300, y, 220, 34, "rounded=1;html=1;whiteSpace=wrap;fillColor=#FDF1E7;strokeColor=#C8691C;fontSize=10;fontColor=#1A1A1A;")
    node[("silver", ds)] = p4.v(f"silver.{lab}", 560, y, 220, 34, "rounded=1;html=1;whiteSpace=wrap;fillColor=#F2F2F2;strokeColor=#666666;fontSize=10;fontColor=#1A1A1A;")
    p4.e(node[("landing", ds)], node[("bronze", ds)], "", "strokeColor=#C8691C;strokeWidth=1;")
    p4.e(node[("bronze", ds)], node[("silver", ds)], "", "strokeColor=#888888;strokeWidth=1;")
qy = 100 + len(rows) * 50 + 10
node[("ops", "q")] = p4.v("silver_quarantine.&lt;dataset&gt;<br>ops.dq_results", 560, qy, 220, 44, f"rounded=1;html=1;whiteSpace=wrap;fillColor={C['fail'][0]};strokeColor={C['fail'][1]};fontSize=10;")
p4.text("<i>mọi bảng bronze → quarantine khi bản ghi lỗi</i>", 300, qy + 6, 250, 30, 10)
gold_cols = {"dim": 900, "fact": 1210, "mart": 1560}
cnt = {"dim": 0, "fact": 0, "mart": 0}
GAP = {"dim": 62, "fact": 52, "mart": 80}
for t, (typ, *_rest) in GS.GOLD.items():
    if t == "fct_demand_forecast":
        typ = "mart"
    x = gold_cols[typ]
    y = 100 + cnt[typ] * GAP[typ]
    cnt[typ] += 1
    node[("gold", t)] = p4.v(f"gold.<b>{t}</b>", x, y, 250, 34, "rounded=1;html=1;whiteSpace=wrap;fillColor=#FFF7D6;strokeColor=#C9A400;fontSize=10;fontColor=#1A1A1A;")
for k, page in enumerate(GS.POWERBI):
    node[("bi", page)] = p4.v(f"<b>{page}</b>", 1950, 130 + k * 120, 240, 50, "rounded=1;html=1;whiteSpace=wrap;fillColor=#F3EEFB;strokeColor=#6B4FBB;fontSize=11;fontColor=#1A1A1A;")
p4.icon("powerbi", 2200, 60, 26)
seen = set()
for r in edf.itertuples(index=False):
    if r.from_layer in ("landing", "bronze") and r.to_layer in ("bronze", "silver", "ops"):
        continue
    def key(layer, tbl):
        if layer == "silver":
            n = tbl.split(".", 1)[1]
            return ("silver", "reference" if n in REF else n)
        if layer == "gold":
            return ("gold", tbl.split(".", 1)[1])
        if layer == "bi":
            return ("bi", tbl.split(": ", 1)[1])
        return None
    a, b = key(r.from_layer, r.from_table), key(r.to_layer, r.to_table)
    if not a or not b or (a, b) in seen or a not in node or b not in node:
        continue
    seen.add((a, b))
    col = {"silver": "#9DB7D5", "gold": "#E0B84C"}[a[0]] if b[0] != "bi" else "#B39DDB"
    same_col = a[0] == "gold" and b[0] == "gold" and (GS.GOLD[a[1]][0] == GS.GOLD[b[1]][0] or b[1] == "fct_demand_forecast")
    if same_col:
        p4.e(node[a], node[b], "", f"strokeColor={col};strokeWidth=1;endSize=4;", exit=(1, .5), entry=(1, .5))
    else:
        p4.e(node[a], node[b], "", f"edgeStyle=none;curved=0;strokeColor={col};strokeWidth=1;endSize=4;", exit=(1, .5), entry=(0, .5))
p4.e(node[("bronze", "reference")], node[("ops", "q")], "", "dashed=1;strokeColor=#C00000;strokeWidth=1;", exit=(.5, 1), entry=(0, .5))
p4.text("<b>Đọc sơ đồ</b>: nét đứt ở cột landing = bảng danh mục (full snapshot, vnb_master_refresh); nét liền = file ngày (vnb_daily_batch).<br>"
        "Lineage mức cột: xem sheet Column mapping (924 dòng) trong file mapping.", 30, 1360, 1400, 40, 10)

pages = [p1, p2, p3, p4]
xml = '<mxfile host="app.diagrams.net" pages="4">' + "".join(p.xml() for p in pages) + "</mxfile>"
os.makedirs("diagrams", exist_ok=True)
open("diagrams/vn_beauty_pipeline_diagrams.drawio", "w", encoding="utf-8").write(xml)
for p in pages:
    open(f"diagrams/_{p.pid}.xml", "w", encoding="utf-8").write('<mxfile>' + p.xml() + '</mxfile>')
print("ok", [len(p.cells) for p in pages])
