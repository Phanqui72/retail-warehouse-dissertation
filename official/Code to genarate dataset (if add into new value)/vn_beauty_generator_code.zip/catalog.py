"""Master data cho VN Beauty Orders Dataset: danh mục SKU, kênh, kho, tỉnh, NCC, hãng vận chuyển, sự kiện."""
from datetime import date

# ------------------------------------------------------------------ thương hiệu (hư cấu)
BRANDS = [  # brand_id, brand_name, positioning
    (101, "Velia Beauty", "premium"),
    (102, "Mira Tools", "value"),
    (103, "Lumi Pro", "pro"),
]
BRAND_ID = {b[1]: b[0] for b in BRANDS}

# ------------------------------------------------------------------ cây danh mục
# category_id, category_l1, category_l2
CATEGORIES = [
    (1101, "Dụng cụ trang điểm", "Mút tán nền"),
    (1102, "Dụng cụ trang điểm", "Cọ nền & phấn"),
    (1103, "Dụng cụ trang điểm", "Cọ mắt & má"),
    (1104, "Dụng cụ trang điểm", "Bộ cọ trang điểm"),
    (1105, "Dụng cụ trang điểm", "Bông phấn"),
    (1201, "Dụng cụ mi & mày", "Kẹp mi"),
    (1202, "Dụng cụ mi & mày", "Nhíp & dao cạo"),
    (1301, "Chăm sóc da", "Bông tẩy trang"),
    (1302, "Chăm sóc da", "Massage mặt"),
    (1303, "Chăm sóc da", "Phụ kiện rửa mặt & tắm"),
    (1401, "Chăm sóc tóc", "Lược & lô cuốn"),
    (1402, "Chăm sóc tóc", "Kẹp tóc"),
    (1501, "Vệ sinh dụng cụ", "Vệ sinh cọ"),
    (1601, "Gương & túi", "Gương"),
    (1602, "Gương & túi", "Túi & hộp đựng"),
    (1701, "Combo & set quà", "Combo"),
]
CAT_ID = {c[2]: c[0] for c in CATEGORIES}

# ------------------------------------------------------------------ dòng sản phẩm (parent) + biến thể
# (line_code, line_name, brand, category_l2, material, shape, launch, retail, cost_ratio, weight_g, base_pop, rating_base,
#  variants: list of dict(attr...) ; giá riêng theo biến thể nếu có 'price')
L = [
    ("MTN-GN", "Mút tán nền giọt nước", "Velia Beauty", "Mút tán nền", "Foam không latex", "Giọt nước", "2020-09-01", 49000, .32, 20, 10.0, 4.8,
     [dict(color="Trắng"), dict(color="Hồng phấn"), dict(color="Be"), dict(color="Đen"), dict(color="Tím pastel")]),
    ("MTN-HL", "Mút tán nền hồ lô", "Mira Tools", "Mút tán nền", "Foam không latex", "Hồ lô", "2020-09-01", 39000, .30, 18, 5.0, 4.6,
     [dict(color="Trắng"), dict(color="Hồng"), dict(color="Cam đào")]),
    ("MTN-VC", "Mút vát cạnh hộp 4", "Velia Beauty", "Mút tán nền", "Foam không latex", "Vát cạnh", "2022-03-01", 89000, .34, 60, 2.5, 4.7,
     [dict(color="Hồng", pack_qty=4), dict(color="Be", pack_qty=4)]),
    ("MTN-HY", "Mút siêu mềm Hydro", "Lumi Pro", "Mút tán nền", "Foam hydrophilic", "Giọt nước", "2024-04-10", 69000, .33, 22, 4.0, 4.8,
     [dict(color="Trắng"), dict(color="Xanh mint")]),
    ("CN-DB", "Cọ nền đầu bằng", "Velia Beauty", "Cọ nền & phấn", "Lông tổng hợp", "Đầu bằng", "2020-09-01", 129000, .35, 45, 3.0, 4.7,
     [dict(color="Bạc"), dict(color="Đen"), dict(color="Vàng hồng")]),
    ("CN-KB", "Cọ nền Kabuki đầu tròn", "Lumi Pro", "Cọ nền & phấn", "Lông tổng hợp", "Đầu tròn", "2022-08-15", 149000, .36, 50, 1.8, 4.6,
     [dict(color="Bạc"), dict(color="Đen")]),
    ("CP-PP", "Cọ phấn phủ", "Velia Beauty", "Cọ nền & phấn", "Lông tổng hợp", "Đầu tròn lớn", "2021-06-01", 139000, .35, 48, 1.8, 4.7,
     [dict(color="Bạc"), dict(color="Vàng hồng")]),
    ("CM-XE", "Cọ má hồng đầu xéo", "Mira Tools", "Cọ mắt & má", "Lông tổng hợp", "Đầu xéo", "2021-06-01", 79000, .33, 30, 1.6, 4.5,
     [dict(color="Đen"), dict(color="Hồng")]),
    ("CC-KD", "Cọ che khuyết điểm", "Mira Tools", "Cọ mắt & má", "Lông tổng hợp", "Đầu dẹt", "2022-01-10", 59000, .33, 15, 1.4, 4.5,
     [dict(size="Nhỏ"), dict(size="Vừa")]),
    ("CM-DT", "Cọ mắt đơn tán", "Lumi Pro", "Cọ mắt & má", "Lông tổng hợp", "Đầu tròn nhỏ", "2023-02-20", 49000, .32, 12, 1.2, 4.6,
     [dict(size="Nhỏ"), dict(size="Lớn")]),
    ("BC-M5", "Bộ cọ mắt 5 cây", "Velia Beauty", "Bộ cọ trang điểm", "Lông tổng hợp", "Bộ", "2021-09-01", 199000, .38, 90, 1.5, 4.7,
     [dict(color="Bạc", pack_qty=5), dict(color="Đen", pack_qty=5)]),
    ("BC-12", "Bộ cọ trang điểm 12 cây", "Velia Beauty", "Bộ cọ trang điểm", "Lông tổng hợp", "Bộ", "2020-09-01", 459000, .40, 320, 2.2, 4.8,
     [dict(color="Bạc", pack_qty=12), dict(color="Vàng hồng", pack_qty=12), dict(color="Đen", pack_qty=12)]),
    ("BC-DL7", "Bộ cọ du lịch 7 cây", "Mira Tools", "Bộ cọ trang điểm", "Lông tổng hợp", "Bộ", "2022-11-01", 249000, .38, 180, 1.3, 4.5,
     [dict(color="Hồng", pack_qty=7), dict(color="Trắng", pack_qty=7)]),
    ("BP-TR", "Bông phấn tròn", "Mira Tools", "Bông phấn", "Nhung", "Tròn", "2020-09-01", 25000, .28, 10, 4.0, 4.5,
     [dict(color="Trắng"), dict(color="Hồng"), dict(color="Be")]),
    ("BP-TG", "Bông phấn tam giác hộp 2", "Mira Tools", "Bông phấn", "Nhung", "Tam giác", "2023-05-01", 35000, .28, 14, 3.0, 4.6,
     [dict(color="Trắng", pack_qty=2), dict(color="Be", pack_qty=2)]),
    ("KM-IN", "Kẹp mi inox", "Velia Beauty", "Kẹp mi", "Inox", "Cong rộng", "2020-09-01", 99000, .35, 40, 2.2, 4.6,
     [dict(color="Bạc"), dict(color="Vàng hồng")]),
    ("KM-MN", "Kẹp mi mini", "Mira Tools", "Kẹp mi", "Inox", "Mini", "2022-04-01", 59000, .33, 20, 1.2, 4.4,
     [dict(color="Bạc"), dict(color="Đen")]),
    ("NH-MY", "Nhíp nhổ lông mày", "Mira Tools", "Nhíp & dao cạo", "Inox", None, "2021-03-01", 45000, .30, 12, 1.4, 4.5,
     [dict(shape="Đầu xéo"), dict(shape="Đầu nhọn")]),
    ("DC-MY", "Dao cạo chân mày", "Mira Tools", "Nhíp & dao cạo", "Thép không gỉ", None, "2021-03-01", 29000, .25, 15, 2.6, 4.4,
     [dict(pack_qty=3, price=29000), dict(pack_qty=6, price=49000)]),
    ("BTT-HP", "Bông tẩy trang", "Velia Beauty", "Bông tẩy trang", "Cotton", "Vuông", "2020-09-01", 29000, .30, 60, 9.0, 4.7,
     [dict(pack_qty=80, price=29000), dict(pack_qty=120, price=39000), dict(pack_qty=222, price=59000)]),
    ("BTT-VA", "Bông tẩy trang vải tái sử dụng", "Lumi Pro", "Bông tẩy trang", "Vải tre", "Tròn", "2023-09-01", 69000, .35, 40, 1.2, 4.5,
     [dict(pack_qty=5, price=69000), dict(pack_qty=10, price=119000)]),
    ("LM-DA", "Cây lăn mặt đá", "Lumi Pro", "Massage mặt", None, "Lăn đôi", "2022-06-01", 189000, .40, 160, 1.4, 4.6,
     [dict(material="Thạch anh hồng"), dict(material="Ngọc bích")]),
    ("GS-DA", "Miếng gua sha", "Lumi Pro", "Massage mặt", None, "Trái tim", "2022-06-01", 129000, .40, 60, 1.1, 4.6,
     [dict(material="Thạch anh hồng"), dict(material="Ngọc bích")]),
    ("BT-TB", "Bông tắm tạo bọt", "Mira Tools", "Phụ kiện rửa mặt & tắm", "Lưới nylon", "Tròn", "2020-09-01", 29000, .25, 30, 1.8, 4.4,
     [dict(color="Hồng"), dict(color="Xanh"), dict(color="Trắng")]),
    ("BD-RM", "Băng đô rửa mặt", "Mira Tools", "Phụ kiện rửa mặt & tắm", "Lông nhung", "Tai thỏ", "2021-10-01", 35000, .28, 25, 2.4, 4.6,
     [dict(color="Hồng"), dict(color="Trắng"), dict(color="Kem")]),
    ("LC-GR", "Lược gỡ rối", "Velia Beauty", "Lược & lô cuốn", "Nhựa ABS", "Oval", "2021-04-01", 89000, .33, 60, 1.6, 4.6,
     [dict(color="Đen"), dict(color="Hồng")]),
    ("LO-CT", "Lô cuốn tóc tự dính", "Mira Tools", "Lược & lô cuốn", "Nhựa PP", "Trụ", "2022-02-01", 39000, .28, 40, 1.8, 4.4,
     [dict(size="S"), dict(size="M"), dict(size="L")]),
    ("KT-CC", "Kẹp tóc càng cua", "Mira Tools", "Kẹp tóc", "Nhựa acrylic", "Càng cua", "2022-02-01", 25000, .25, 15, 2.2, 4.5,
     [dict(color="Đen"), dict(color="Nâu"), dict(color="Kem"), dict(color="Hồng")]),
    ("NRC-VS", "Nước rửa cọ", "Lumi Pro", "Vệ sinh cọ", None, "Chai", "2022-09-01", 79000, .35, 130, 1.0, 4.5,
     [dict(size="100ml", price=79000), dict(size="250ml", price=149000)]),
    ("TRC-SL", "Thảm rửa cọ silicon", "Mira Tools", "Vệ sinh cọ", "Silicon", "Trái tim", "2021-08-01", 49000, .30, 45, 1.3, 4.5,
     [dict(color="Hồng"), dict(color="Xanh")]),
    ("GPC-CO", "Giá phơi cọ", "Mira Tools", "Vệ sinh cọ", "Nhựa ABS", "Tháp", "2023-03-01", 69000, .32, 80, 0.7, 4.3,
     [dict(color="Trắng")]),
    ("GU-LED", "Gương LED để bàn", "Velia Beauty", "Gương", "Nhựa ABS", "Chữ nhật", "2022-05-01", 299000, .45, 520, 1.0, 4.5,
     [dict(color="Trắng"), dict(color="Hồng")]),
    ("GU-CT", "Gương cầm tay gấp", "Mira Tools", "Gương", "Nhựa ABS", "Tròn", "2021-05-01", 49000, .30, 90, 1.3, 4.4,
     [dict(color="Trắng"), dict(color="Hồng"), dict(color="Đen")]),
    ("TU-MP", "Túi đựng mỹ phẩm", "Velia Beauty", "Túi & hộp đựng", "Da PU", "Hộp", "2021-11-01", 129000, .38, 150, 1.4, 4.6,
     [dict(size="S", color="Đen", price=129000), dict(size="S", color="Hồng", price=129000),
      dict(size="M", color="Đen", price=179000), dict(size="M", color="Hồng", price=179000)]),
    ("HD-CO", "Hộp đựng cọ", "Mira Tools", "Túi & hộp đựng", "Nhựa acrylic", "Trụ", "2023-06-01", 59000, .30, 110, 0.7, 4.3,
     [dict(color="Trắng"), dict(color="Hồng")]),
]

# Hệ số nhu cầu ẩn theo thuộc tính (đáp án cho bài toán insight "đặc điểm nào bán tốt")
ATTR_DEMAND = {
    "color": {"Trắng": 1.35, "Hồng phấn": 1.25, "Hồng": 1.15, "Be": 1.0, "Đen": 0.75, "Tím pastel": 0.55, "Cam đào": 0.8,
              "Xanh mint": 0.9, "Bạc": 1.2, "Vàng hồng": 1.1, "Kem": 1.1, "Nâu": 0.8, "Xanh": 0.85},
    "size": {"Nhỏ": 1.0, "Vừa": 1.2, "Lớn": 0.8, "S": 0.9, "M": 1.2, "L": 0.7, "100ml": 1.3, "250ml": 0.7},
    "pack_qty": {80: 0.8, 120: 1.3, 222: 1.0, 3: 1.2, 6: 0.8, 5: 1.1, 10: 0.7},
    "material": {"Thạch anh hồng": 1.3, "Ngọc bích": 0.75},
    "shape": {"Đầu xéo": 1.3, "Đầu nhọn": 0.7},
}
# Thuộc tính ảnh hưởng điểm đánh giá (ví dụ cán bạc ít lỗi bong tróc hơn cán đen)
ATTR_RATING = {"color": {"Đen": -0.25, "Bạc": +0.1, "Tím pastel": -0.15}, "material": {"Ngọc bích": -0.2}}

COMBOS = [  # code, name, components [(line_code, variant_idx, qty)], launch, price
    ("CB-01", "Combo 3 mút giọt nước trắng", [("MTN-GN", 0, 3)], "2021-03-01", 129000),
    ("CB-02", "Combo mút giọt nước + bông phấn tròn", [("MTN-GN", 1, 1), ("BP-TR", 1, 1)], "2021-06-01", 69000),
    ("CB-03", "Set quà bộ cọ 12 cây + túi S", [("BC-12", 0, 1), ("TU-MP", 0, 1)], "2021-11-15", 549000),
    ("CB-04", "Combo bông tẩy trang 3 hộp 120", [("BTT-HP", 1, 3)], "2021-04-01", 105000),
    ("CB-05", "Combo cây lăn + gua sha thạch anh", [("LM-DA", 0, 1), ("GS-DA", 0, 1)], "2022-07-01", 289000),
    ("CB-06", "Combo vệ sinh cọ (nước rửa 100ml + thảm)", [("NRC-VS", 0, 1), ("TRC-SL", 0, 1)], "2022-09-15", 115000),
    ("CB-07", "Combo kẹp mi + nhíp", [("KM-IN", 0, 1), ("NH-MY", 0, 1)], "2021-08-01", 129000),
    ("CB-08", "Set mút 4 màu giọt nước", [("MTN-GN", 0, 1), ("MTN-GN", 1, 1), ("MTN-GN", 2, 1), ("MTN-GN", 3, 1)], "2022-01-10", 169000),
    ("CB-09", "Combo băng đô + bông tắm", [("BD-RM", 0, 1), ("BT-TB", 0, 1)], "2022-03-01", 59000),
    ("CB-10", "Combo dao cạo 6 + nhíp đầu xéo", [("DC-MY", 1, 1), ("NH-MY", 0, 1)], "2022-05-01", 85000),
    ("CB-11", "Set quà gương LED + túi M", [("GU-LED", 1, 1), ("TU-MP", 3, 1)], "2022-11-01", 449000),
    ("CB-12", "Combo cọ nền + mút Hydro", [("CN-DB", 0, 1), ("MTN-HY", 0, 1)], "2024-05-01", 179000),
    ("CB-13", "Combo 5 kẹp càng cua", [("KT-CC", 0, 2), ("KT-CC", 2, 2), ("KT-CC", 3, 1)], "2023-01-05", 99000),
    ("CB-14", "Combo bộ cọ du lịch + hộp đựng", [("BC-DL7", 0, 1), ("HD-CO", 1, 1)], "2023-10-01", 279000),
    ("CB-15", "Combo bông phấn tam giác + mút hồ lô", [("BP-TG", 0, 1), ("MTN-HL", 0, 1)], "2023-07-01", 69000),
]
DISCONTINUED = {"MTN-GN-05": "2024-06-30", "KM-MN-02": "2025-03-31", "CB-02": "2023-12-31", "BC-DL7-02": "2025-08-31"}

# ------------------------------------------------------------------ kênh & shop
# shop_code, sale_channel, platform, channel_name, shop_name, is_marketplace, opened_date, closed_date
SHOPS = [
    ("SHP_MALL", 42, "shopee", "Shopee", "Velia Official Store (Shopee Mall)", True, "2021-01-01", None),
    ("SHP_02", 42, "shopee", "Shopee", "Mira Tools Store (Shopee)", True, "2022-03-01", None),
    ("TTS_01", 48, "tiktok", "TikTok Shop", "Velia Beauty TikTok Shop", True, "2022-06-15", None),
    ("LZD_01", 41, "lazada", "Lazada", "Velia LazMall", True, "2021-01-01", None),
    ("WEB_01", 1, "website", "Website", "velia.vn (website)", False, "2021-01-01", None),
    ("FB_01", 2, "social", "Facebook / Zalo", "Fanpage & Zalo OA", False, "2021-01-01", None),
    ("STORE_HN", 3, "offline", "Cửa hàng", "Showroom Hà Nội", False, "2023-04-01", None),
]
# tỷ trọng kênh theo năm (trọng số tương đối)
CHANNEL_MIX = {
    2021: {"SHP_MALL": 55, "LZD_01": 16, "WEB_01": 17, "FB_01": 12},
    2022: {"SHP_MALL": 46, "SHP_02": 6, "TTS_01": 8, "LZD_01": 13, "WEB_01": 14, "FB_01": 13},
    2023: {"SHP_MALL": 40, "SHP_02": 9, "TTS_01": 20, "LZD_01": 10, "WEB_01": 10, "FB_01": 8, "STORE_HN": 3},
    2024: {"SHP_MALL": 36, "SHP_02": 10, "TTS_01": 30, "LZD_01": 7, "WEB_01": 8, "FB_01": 6, "STORE_HN": 3},
    2025: {"SHP_MALL": 34, "SHP_02": 10, "TTS_01": 35, "LZD_01": 5, "WEB_01": 8, "FB_01": 5, "STORE_HN": 3},
    2026: {"SHP_MALL": 33, "SHP_02": 10, "TTS_01": 38, "LZD_01": 4, "WEB_01": 8, "FB_01": 4, "STORE_HN": 3},
}
ORDERS_PER_YEAR = {2021: 22000, 2022: 38000, 2023: 56000, 2024: 70000, 2025: 76000, 2026: 52000}  # 2026: tới 30/09
START, END = date(2021, 1, 1), date(2026, 9, 30)

# ------------------------------------------------------------------ kho
# depot_id, depot_code, warehouse_name, warehouse_role, region, province_code, is_stock_alert, opened_date
WAREHOUSES = [
    (1, "HN-MAIN", "Kho tổng Hà Nội", "main", "Bắc", "01", True, "2021-01-01"),
    (2, "HCM-MAIN", "Kho tổng TP.HCM", "main", "Nam", "79", True, "2021-01-01"),
    (3, "HCM-FBS", "Kho Fulfillment sàn (TP.HCM)", "marketplace_fulfillment", "Nam", "74", True, "2023-03-01"),
    (4, "HN-RETURN", "Kho hàng hoàn / lỗi", "returns", "Bắc", "01", False, "2021-06-01"),
]

CARRIERS = [  # carrier_id, carrier_name, carrier_short_name, share
    (11, "Giao Hàng Nhanh", "GHN", 22), (12, "Giao Hàng Tiết Kiệm", "GHTK", 18), (13, "J&T Express", "J&T", 16),
    (14, "SPX Express", "SPX", 24), (15, "Viettel Post", "VTP", 8), (16, "Ninja Van", "NJV", 6), (17, "Tự giao / nhận tại cửa hàng", "SELF", 6),
]

SUPPLIERS = [  # supplier_id, supplier_name, country, lead_time_days, min_order_value, payment_terms
    (501, "Công ty TNHH Foam Việt (hư cấu)", "VN", 7, 5_000_000, "NET30"),
    (502, "Guangzhou Brush Factory (hư cấu)", "CN", 25, 20_000_000, "T/T 30% đặt cọc"),
    (503, "Yiwu Beauty Accessories (hư cấu)", "CN", 21, 15_000_000, "T/T 30% đặt cọc"),
    (504, "Cotton Pad Hưng Yên (hư cấu)", "VN", 5, 3_000_000, "NET15"),
    (505, "Đá tự nhiên Lục Yên (hư cấu)", "VN", 14, 8_000_000, "NET30"),
]
SUPPLIER_BY_CAT = {"Mút tán nền": 501, "Bông phấn": 501, "Bông tẩy trang": 504, "Massage mặt": 505}  # còn lại: 502/503

# ------------------------------------------------------------------ 63 tỉnh (danh mục trước 7/2025)
# code, name, type, region3, region6, weight (tỷ trọng đơn tương đối)
PROVINCES = [
    ("01", "Hà Nội", "Thành phố Trung ương", "Bắc", "Đồng bằng sông Hồng", 17.0), ("02", "Hà Giang", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .25),
    ("04", "Cao Bằng", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .25), ("06", "Bắc Kạn", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .15),
    ("08", "Tuyên Quang", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .35), ("10", "Lào Cai", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .4),
    ("11", "Điện Biên", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .2), ("12", "Lai Châu", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .15),
    ("14", "Sơn La", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .45), ("15", "Yên Bái", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .35),
    ("17", "Hòa Bình", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .4), ("19", "Thái Nguyên", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", 1.1),
    ("20", "Lạng Sơn", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .4), ("22", "Quảng Ninh", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", 1.3),
    ("24", "Bắc Giang", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", 1.1), ("25", "Phú Thọ", "Tỉnh", "Bắc", "Trung du và miền núi phía Bắc", .8),
    ("26", "Vĩnh Phúc", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", .9), ("27", "Bắc Ninh", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", 1.5),
    ("30", "Hải Dương", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", 1.1), ("31", "Hải Phòng", "Thành phố Trung ương", "Bắc", "Đồng bằng sông Hồng", 2.2),
    ("33", "Hưng Yên", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", .9), ("34", "Thái Bình", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", .8),
    ("35", "Hà Nam", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", .5), ("36", "Nam Định", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", .8),
    ("37", "Ninh Bình", "Tỉnh", "Bắc", "Đồng bằng sông Hồng", .6), ("38", "Thanh Hóa", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", 1.6),
    ("40", "Nghệ An", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", 1.5), ("42", "Hà Tĩnh", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .6),
    ("44", "Quảng Bình", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .45), ("45", "Quảng Trị", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .35),
    ("46", "Thừa Thiên Huế", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .8), ("48", "Đà Nẵng", "Thành phố Trung ương", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", 2.0),
    ("49", "Quảng Nam", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .8), ("51", "Quảng Ngãi", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .6),
    ("52", "Bình Định", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .9), ("54", "Phú Yên", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .45),
    ("56", "Khánh Hòa", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", 1.0), ("58", "Ninh Thuận", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .35),
    ("60", "Bình Thuận", "Tỉnh", "Trung", "Bắc Trung Bộ và Duyên hải miền Trung", .7), ("62", "Kon Tum", "Tỉnh", "Trung", "Tây Nguyên", .25),
    ("64", "Gia Lai", "Tỉnh", "Trung", "Tây Nguyên", .7), ("66", "Đắk Lắk", "Tỉnh", "Trung", "Tây Nguyên", 1.0),
    ("67", "Đắk Nông", "Tỉnh", "Trung", "Tây Nguyên", .35), ("68", "Lâm Đồng", "Tỉnh", "Trung", "Tây Nguyên", .9),
    ("70", "Bình Phước", "Tỉnh", "Nam", "Đông Nam Bộ", .6), ("72", "Tây Ninh", "Tỉnh", "Nam", "Đông Nam Bộ", .7),
    ("74", "Bình Dương", "Tỉnh", "Nam", "Đông Nam Bộ", 3.0), ("75", "Đồng Nai", "Tỉnh", "Nam", "Đông Nam Bộ", 2.8),
    ("77", "Bà Rịa - Vũng Tàu", "Tỉnh", "Nam", "Đông Nam Bộ", 1.1), ("79", "Hồ Chí Minh", "Thành phố Trung ương", "Nam", "Đông Nam Bộ", 22.0),
    ("80", "Long An", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", 1.0), ("82", "Tiền Giang", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .9),
    ("83", "Bến Tre", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .6), ("84", "Trà Vinh", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .5),
    ("86", "Vĩnh Long", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .5), ("87", "Đồng Tháp", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .7),
    ("89", "An Giang", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .9), ("91", "Kiên Giang", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .8),
    ("92", "Cần Thơ", "Thành phố Trung ương", "Nam", "Đồng bằng sông Cửu Long", 1.3), ("93", "Hậu Giang", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .35),
    ("94", "Sóc Trăng", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .5), ("95", "Bạc Liêu", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .35),
    ("96", "Cà Mau", "Tỉnh", "Nam", "Đồng bằng sông Cửu Long", .5),
]
# cách viết "bẩn" của tên tỉnh trong province_name_raw (giống dữ liệu nhập tay / từ sàn)
PROVINCE_ALIASES = {
    "79": ["TP. Hồ Chí Minh", "TP.HCM", "Hồ Chí Minh", "Ho Chi Minh City", "tp hcm", "Sài Gòn"],
    "01": ["Hà Nội", "TP. Hà Nội", "Ha Noi", "hà nội", "HN"],
    "48": ["Đà Nẵng", "TP Đà Nẵng", "Da Nang"],
    "46": ["Thừa Thiên Huế", "Huế", "TT Huế"],
    "77": ["Bà Rịa - Vũng Tàu", "Bà Rịa Vũng Tàu", "BR-VT"],
    "31": ["Hải Phòng", "TP Hải Phòng", "Hai Phong"],
}

# ------------------------------------------------------------------ trạng thái đơn (mã giữ theo hệ thống gốc)
ORDER_STATUS = [  # code, name, group, is_demand, is_net_sale, is_delivered, is_cancelled, is_returned, is_final
    (54, "Mới", "processing", 1, 1, 0, 0, 0, 0), (56, "Đã xác nhận", "processing", 1, 1, 0, 0, 0, 0),
    (42, "Đang đóng gói", "processing", 1, 1, 0, 0, 0, 0), (40, "Đã đóng gói", "processing", 1, 1, 0, 0, 0, 0),
    (59, "Đang chuyển", "shipping", 1, 1, 0, 0, 0, 0), (60, "Thành công", "success", 1, 1, 1, 0, 0, 1),
    (61, "Thất lạc", "lost", 1, 0, 0, 0, 0, 1), (63, "Khách hủy", "cancelled", 0, 0, 0, 1, 0, 1),
    (64, "Hệ thống / sàn hủy", "cancelled", 0, 0, 0, 1, 0, 1), (71, "Đang chuyển hoàn", "returning", 1, 0, 0, 0, 1, 0),
    (72, "Đã chuyển hoàn", "returned", 1, 0, 0, 0, 1, 1), (74, "Xác nhận hoàn", "returned", 1, 0, 0, 0, 1, 1),
]
CANCEL_REASONS = {63: [(1, "Khách đổi ý"), (2, "Đặt nhầm sản phẩm"), (3, "Thời gian giao lâu")],
                  64: [(11, "Hết hàng"), (12, "Quá hạn xác nhận"), (13, "Nghi ngờ gian lận")]}
RETURN_REASONS = [(21, "Không nhận hàng / bom hàng"), (22, "Sản phẩm lỗi"), (23, "Sai màu / sai mẫu"), (24, "Không giống mô tả")]

MOVEMENT_TYPES = [  # bill_type, bill_mode, movement_name, movement_category, direction
    (1, 1, "Nhập mua hàng", "purchase", 1), (1, 2, "Nhập hàng hoàn", "return_in", 1), (1, 3, "Nhập chuyển kho", "transfer_in", 1),
    (1, 4, "Nhập điều chỉnh kiểm kê", "adjustment", 1), (2, 1, "Xuất bán hàng", "sale", -1), (2, 2, "Xuất trả nhà cung cấp", "return_out", -1),
    (2, 3, "Xuất chuyển kho", "transfer_out", -1), (2, 4, "Xuất điều chỉnh kiểm kê", "adjustment", -1), (2, 5, "Xuất hủy hàng lỗi", "write_off", -1),
]

# ------------------------------------------------------------------ lịch sự kiện
TET = {2021: "2021-02-12", 2022: "2022-02-01", 2023: "2023-01-22", 2024: "2024-02-10", 2025: "2025-01-29", 2026: "2026-02-17"}


def events():
    ev = []
    for y in range(2021, 2027):
        for m in range(1, 13):
            if m <= 12 and (y < 2026 or m <= 9):
                big = m in (9, 10, 11, 12)
                ev.append((f"DD{m:02d}{m:02d}", y, f"Ngày đôi {m}.{m}", "double_day", "all", f"{y}-{m:02d}-{m:02d}", 2, 1, 1 if big else 2))
                ev.append((f"PAYDAY25_{m:02d}", y, f"Sale giữa/cuối tháng 25/{m}", "payday", "all", f"{y}-{m:02d}-25", 1, 1, 3))
        ev.append(("TET", y, "Tết Nguyên Đán", "holiday", "all", TET[y], 10, 6, 1))
        ev.append(("WD0803", y, "Quốc tế Phụ nữ 8/3", "gifting", "all", f"{y}-03-08", 5, 0, 2))
        if y < 2026:
            ev.append(("WD2010", y, "Phụ nữ Việt Nam 20/10", "gifting", "all", f"{y}-10-20", 5, 0, 2))
            bf = {2021: "2021-11-26", 2022: "2022-11-25", 2023: "2023-11-24", 2024: "2024-11-29", 2025: "2025-11-28"}[y]
            ev.append(("BLACKFRIDAY", y, "Black Friday", "mega_sale", "all", bf, 1, 3, 2))
        ev.append(("BRAND_BDAY", y, "Sinh nhật thương hiệu", "brand", "website", f"{y}-07-15", 3, 3, 2))
    return ev
