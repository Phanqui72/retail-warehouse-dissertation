"""VN Beauty Orders Dataset generator (100% dữ liệu sinh, cấu trúc thuộc tính theo hệ thống thật).

python gen.py --out out_full            # toàn bộ 2021-01-01 .. 2026-09-30 (~300k đơn)
python gen.py --out out_small --scale 0.02
Tất cả timestamp là giờ Việt Nam (Asia/Ho_Chi_Minh), dạng 'YYYY-MM-DD HH:MM:SS' (trừ các dòng bị tiêm lỗi định dạng).
"""
import argparse, hashlib, math, os, random
from collections import defaultdict
from datetime import date, datetime, timedelta
import numpy as np
import pandas as pd
import catalog as C

P = argparse.ArgumentParser()
P.add_argument("--out", default="out_full")
P.add_argument("--scale", type=float, default=1.0)
P.add_argument("--seed", type=int, default=2026)
P.add_argument("--no-issues", action="store_true")
A = P.parse_args()
rng = np.random.default_rng(A.seed)
random.seed(A.seed)
PFX = "vn_beauty_"
D = lambda s: datetime.strptime(s, "%Y-%m-%d").date() if isinstance(s, str) else s
fmt = lambda t: t.strftime("%Y-%m-%d %H:%M:%S") if t is not None else None
hx = lambda *a: hashlib.md5("|".join(map(str, a)).encode()).hexdigest()


def weighted(items, weights):
    w = np.asarray(weights, float)
    return items[rng.choice(len(items), p=w / w.sum())]

# =================================================================== 1. master data
prod_rows, attr_rows, line_of, comps = [], [], {}, {}
pid = 30000
code_to_pid = {}
for (lc, lname, brand, cat2, mat, shape, launch, retail, cr, wg, pop, rbase, variants) in C.L:
    for i, v in enumerate(variants, 1):
        pid += 1
        code = f"{lc}-{i:02d}"
        a = dict(color=v.get("color"), material=v.get("material", mat), shape=v.get("shape", shape),
                 size=v.get("size"), pack_qty=v.get("pack_qty", 1))
        vlabel = " / ".join(str(x) for x in [a["color"], a["size"], (f"{a['pack_qty']} cái" if a["pack_qty"] > 1 else None),
                                              v.get("material"), v.get("shape")] if x)
        price = v.get("price", retail)
        mult = 1.0
        for k in ("color", "size", "pack_qty", "material", "shape"):
            mult *= C.ATTR_DEMAND.get(k, {}).get(a[k], 1.0)
        rating = rbase + sum(C.ATTR_RATING.get(k, {}).get(a[k], 0) for k in ("color", "material"))
        launch_d = D(launch) + timedelta(days=int(rng.integers(0, 60)) if i > 1 else 0)
        disc = C.DISCONTINUED.get(code)
        prod_rows.append(dict(
            product_id=pid, product_code=code, barcode=f"893{rng.integers(10**9, 10**10 - 1)}",
            product_name=f"{lname} {brand.split()[0]} - {vlabel}" if vlabel else f"{lname} {brand.split()[0]}",
            product_type_code=1, product_status_code=2 if disc else 1, parent_code=lc, parent_name=lname,
            brand_id=C.BRAND_ID[brand], category_id=C.CAT_ID[cat2],
            attr_color=a["color"], attr_material=a["material"], attr_shape=a["shape"], attr_size=a["size"], attr_pack_qty=a["pack_qty"],
            retail_price=price, import_price=int(round(price * cr / 100) * 100), avg_cost=None,
            wholesale_price=int(round(price * 0.8 / 1000) * 1000), weight_gram=wg * (a["pack_qty"] if lc.startswith(("BTT", "KT")) else 1),
            created_at=fmt(datetime.combine(launch_d, datetime.min.time()) + timedelta(hours=9, minutes=int(rng.integers(0, 480)))),
            updated_at=None, discontinued_date=disc,
            _pop=pop * mult / len(variants) ** 0.3, _rating=rating, _launch=launch_d, _disc=D(disc) if disc else None, _cat2=cat2))
        code_to_pid[code] = pid
        line_of[pid] = lc
        for k in ("color", "material", "shape", "size", "pack_qty"):
            if a[k] is not None and not (k == "pack_qty" and a[k] == 1):
                attr_rows.append(dict(product_id=pid, product_code=code, attribute_name=k, attribute_value=str(a[k])))
line_variants = defaultdict(list)
for r in prod_rows:
    line_variants[r["parent_code"]].append(r["product_id"])
for (cc, cname, parts, launch, price) in C.COMBOS:
    pid += 1
    comp = [(line_variants[lc][vi], q) for lc, vi, q in parts]
    cost = sum(next(r for r in prod_rows if r["product_id"] == p)["import_price"] * q for p, q in comp)
    disc = C.DISCONTINUED.get(cc)
    prod_rows.append(dict(
        product_id=pid, product_code=cc, barcode=f"893{rng.integers(10**9, 10**10 - 1)}", product_name=cname,
        product_type_code=4, product_status_code=2 if disc else 1, parent_code=None, parent_name=None,
        brand_id=101, category_id=C.CAT_ID["Combo"], attr_color=None, attr_material=None, attr_shape=None, attr_size=None,
        attr_pack_qty=sum(q for _, q in comp), retail_price=price, import_price=cost, avg_cost=None,
        wholesale_price=int(round(price * 0.85 / 1000) * 1000),
        weight_gram=sum(next(r for r in prod_rows if r["product_id"] == p)["weight_gram"] * q for p, q in comp),
        created_at=fmt(datetime.combine(D(launch), datetime.min.time()) + timedelta(hours=10)), updated_at=None,
        discontinued_date=disc, _pop=1.6, _rating=4.7, _launch=D(launch), _disc=D(disc) if disc else None, _cat2="Combo"))
    comps[pid] = comp
    code_to_pid[cc] = pid
products = pd.DataFrame(prod_rows)
P_BY = {r["product_id"]: r for r in prod_rows}
SINGLES = [r["product_id"] for r in prod_rows if r["product_type_code"] == 1]

# giá niêm yết tăng theo năm
PRICE_IDX = {2021: 0.92, 2022: 0.95, 2023: 1.0, 2024: 1.0, 2025: 1.05, 2026: 1.08}

prov = pd.DataFrame(C.PROVINCES, columns=["province_code", "province_name", "province_type", "region", "economic_region", "_w"])
PROV_CODES = prov.province_code.tolist()
PROV_W = prov._w.to_numpy() / prov._w.sum()
PROV_REG = dict(zip(prov.province_code, prov.region))
PROV_NAME = dict(zip(prov.province_code, prov.province_name))

SHOP = {s[0]: s for s in C.SHOPS}
ev_rows = C.events()
EV_MULT = defaultdict(lambda: 1.0)
for (code, y, name, etype, plat, anchor, wb, wa, prio) in ev_rows:
    a = D(anchor)
    peak = {"double_day": 3.2 if a.month in (9, 10, 11, 12) else 2.0, "payday": 1.35, "mega_sale": 2.2, "gifting": 1.4,
            "holiday": 0.45, "brand": 1.3}[etype]
    for k in range(-wb, wa + 1):
        d = a + timedelta(days=k)
        f = peak if k == 0 else (1 + (peak - 1) * 0.3 if etype != "holiday" else peak)
        if etype == "holiday" and k < -7:
            f = 1.25  # mua sắm trước Tết
        EV_MULT[d] = max(EV_MULT[d], f) if f >= 1 else min(EV_MULT[d], f)

# =================================================================== 2. số đơn mỗi ngày
days = [C.START + timedelta(days=i) for i in range((C.END - C.START).days + 1)]
WD = [1.0, 0.97, 0.96, 0.98, 1.0, 1.08, 1.12]
raw = np.array([WD[d.weekday()] * EV_MULT[d] * (1 + 0.35 * (d.timetuple().tm_yday / 366)) for d in days])
cnt = np.zeros(len(days), int)
for y, tot in C.ORDERS_PER_YEAR.items():
    idx = [i for i, d in enumerate(days) if d.year == y]
    lam = raw[idx] / raw[idx].sum() * tot * A.scale
    cnt[idx] = rng.poisson(lam)
print("orders planned", cnt.sum())

# =================================================================== 3. mô phỏng theo ngày (đơn + kho)
HOUR_W = np.array([2, 1, .5, .3, .2, .3, .8, 1.5, 2.5, 3.2, 3.5, 3.8, 4.5, 4.0, 3.4, 3.2, 3.2, 3.4, 3.8, 4.6, 5.5, 5.8, 5.0, 3.5])
HOUR_W /= HOUR_W.sum()
CARRIER_BY = {"shopee": [14, 11, 13], "tiktok": [13, 11, 14], "lazada": [16, 11, 13], "website": [12, 11, 15], "social": [12, 15, 11],
              "offline": [17]}
FEE = {"shopee": {2021: .06, 2022: .08, 2023: .10, 2024: .13, 2025: .15, 2026: .16}, "tiktok": {2022: .03, 2023: .06, 2024: .10, 2025: .13, 2026: .14},
       "lazada": {2021: .07, 2022: .08, 2023: .10, 2024: .12, 2025: .13, 2026: .14}}
DEPOT_OPEN = {w[0]: D(w[7]) for w in C.WAREHOUSES}
LEAD = {}
for r in prod_rows:
    if r["product_type_code"] == 1:
        sid = C.SUPPLIER_BY_CAT.get(r["_cat2"], 502 if "Cọ" in r["_cat2"] or "cọ" in r["_cat2"] else 503)
        r["_supplier"] = sid
        LEAD[r["product_id"]] = next(s[3] for s in C.SUPPLIERS if s[0] == sid)

on_hand = defaultdict(int); reserved = defaultdict(int); shipping = defaultdict(int); transferring = defaultdict(int)
cost = {p: P_BY[p]["import_price"] for p in SINGLES}           # giá vốn bình quân (moving average)
demand_hist = defaultdict(lambda: np.zeros(28))                 # nhu cầu 28 ngày gần nhất theo (depot, sku)
pending = defaultdict(list)                                    # day -> events
open_po = {}
orders, items, pays, hist, moves, snaps, pos, counts = [], [], [], [], [], [], [], []
cust_pool = []                                                  # (unique_id, province)
bill_seq, line_seq, po_seq, oid = [700000], [1], [9000], 1_000_000
cust_seq = [0]


def new_bill():
    bill_seq[0] += 1
    return bill_seq[0]


def move(day, ts, btype, bmode, depot, p, q, order_id=None, rel=None, supplier=None, check=None, po=None, bill=None, price=None, from_bundle=False):
    line_seq[0] += 1
    moves.append(dict(bill_line_id=line_seq[0], bill_id=bill or new_bill(), bill_type=btype, bill_mode=bmode, movement_date=day.isoformat(),
                      created_at=fmt(ts), depot_id=depot, related_depot_id=rel, product_id=p, product_code=P_BY[p]["product_code"],
                      quantity=int(q), avg_cost=int(cost[p]), product_price=price, discount_amount=0 if price else None,
                      order_id=order_id, supplier_id=supplier, inventory_check_id=check, po_id=po, is_from_bundle=from_bundle))


def expand(p, q):
    return [(c, cq * q) for c, cq in comps[p]] if p in comps else [(p, q)]


def avail(dep, p):
    return on_hand[(dep, p)] - reserved[(dep, p)]


# tồn đầu kỳ 2021-01-01
for p in SINGLES:
    if P_BY[p]["_launch"] <= C.START + timedelta(days=30):
        for dep, share in ((1, .45), (2, .55)):
            q = int(max(30, P_BY[p]["_pop"] * 120 * A.scale ** 0.5 * share))
            on_hand[(dep, p)] += q
            move(C.START, datetime(2021, 1, 1, 7, 0), 1, 4, dep, p, q, check="OPENING-2021")


def pick_products(shop, d, n):
    plat = SHOP[shop][2]
    cand, w = [], []
    for r in prod_rows:
        if r["_launch"] > d or (r["_disc"] and r["_disc"] < d):
            continue
        if shop == "SHP_02" and r["brand_id"] != 102 and r["product_type_code"] == 1:
            continue
        ww = r["_pop"]
        if plat == "tiktok" and r["retail_price"] <= 70000:
            ww *= 1.6
        if plat in ("website", "offline") and r["retail_price"] >= 190000:
            ww *= 1.5
        if d.month in (2, 3, 10, 11, 12) and r["product_type_code"] == 4:
            ww *= 1.8  # mùa quà tặng
        cand.append(r["product_id"]); w.append(ww)
    w = np.asarray(w, float)
    if not np.isfinite(w).all(): raise SystemExit([(c_, x) for c_, x in zip(cand, w) if not np.isfinite(x)])
    if len(cand)==0 or w.sum()<=0: raise SystemExit(f'empty cand {shop} {d} {len(cand)} {w.sum()}')
    w = w / w.sum()
    return list(rng.choice(cand, size=min(n, len(cand)), replace=False, p=w))


def plan_depot(shop, province, d):
    reg = PROV_REG[province]
    if SHOP[shop][2] == "offline":
        return 1
    if SHOP[shop][2] in ("shopee", "tiktok") and reg == "Nam" and d >= DEPOT_OPEN[3] and rng.random() < .45:
        return 3
    return 1 if reg == "Bắc" else 2


po_lines = []


def po_review(day):
    """Đặt hàng lại hằng tuần tại kho tổng 1, 2."""
    by_sup = defaultdict(list)
    for dep in (1, 2):
        for p in SINGLES:
            r = P_BY[p]
            if r["_launch"] > day + timedelta(days=LEAD[p] + 10) or (r["_disc"] and r["_disc"] < day + timedelta(days=60)):
                continue
            if (dep, p) in open_po:
                continue
            dd = demand_hist[(dep, p)].mean() + (demand_hist[(3, p)].mean() * .5 if dep == 2 else 0)
            dd = max(dd, 0.05 * A.scale ** 0.5)
            lead = LEAD[p]
            rop = dd * (lead + 10)
            if on_hand[(dep, p)] + transferring[(dep, p)] - reserved[(dep, p)] < rop:
                q = int(math.ceil(dd * (lead + 35) / 10) * 10)
                by_sup[(r["_supplier"], dep)].append((p, q))
    for (sid, dep), lines in by_sup.items():
        po_seq[0] += 1
        po = f"PO{day.strftime('%y%m')}-{po_seq[0]}"
        lead = next(s[3] for s in C.SUPPLIERS if s[0] == sid)
        delay = int(max(-2, rng.normal(1.5, 3 if sid in (502, 503) else 1.5)))
        arr = day + timedelta(days=lead + delay)
        for k, (p, q) in enumerate(lines, 1):
            rq = q if rng.random() > .12 else int(q * rng.uniform(.85, 1.0))
            unit = int(P_BY[p]["import_price"] * PRICE_IDX[day.year] * rng.uniform(.97, 1.03))
            po_lines.append(dict(po_id=po, po_line_id=f"{po}-{k:02d}", supplier_id=sid, depot_id=dep, product_id=p,
                                 product_code=P_BY[p]["product_code"], order_qty=q, unit_cost=unit, order_date=day.isoformat(),
                                 expected_date=(day + timedelta(days=lead)).isoformat(),
                                 received_date=arr.isoformat() if arr <= C.END else None,
                                 received_qty=rq if arr <= C.END else None, po_status="received" if arr <= C.END else "open"))
            open_po[(dep, p)] = po
            if arr <= C.END:
                pending[arr].append(("po_in", dep, p, rq, unit, sid, po))


fbs_review_days = set()
for di, day in enumerate(days):
    # ---------------- sự kiện đến hạn trong ngày
    for ev in sorted(pending.pop(day, []), key=lambda e: {"po_in": 0, "tr_in": 0}.get(e[0], 1)):
        kind = ev[0]
        if kind == "po_in":
            _, dep, p, q, unit, sid, po = ev
            tot = on_hand[(dep, p)]
            cost[p] = (cost[p] * max(tot, 0) + unit * q) / max(tot + q, 1)
            on_hand[(dep, p)] += q
            open_po.pop((dep, p), None)
            move(day, datetime.combine(day, datetime.min.time()) + timedelta(hours=int(rng.integers(8, 17))), 1, 1, dep, p, q,
                 supplier=sid, po=po, price=unit)
        elif kind == "tr_in":
            _, src, dst, p, q, bill = ev
            transferring[(dst, p)] -= q
            on_hand[(dst, p)] += q
            move(day, datetime.combine(day, datetime.min.time()) + timedelta(hours=10), 1, 3, dst, p, q, rel=src, bill=bill)
        elif kind == "pack":
            _, o, ts = ev
            bill = new_bill()
            for (p, q, from_b, dep) in o["_alloc"]:
                reserved[(dep, p)] -= q; on_hand[(dep, p)] -= q; shipping[(dep, p)] += q
                move(day, ts, 2, 1, dep, p, q, order_id=o["order_id"], bill=bill, price=None, from_bundle=from_b)
        elif kind == "release":       # hủy trước khi đóng gói
            _, o = ev
            for (p, q, _, dep) in o["_alloc"]:
                reserved[(dep, p)] -= q
        elif kind == "delivered":
            _, o = ev
            for (p, q, _, dep) in o["_alloc"]:
                shipping[(dep, p)] -= q
        elif kind == "return_in":
            _, o, ts = ev
            bill = new_bill()
            for (p, q, from_b, dep) in o["_alloc"]:
                shipping[(dep, p)] -= q
                dst = dep if rng.random() < .85 else 4
                on_hand[(dst, p)] += q
                move(day, ts, 1, 2, dst, p, q, order_id=o["order_id"], bill=bill, from_bundle=from_b)
    # ---------------- đơn mới
    n = cnt[di]
    yr = day.year
    mix = {k: v for k, v in C.CHANNEL_MIX[yr].items() if D(SHOP[k][6]) <= day}
    shops_k, shops_w = list(mix), list(mix.values())
    is_event = EV_MULT[day] > 1.5
    for _ in range(n):
        oid += 1
        shop = weighted(shops_k, shops_w)
        plat = SHOP[shop][2]
        hour = int(rng.choice(24, p=HOUR_W)) if not (is_event and rng.random() < .25) else int(rng.integers(0, 2))
        created = datetime.combine(day, datetime.min.time()) + timedelta(hours=hour, minutes=int(rng.integers(0, 60)), seconds=int(rng.integers(0, 60)))
        # khách hàng (customer_id theo đơn, customer_unique_id theo người)
        if cust_pool and rng.random() < min(.12 + .04 * (yr - 2021), .32):
            uid, province = cust_pool[int(rng.integers(0, len(cust_pool)))]
        else:
            province = str(rng.choice(PROV_CODES, p=PROV_W)) if plat != "offline" else str(rng.choice(["01", "01", "01", "26", "27", "33"]))
            uid = hx("u", oid, province)
            cust_pool.append((uid, province))
        cust_seq[0] += 1
        customer_id = "c" + hx("c", oid)[:15]
        # dòng hàng
        k = 1 if rng.random() < .68 else (2 if rng.random() < .7 else int(rng.integers(3, 6)))
        prods = pick_products(shop, day, k)
        dep = plan_depot(shop, province, day)
        alloc, lines, stockout = [], [], False
        for p in prods:
            q = 1 if rng.random() < .78 else int(rng.integers(2, 5))
            parts = expand(p, q)
            dsel = dep
            if any(avail(dsel, c) < cq for c, cq in parts):
                alt = 2 if dep in (1, 3) else 1
                dsel = alt if all(avail(alt, c) >= cq for c, cq in parts) else None
            if dsel is None:
                stockout = True
                dsel = dep
            for c, cq in parts:
                alloc.append((c, cq, p in comps, dsel))
                demand_hist[(dep, c)][di % 28] += cq
            r = P_BY[p]
            list_price = int(round(r["retail_price"] * PRICE_IDX[yr] / 1000) * 1000)
            dpct = rng.uniform(.15, .35) if is_event else (rng.uniform(0, .12) if plat != "offline" else 0)
            unit = int(round(list_price * (1 - dpct) / 100) * 100)
            ldisc = int(round(unit * q * rng.uniform(.03, .08) / 100) * 100) if (plat in ("website", "social") and rng.random() < .1) else 0
            lines.append(dict(order_id=oid, product_id=p, product_code=r["product_code"], quantity=q, original_price=list_price,
                              unit_price=unit, line_discount_amount=ldisc, total_amount=unit * q - ldisc))
        order_dep = alloc[0][3]
        if not stockout:
            for c, cq, _, dd_ in alloc:
                reserved[(dd_, c)] += cq
        goods = sum(l["total_amount"] for l in lines)
        voucher = int(round(goods * rng.uniform(.03, .1) / 1000) * 1000) if (rng.random() < (.45 if is_event else .15)) else 0
        cship = 0 if (plat in ("shopee", "tiktok", "lazada", "offline") or goods >= 299000) else 30000
        pay_total = goods - voucher + cship
        # phương thức thanh toán
        cod_share = {2021: .7, 2022: .65, 2023: .58, 2024: .52, 2025: .48, 2026: .45}[yr]
        if plat == "offline":
            ptype = weighted(np.array(["cash", "card", "bank_transfer"]), [.5, .2, .3])
        elif plat in ("website", "social"):
            ptype = "cod" if rng.random() < cod_share + .15 else "bank_transfer"
        else:
            ptype = "cod" if rng.random() < cod_share else weighted(np.array(["e_wallet", "card", "bank_transfer"]), [.65, .2, .15])
        deposit = int(round(pay_total * .3 / 1000) * 1000) if (plat == "social" and ptype == "cod" and pay_total > 400000 and rng.random() < .5) else 0
        # kết cục đơn
        u = rng.random()
        recent = (C.END - day).days
        if stockout:
            final = 64; reason = 11
        elif u < (.045 if plat != "offline" else 0):
            final = 63; reason = weighted(np.array([1, 2, 3]), [5, 3, 2])
        elif u < (.075 if plat != "offline" else 0):
            final = 64; reason = weighted(np.array([12, 13]), [8, 2])
        elif u < .075 + (.065 if ptype == "cod" else .02) * (plat != "offline"):
            final = 74 if rng.random() < .5 else 72; reason = weighted(np.array([21, 22, 23, 24]), [6, 1.5, 1.5, 1])
        elif u < .078 + (.065 if ptype == "cod" else .02):
            final = 61; reason = None
        else:
            final = 60; reason = None
        carrier = 17 if plat == "offline" else int(weighted(np.array(CARRIER_BY[plat]), [.6, .25, .15][:len(CARRIER_BY[plat])]))
        # dòng thời gian trạng thái
        t = created
        seq = [(54, t)]
        t_conf = t + timedelta(minutes=int(rng.integers(5, 240)))
        packed_at = delivered_at = None
        if final == 64 and reason == 11:
            seq.append((64, t + timedelta(minutes=int(rng.integers(20, 300)))))
        elif final in (63, 64):
            seq.append((56, t_conf))
            seq.append((final, t_conf + timedelta(minutes=int(rng.integers(10, 1500)))))
        else:
            seq.append((56, t_conf))
            start_pack = t_conf if t_conf.hour < 17 else datetime.combine(t_conf.date() + timedelta(days=1), datetime.min.time()) + timedelta(hours=8)
            if is_event:
                start_pack += timedelta(hours=float(rng.uniform(4, 30)))
            seq.append((42, start_pack + timedelta(minutes=int(rng.integers(5, 120)))))
            packed_at = seq[-1][1] + timedelta(minutes=int(rng.integers(10, 180)))
            seq.append((40, packed_at))
            if plat == "offline":
                delivered_at = packed_at + timedelta(minutes=5)
                seq.append((60, delivered_at))
            else:
                ship = packed_at + timedelta(hours=float(rng.uniform(1, 8)))
                seq.append((59, ship))
                same = PROV_REG[province] == ("Bắc" if order_dep in (1, 4) else "Nam")
                tdays = rng.gamma(2.2, .7 if same else 1.4) + (1.2 if PROV_REG[province] == "Trung" else 0)
                arrive = ship + timedelta(days=float(tdays))
                if final == 60:
                    delivered_at = arrive; seq.append((60, arrive))
                elif final == 61:
                    seq.append((61, arrive + timedelta(days=float(rng.uniform(7, 20)))))
                else:
                    r71 = arrive + timedelta(days=float(rng.uniform(1, 3)))
                    seq.append((71, r71))
                    r72 = r71 + timedelta(days=float(rng.uniform(2, 7)))
                    seq.append((72, r72))
                    if final == 74:
                        seq.append((74, r72 + timedelta(days=float(rng.uniform(.5, 3)))))
        end_dt = datetime.combine(C.END, datetime.min.time()) + timedelta(hours=23, minutes=59)
        seq = [(s, ts) for s, ts in seq if ts <= end_dt]
        status = seq[-1][0]
        if packed_at and packed_at > end_dt:
            packed_at = None
        if delivered_at and delivered_at > end_dt:
            delivered_at = None
        o = dict(order_id=oid, customer_id=customer_id, marketplace_order_sn=(hx("sn", oid)[:14].upper() if plat in ("shopee", "tiktok", "lazada") else None),
                 order_type_code=1 if plat != "offline" else 2, order_mode_code={"shopee": 6, "tiktok": 6, "lazada": 6, "website": 2, "social": 1, "offline": 3}[plat],
                 status_code=status, reason_code=reason if status in (63, 64, 71, 72, 74) else None, original_order_id=None,
                 depot_id=order_dep, sale_channel=SHOP[shop][1], shop_code=shop, carrier_id=carrier if status not in (63, 64) or packed_at else None,
                 created_at=fmt(created), packed_at=fmt(packed_at), delivered_at=fmt(delivered_at), updated_at=fmt(seq[-1][1]),
                 order_date=created.date().isoformat(), delivered_date=delivered_at.date().isoformat() if delivered_at else None,
                 cod_amount=(pay_total - deposit) if ptype == "cod" else 0, business_payment_amount=pay_total, order_discount_amount=voucher,
                 transfer_amount=pay_total if ptype in ("bank_transfer", "e_wallet", "card") else deposit, deposit_amount=deposit,
                 ecom_fee_amount=int(round(goods * FEE.get(plat, {}).get(yr, 0) / 100) * 100),
                 cod_fee_amount=int(round((pay_total - deposit) * .01 / 100) * 100) if (ptype == "cod" and plat in ("website", "social")) else 0,
                 customer_ship_fee_amount=cship,
                 ship_fee_amount=0 if plat in ("shopee", "tiktok", "lazada", "offline") else int(rng.choice([22000, 25000, 30000, 35000])),
                 return_fee_amount=int(rng.choice([0, 15000, 22000])) if status in (72, 74) else 0,
                 weight_gram=sum(P_BY[l["product_id"]]["weight_gram"] * l["quantity"] for l in lines) + 30,
                 province_code=province, province_name_raw=None, gift_count=int(is_event and rng.random() < .2))
        o["_alloc"] = alloc
        o["_uid"] = uid
        aliases = C.PROVINCE_ALIASES.get(province)
        o["province_name_raw"] = (random.choice(aliases) if aliases and rng.random() < .5 else PROV_NAME[province])
        orders.append(o)
        for i, l in enumerate(lines, 1):
            l.update(order_product_id=int(f"{oid}{i:02d}"), avg_cost=int(sum(cost[c] * cq for c, cq in expand(l["product_id"], 1))),
                     partial_return_status=0, order_updated_at=o["updated_at"])
            items.append(l)
        for s, ts in seq:
            hist.append(dict(order_id=oid, status_code=s, changed_at=fmt(ts),
                             changed_by="system" if s in (54, 61) else ("marketplace" if plat in ("shopee", "tiktok", "lazada") and s in (59, 60, 64, 71, 72) else "staff")))
        # sự kiện kho
        if not stockout:
            if packed_at:
                pending[packed_at.date()].append(("pack", o, packed_at))
                if delivered_at:
                    pending[delivered_at.date()].append(("delivered", o))
                elif status == 61:
                    pending[seq[-1][1].date()].append(("delivered", o))
                elif status in (72, 74):
                    t72 = next(ts for s, ts in seq if s == 72)
                    pending[t72.date()].append(("return_in", o, t72))
            elif status in (63, 64):
                pending[seq[-1][1].date()].append(("release", o))
        # thanh toán
        ps = []
        if deposit:
            ps.append(("bank_transfer", deposit)); ps.append(("cod", pay_total - deposit))
        else:
            ps.append((ptype, pay_total))
        if voucher and plat in ("shopee", "tiktok", "lazada") and rng.random() < .5:
            ps.append(("platform_voucher", int(voucher * rng.uniform(.3, 1))))
        for k2, (pt, amt) in enumerate(ps, 1):
            pstat = "refunded" if status in (63, 64, 72, 74) and pt != "cod" else ("cancelled" if status in (63, 64) else
                                                                                     ("collected" if status == 60 else "pending"))
            pays.append(dict(order_id=oid, payment_sequential=k2, payment_type=pt, payment_amount=int(amt), payment_status=pstat,
                             paid_at=fmt(created + timedelta(minutes=2)) if pt not in ("cod", "cash") else fmt(delivered_at)))
    # ---------------- chuyển kho FBS + đặt hàng + kiểm kê
    if day >= DEPOT_OPEN[3] and day.weekday() == 0:
        bill = new_bill()
        for p in SINGLES:
            need = demand_hist[(3, p)].mean() * 14 - on_hand[(3, p)] - transferring[(3, p)] + reserved[(3, p)]
            q = int(min(need, max(avail(2, p) - demand_hist[(2, p)].mean() * 7, 0)))
            if q >= 5:
                on_hand[(2, p)] -= q; transferring[(3, p)] += q
                move(day, datetime.combine(day, datetime.min.time()) + timedelta(hours=9), 2, 3, 2, p, q, rel=3, bill=bill)
                pending[day + timedelta(days=2)].append(("tr_in", 2, 3, p, q, bill))
    if day.weekday() == 2:
        po_review(day)
    if day.day == 28 and day.month in (3, 6, 9, 12):
        chk = f"KK{day.strftime('%Y%m')}"
        for dep in (1, 2):
            bill_p, bill_m = new_bill(), new_bill()
            for p in SINGLES:
                sysq = on_hand[(dep, p)]
                if sysq <= 0 and P_BY[p]["_launch"] > day:
                    continue
                diff = int(rng.choice([0, 0, 0, 0, -1, -2, 1, -3])) if sysq > 20 else 0
                counts.append(dict(inventory_check_id=chk, count_date=day.isoformat(), depot_id=dep, product_id=p,
                                   product_code=P_BY[p]["product_code"], system_qty=sysq, counted_qty=sysq + diff, diff_qty=diff,
                                   counted_by=f"NV{int(rng.integers(1, 9)):02d}"))
                if diff:
                    on_hand[(dep, p)] += diff
                    move(day, datetime.combine(day, datetime.min.time()) + timedelta(hours=18), 1 if diff > 0 else 2, 4, dep, p, abs(diff),
                         check=chk, bill=bill_p if diff > 0 else bill_m)
    if day.day == 1 and on_hand:  # hủy hàng lỗi trong kho hoàn mỗi tháng
        bill = new_bill()
        for p in SINGLES:
            q = on_hand[(4, p)]
            if q > 0:
                on_hand[(4, p)] = 0
                move(day, datetime.combine(day, datetime.min.time()) + timedelta(hours=15), 2, 5, 4, p, q, bill=bill)
    # ---------------- snapshot cuối ngày
    for dep in (1, 2, 3, 4):
        if DEPOT_OPEN[dep] > day:
            continue
        for p in SINGLES:
            if P_BY[p]["_launch"] > day:
                continue
            k_ = (dep, p)
            if dep in (3, 4) and on_hand[k_] == 0 and reserved[k_] == 0 and shipping[k_] == 0 and transferring[k_] == 0:
                continue
            snaps.append((day.isoformat(), dep, p, on_hand[k_], on_hand[k_] - reserved[k_], reserved[k_], shipping[k_], transferring[k_], int(cost[p])))
    demand_hist_keys = list(demand_hist.keys())
    for k_ in demand_hist_keys:
        demand_hist[k_][(di + 1) % 28] = 0
print("orders", len(orders), "items", len(items), "moves", len(moves), "snaps", len(snaps))

# =================================================================== 4. bảng phụ thuộc đơn
odf = pd.DataFrame([{k: v for k, v in o.items() if not k.startswith("_")} for o in orders])
idf = pd.DataFrame(items)
cust = pd.DataFrame([dict(customer_id=o["customer_id"], customer_unique_id=o["_uid"], customer_province_code=o["province_code"],
                          customer_province_name_raw=o["province_name_raw"], first_seen_channel=o["shop_code"]) for o in orders])
# order_status_history, payments
hdf = pd.DataFrame(hist)
pdf = pd.DataFrame(pays)

# listings (item = dòng sản phẩm / combo, model = biến thể)
listings = []
item_seq = 2_200_000_000
for shop in ("SHP_MALL", "SHP_02", "TTS_01", "LZD_01"):
    opened = D(SHOP[shop][6])
    groups = defaultdict(list)
    for r in prod_rows:
        if shop == "SHP_02" and r["brand_id"] != 102:
            continue
        if shop == "LZD_01" and r["_pop"] < 0.6 and r["product_type_code"] == 1:
            continue
        groups[r["parent_code"] or r["product_code"]].append(r)
    for g, rs in groups.items():
        item_seq += int(rng.integers(1000, 90000))
        for j, r in enumerate(rs):
            listings.append(dict(listing_id=f"{shop}:{item_seq}:{j + 1 if r['parent_code'] else 0}", platform=SHOP[shop][2], shop_code=shop,
                                 item_id=item_seq, model_id=(item_seq * 10 + j + 1) if r["parent_code"] else 0,
                                 listing_name=f"[{SHOP[shop][3]}] {r['parent_name'] or r['product_name']}" + (f" - {r['product_name'].split(' - ')[-1]}" if r["parent_code"] else ""),
                                 product_id=r["product_id"], sku=r["product_code"], qty_per_listing=1,
                                 listed_date=max(opened, r["_launch"]).isoformat(), delisted_date=r["discontinued_date"]))
ldf = pd.DataFrame(listings)
LMAP = {(l["shop_code"], l["product_id"]): l for l in listings}

# reviews
REV_POS = ["Mút mềm, tán nền mịn lắm, sẽ ủng hộ tiếp", "Hàng đẹp, đóng gói cẩn thận, giao nhanh", "Màu {c} xinh xỉu, đúng như hình",
           "Chất lượng tốt so với giá", "Shop tư vấn nhiệt tình, hàng y mô tả", "Lần thứ 3 mua rồi, vẫn ưng", "Giao hàng nhanh, sản phẩm ok"]
REV_MID = ["Hàng ổn nhưng giao hơi lâu", "Tạm được, màu {c} hơi khác ảnh", "Dùng được, không quá xuất sắc", "Đóng gói hơi sơ sài"]
REV_NEG = ["Cán cọ bị bong sơn sau 2 tuần", "Mút bị rách sau vài lần giặt", "Giao sai màu, đặt {c} mà nhận màu khác", "Hàng bị lỗi, shop phản hồi chậm",
           "Giao quá lâu, hộp bị móp", "Kẹp mi kẹp đau, không cong"]
revs = []
items_by_order = idf.groupby("order_id")
for o in orders:
    shop = o["shop_code"]
    if SHOP[shop][2] not in ("shopee", "tiktok", "lazada") or o["status_code"] != 60 or rng.random() > .36:
        continue
    lines = items_by_order.get_group(o["order_id"])
    for _, l in lines.head(2).iterrows():
        r = P_BY[l.product_id]
        lst = LMAP.get((shop, l.product_id))
        if lst is None:
            continue
        dl = (datetime.strptime(o["delivered_at"], "%Y-%m-%d %H:%M:%S") - datetime.strptime(o["created_at"], "%Y-%m-%d %H:%M:%S")).days
        mu = r["_rating"] - (0.35 if dl >= 5 else 0)
        star = int(np.clip(round(rng.normal(mu, .9)), 1, 5))
        if rng.random() < .03:
            star = 1
        c = r["attr_color"] or "này"
        has_text = rng.random() < (.55 if star >= 4 else .9)
        txt = (random.choice(REV_POS if star >= 4 else REV_MID if star == 3 else REV_NEG).format(c=c.lower()) if has_text else None)
        cr = datetime.strptime(o["delivered_at"], "%Y-%m-%d %H:%M:%S") + timedelta(days=float(rng.uniform(.2, 12)))
        if cr.date() > C.END:
            continue
        revs.append(dict(comment_id=int(9_000_000_000 + len(revs) * 7 + rng.integers(0, 7)), order_id=o["order_id"],
                         marketplace_order_sn=o["marketplace_order_sn"], shop_code=shop, item_id=lst["item_id"], model_id=lst["model_id"],
                         product_id=l.product_id, rating_star=star, comment_text=txt, image_count=int(rng.choice([0, 0, 0, 1, 2, 3])) if has_text else 0,
                         is_replied=bool(rng.random() < (.85 if star <= 3 else .35)), is_hidden=False, review_status_code=1,
                         created_at=fmt(cr), modified_at=fmt(cr + timedelta(days=float(rng.uniform(0, 3)))) if rng.random() < .05 else fmt(cr),
                         review_date=cr.date().isoformat()))
rdf = pd.DataFrame(revs)

# listing traffic daily (từ đơn thật của mô phỏng + phễu ngược)
o_small = odf[["order_id", "shop_code", "order_date", "status_code"]]
j = idf.merge(o_small, on="order_id")
j = j[j.shop_code.isin(["SHP_MALL", "SHP_02", "TTS_01", "LZD_01"])]
j["item_id"] = [LMAP[(s, p)]["item_id"] if (s, p) in LMAP else None for s, p in zip(j.shop_code, j.product_id)]
j = j.dropna(subset=["item_id"])
j["paid"] = ~j.status_code.isin([63, 64])
j["conf"] = j.status_code.isin([60, 59, 40, 42, 56])
for c_ in ("quantity", "total_amount"):
    j[f"paid_{c_}"] = j[c_] * j.paid; j[f"conf_{c_}"] = j[c_] * j.conf
j["paid_oid"] = j.order_id.where(j.paid); j["conf_oid"] = j.order_id.where(j.conf)
g = j.groupby(["order_date", "shop_code", "item_id"])
agg = g.agg(placed_orders=("order_id", "nunique"), placed_qty=("quantity", "sum"), placed_amount=("total_amount", "sum"),
            paid_orders=("paid_oid", "nunique"), paid_qty=("paid_quantity", "sum"), paid_amount=("paid_total_amount", "sum"),
            confirmed_orders=("conf_oid", "nunique"), confirmed_qty=("conf_quantity", "sum"), confirmed_amount=("conf_total_amount", "sum")).reset_index()
items_meta = {}
for l in listings:
    items_meta.setdefault((l["shop_code"], l["item_id"]), (l["listing_name"].split(" - ")[0], l["listed_date"], l["delisted_date"]))
grid = []
for (shop, item), (name, ld, dd) in items_meta.items():
    for d in pd.date_range(ld, dd or C.END.isoformat(), freq="D"):
        grid.append((d.date().isoformat(), shop, item, name))
tr = pd.DataFrame(grid, columns=["stat_date", "shop_code", "item_id", "item_name"]).merge(
    agg.rename(columns={"order_date": "stat_date"}), on=["stat_date", "shop_code", "item_id"], how="left").fillna(0)
n_ = len(tr)
cr = rng.uniform(.03, .08, n_); ctr = rng.uniform(.02, .05, n_)
clicks = np.maximum(np.round(tr.placed_orders / cr + rng.poisson(3, n_)), tr.placed_orders).astype(int)
tr["impressions"] = np.round(clicks / ctr).astype(int)
tr["unique_impressions"] = (tr.impressions * rng.uniform(.6, .8, n_)).astype(int)
tr["clicks"] = clicks
tr["unique_clicks"] = (clicks * rng.uniform(.75, .9, n_)).astype(int)
tr["search_clicks"] = (clicks * rng.uniform(.3, .6, n_)).astype(int)
tr["page_views"] = (clicks * rng.uniform(1.1, 1.6, n_)).astype(int)
tr["unique_visitors"] = tr.unique_clicks
tr["bounce_visitors"] = (tr.unique_visitors * rng.uniform(.35, .6, n_)).astype(int)
tr["likes"] = rng.poisson(np.maximum(clicks * .02, .1))
tr["add_to_cart_qty"] = np.maximum(np.round(tr.placed_qty * rng.uniform(1.6, 3.0, n_)), tr.placed_qty).astype(int)
tr["add_to_cart_buyers"] = np.maximum((tr.add_to_cart_qty * .8).astype(int), tr.placed_orders.astype(int))
for c_ in ("placed", "paid", "confirmed"):
    tr[f"{c_}_buyers"] = tr[f"{c_}_orders"]
tr["stat_period"] = "daily"; tr["item_status_code"] = 1; tr["display_tag"] = ""
cols_tr = ["stat_date", "shop_code", "stat_period", "item_id", "item_name", "item_status_code", "display_tag", "impressions", "unique_impressions",
           "clicks", "unique_clicks", "search_clicks", "page_views", "unique_visitors", "bounce_visitors", "likes", "add_to_cart_qty",
           "add_to_cart_buyers", "placed_orders", "placed_qty", "placed_amount", "placed_buyers", "paid_orders", "paid_qty", "paid_amount",
           "paid_buyers", "confirmed_orders", "confirmed_qty", "confirmed_amount", "confirmed_buyers"]
tr = tr[cols_tr]
for c_ in cols_tr[7:]:
    tr[c_] = tr[c_].astype(int)

# ads spend daily
gmv = odf[odf.shop_code.isin(["SHP_MALL", "SHP_02", "TTS_01", "LZD_01"])].groupby(["order_date", "shop_code"]).business_payment_amount.sum()
ads = []
for (d, shop), v in gmv.items():
    for ctype, share in (("search", .55), ("discovery", .3), ("livestream" if shop == "TTS_01" else "affiliate", .15)):
        acos = rng.uniform(.06, .14)
        spend = int(v * share * acos)
        clicks_ = int(spend / rng.uniform(900, 2500))
        ads.append(dict(stat_date=d, shop_code=shop, campaign_id=f"{shop}-{ctype[:3].upper()}", campaign_type=ctype, spend_amount=spend,
                        impressions=int(clicks_ / rng.uniform(.01, .03)), clicks=clicks_, ad_orders=int(v * share * .35 / 150000),
                        ad_gmv_amount=int(v * share * .35)))
adf = pd.DataFrame(ads)

# market prices (crawl hằng tuần từ 2023)
COMP_BRANDS = ["Glowie", "Bellamie", "Koko Beauty", "Sora Tools", "Puffy Lab"]
mitems = []
for k_ in range(30):
    cat2 = random.choice(["Mút tán nền", "Cọ nền & phấn", "Bộ cọ trang điểm", "Bông tẩy trang", "Kẹp mi", "Massage mặt"])
    base = {"Mút tán nền": 55000, "Cọ nền & phấn": 150000, "Bộ cọ trang điểm": 420000, "Bông tẩy trang": 35000, "Kẹp mi": 110000, "Massage mặt": 210000}[cat2]
    mitems.append(dict(market_item_id=5000 + k_, hasaki_sku=f"{int(rng.integers(100000, 999999))}", brand_name=random.choice(COMP_BRANDS),
                       category_name=cat2, item_name=f"{cat2} {random.choice(COMP_BRANDS)} #{k_ + 1}", base=base * rng.uniform(.7, 1.3), own=False))
for r in random.sample([r for r in prod_rows if r["product_type_code"] == 1 and r["brand_id"] == 101], 8):
    mitems.append(dict(market_item_id=6000 + r["product_id"] % 1000, hasaki_sku=f"{int(rng.integers(100000, 999999))}", brand_name="Velia Beauty",
                       category_name=r["_cat2"], item_name=r["product_name"], base=r["retail_price"] * 1.05, own=True))
mp = []
for it in mitems:
    bought = int(rng.integers(50, 3000)); rating_c = int(bought * .1)
    for d in pd.date_range("2023-01-02", C.END.isoformat(), freq="W-MON"):
        dd = d.date()
        ev = EV_MULT[dd] > 1.5 or EV_MULT[dd + timedelta(days=1)] > 1.5
        market_price = int(round(it["base"] * PRICE_IDX[dd.year] / 1000) * 1000)
        dp = rng.uniform(.2, .45) if ev else rng.uniform(0, .2)
        price = int(round(market_price * (1 - dp) / 1000) * 1000)
        sold = int(rng.poisson(15 * (2.5 if ev else 1)))
        bought += sold; rating_c += int(sold * .1)
        mp.append(dict(snapshot_date=dd.isoformat(), market_item_id=it["market_item_id"], platform="hasaki", hasaki_sku=it["hasaki_sku"],
                       item_name=it["item_name"], brand_name=it["brand_name"], category_name=it["category_name"], is_own_product=it["own"],
                       price=price, market_price=market_price, discount_percent=round(dp * 100), bought_count=bought, sold_since_prev=sold,
                       stock_qty=int(rng.integers(0, 400)), rating_avg=round(float(rng.uniform(4.2, 4.9)), 1), rating_count=rating_c,
                       crawled_at=fmt(datetime.combine(dd, datetime.min.time()) + timedelta(hours=2, minutes=int(rng.integers(0, 50)))),
                       source_url=f"https://www.hasaki.example/san-pham/{it['hasaki_sku']}"))
mdf = pd.DataFrame(mp)

# reference tables
prod_out = products.drop(columns=[c for c in products.columns if c.startswith("_")])
prod_out["avg_cost"] = [int(cost.get(p, P_BY[p]["import_price"])) if p in cost else int(sum(cost[c] * q for c, q in comps[p])) for p in prod_out.product_id]
prod_out["updated_at"] = fmt(datetime.combine(C.END, datetime.min.time()) + timedelta(hours=23))
bundles = pd.DataFrame([dict(combo_product_id=p, combo_code=P_BY[p]["product_code"], component_product_id=c, component_code=P_BY[c]["product_code"],
                             component_qty=q) for p, cs in comps.items() for c, q in cs])
cats = pd.DataFrame(C.CATEGORIES, columns=["category_id", "category_l1", "category_l2"])
brands = pd.DataFrame(C.BRANDS, columns=["brand_id", "brand_name", "positioning"])
shops = pd.DataFrame(C.SHOPS, columns=["shop_code", "sale_channel", "platform", "channel_name", "shop_name", "is_marketplace", "opened_date", "closed_date"])
whs = pd.DataFrame(C.WAREHOUSES, columns=["depot_id", "depot_code", "warehouse_name", "warehouse_role", "region", "province_code", "is_stock_alert", "opened_date"])
carriers = pd.DataFrame([c[:3] for c in C.CARRIERS], columns=["carrier_id", "carrier_name", "carrier_short_name"])
sups = pd.DataFrame(C.SUPPLIERS, columns=["supplier_id", "supplier_name", "country", "lead_time_days", "min_order_value", "payment_terms"])
geo = prov.drop(columns="_w")
status = pd.DataFrame(C.ORDER_STATUS, columns=["status_code", "status_name", "status_group", "is_demand", "is_net_sale", "is_delivered", "is_cancelled", "is_returned", "is_final"])
mtypes = pd.DataFrame(C.MOVEMENT_TYPES, columns=["bill_type", "bill_mode", "movement_name", "movement_category", "direction"])
reasons = pd.DataFrame([(c, n, "cancel") for v in C.CANCEL_REASONS.values() for c, n in v] + [(c, n, "return") for c, n in C.RETURN_REASONS],
                       columns=["reason_code", "reason_name", "reason_type"])
evdf = pd.DataFrame(ev_rows, columns=["event_code", "event_year", "event_name", "event_type", "platform", "anchor_date", "window_before_days", "window_after_days", "priority"])
policy = []
for p in SINGLES:
    r = P_BY[p]
    for dep in (1, 2):
        policy.append(dict(product_id=p, product_code=r["product_code"], depot_id=dep, supplier_id=r["_supplier"], lead_time_days=LEAD[p],
                           safety_stock_days=10, review_cycle_days=7, min_order_qty=10, valid_from="2021-01-01", valid_to=None, is_current=True))
poldf = pd.DataFrame(policy)
mvdf = pd.DataFrame(moves)
sdf = pd.DataFrame(snaps, columns=["snapshot_date", "depot_id", "product_id", "on_hand_qty", "available_qty", "holding_qty", "shipping_qty", "transferring_qty", "unit_cost"])
podf = pd.DataFrame(po_lines)
cntdf = pd.DataFrame(counts)
attr = pd.DataFrame(attr_rows)

T = dict(orders=odf, order_items=idf, order_payments=pdf, order_status_history=hdf, order_reviews=rdf, customers=cust, geolocation=geo,
         products=prod_out, product_attributes=attr, product_bundles=bundles, categories=cats, brands=brands, channels_shops=shops,
         warehouses=whs, carriers=carriers, suppliers=sups, purchase_orders=podf, inventory_movements=mvdf, inventory_snapshots_daily=sdf,
         inventory_policy=poldf, stock_counts=cntdf, listings=ldf, listing_traffic_daily=tr, ads_spend_daily=adf, market_prices=mdf,
         events_calendar=evdf, order_status=status, movement_types=mtypes, order_reasons=reasons)
# thứ tự cột của order_items giống hệ thống gốc
T["order_items"] = idf[["order_id", "order_product_id", "product_id", "product_code", "quantity", "original_price", "unit_price", "total_amount",
                        "line_discount_amount", "avg_cost", "partial_return_status", "order_updated_at"]]

# =================================================================== 5. tiêm lỗi
import issues  # noqa: E402
log = [] if A.no_issues else issues.inject(T, rng, random)
os.makedirs(A.out, exist_ok=True)


def int_clean(df):
    for c in df.columns:
        s = df[c]
        if pd.api.types.is_float_dtype(s) and s.dropna().apply(float.is_integer).all() and c not in ("rating_avg",):
            df[c] = s.astype("Int64")
        elif s.dtype == object:
            df[c] = pd.Series([int(v) if isinstance(v, float) and not math.isnan(v) and v.is_integer() and c not in ("rating_avg",) else v for v in s],
                              index=df.index, dtype=object)
    return df


for k, df in T.items():
    df = int_clean(df)
    df.to_csv(os.path.join(A.out, f"{PFX}{k}_dataset.csv"), index=False, encoding="utf-8")
pd.DataFrame(log, columns=["issue_id", "dataset", "row_key", "column", "original_value", "injected_value"]).to_csv(
    os.path.join(A.out, f"{PFX}injected_issues_log.csv"), index=False, encoding="utf-8")
print({k: len(v) for k, v in T.items()}, "issues", len(log))
