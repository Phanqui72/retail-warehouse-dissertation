import numpy as np
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
# =========================================================== helpers
HDR = PatternFill("solid", fgColor="1F4E78"); HFONT = Font(name="Arial", bold=True, color="FFFFFF", size=10)
BODY = Font(name="Arial", size=10); BOLD = Font(name="Arial", size=10, bold=True)
RED = PatternFill("solid", fgColor="F8CBAD"); ROWRED = PatternFill("solid", fgColor="FCE4D6")
thin = Side(style="thin", color="BFBFBF"); BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
SEV = {"Critical": "C00000", "High": "E26B0A", "Medium": "BF8F00", "Low": "548235"}


def write_table(ws, df, start_row=1, widths=None, wrap_cols=(), max_w=60):
    for j, c in enumerate(df.columns, 1):
        cell = ws.cell(row=start_row, column=j, value=c)
        cell.fill, cell.font, cell.border = HDR, HFONT, BORDER
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    for i, row in enumerate(df.itertuples(index=False), start_row + 1):
        for j, v in enumerate(row, 1):
            if isinstance(v, float) and np.isnan(v):
                v = None
            cell = ws.cell(row=i, column=j, value=v)
            cell.font, cell.border = BODY, BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=df.columns[j - 1] in wrap_cols)
    for j, c in enumerate(df.columns, 1):
        if widths and c in widths:
            w = widths[c]
        else:
            vals = [len(str(c))] + [len(str(x)) for x in df[c].head(200)]
            w = min(max(vals) + 2, max_w)
        ws.column_dimensions[get_column_letter(j)].width = max(w, 8)
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    ws.auto_filter.ref = f"A{start_row}:{get_column_letter(len(df.columns))}{start_row + len(df)}"

