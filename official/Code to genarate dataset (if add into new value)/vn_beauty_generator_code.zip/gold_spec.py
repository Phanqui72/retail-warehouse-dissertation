"""Thiết kế lớp Gold + cạnh lineage (dùng cho mapping xlsx và diagram lineage)."""

# table: (type, grain, sources(silver), task_id, columns[(col, source, transformation)])
GOLD = {
    "dim_date": ("dim", "1 dòng / ngày 2020-12-01..2027-12-31", ["silver.events_calendar"], "build_gold_dims", [
        ("date_key", "calendar", "yyyymmdd (int)"), ("calendar_date", "calendar", "sinh dãy ngày"), ("day_of_week", "calendar", "ISO 1–7"),
        ("is_weekend", "calendar", "T7/CN"), ("event_code", "events_calendar.event_code", "sự kiện ưu tiên cao nhất phủ ngày (anchor ± window)"),
        ("event_type", "events_calendar.event_type", ""), ("days_to_event", "events_calendar.anchor_date", "date − anchor_date"),
        ("is_tet_period", "events_calendar", "event_code='TET' trong cửa sổ"), ("date_key_ly", "calendar", "cùng thứ năm trước (−364 ngày)")]),
    "dim_product": ("dim", "1 dòng / SKU × phiên bản (SCD2)", ["silver.products", "silver.categories", "silver.brands", "silver.product_attributes", "silver.product_bundles"], "build_gold_dims", [
        ("product_key", "products.product_id", "hash BIGINT(product_id, valid_from); −1 = unknown"), ("product_id", "products.product_id", ""),
        ("product_code", "products.product_code", "UPPER(TRIM()); gộp SKU trùng (PRD-01) qua bảng mapping"), ("product_name", "products.product_name", "làm sạch khoảng trắng/emoji (PRD-06)"),
        ("product_type", "products.product_type_code", "1→single, 4→combo"), ("parent_code", "products.parent_code", ""), ("brand_name", "brands.brand_name", "JOIN brand_id"),
        ("category_l1", "categories.category_l1", "JOIN category_id; NULL→'Chưa phân loại' (PRD-03)"), ("category_l2", "categories.category_l2", ""),
        ("color", "products.attr_color", "chuẩn hóa theo từ điển màu (PRD-02)"), ("material", "products.attr_material", ""), ("shape", "products.attr_shape", ""),
        ("size", "products.attr_size", ""), ("pack_qty", "products.attr_pack_qty", ""), ("retail_price", "products.retail_price", "SCD2 theo snapshot"),
        ("import_price", "products.import_price", ""), ("component_count", "product_bundles", "COUNT thành phần (combo)"),
        ("is_active", "products.product_status_code", "=1"), ("valid_from / valid_to / is_current", "products (SCD2)", "")]),
    "dim_customer": ("dim", "1 dòng / customer_unique_id", ["silver.customers", "silver.orders"], "fct_order", [
        ("customer_key", "customers.customer_unique_id", "hash(LOWER(TRIM())) (CUS-01)"), ("province_code", "customers.customer_province_code", "mode của các đơn; '99'/NULL → suy từ name_raw (CUS-02)"),
        ("first_order_date", "orders.order_date", "MIN"), ("first_channel", "orders.shop_code", "kênh đơn đầu tiên"), ("order_count", "orders", "COUNT đơn không hủy")]),
    "dim_geography": ("dim", "1 dòng / tỉnh", ["silver.geolocation"], "build_gold_dims", [("province_key", "province_code", ""), ("province_name", "", ""), ("region", "", ""), ("economic_region", "", "")]),
    "dim_channel": ("dim", "1 dòng / shop", ["silver.channels_shops"], "build_gold_dims", [("shop_key", "shop_code", ""), ("platform", "", ""), ("channel_name", "", ""), ("is_marketplace", "", "")]),
    "dim_warehouse": ("dim", "1 dòng / kho", ["silver.warehouses"], "build_gold_dims", [("warehouse_key", "depot_id", ""), ("warehouse_role", "", ""), ("region", "", "")]),
    "dim_carrier": ("dim", "1 dòng / hãng", ["silver.carriers"], "build_gold_dims", [("carrier_key", "carrier_id", "−1 = không xác định (ORD-08)")]),
    "dim_supplier": ("dim", "1 dòng / NCC", ["silver.suppliers"], "build_gold_dims", [("supplier_key", "supplier_id", "")]),
    "dim_order_status": ("dim", "1 dòng / mã trạng thái", ["silver.order_status", "silver.order_reasons"], "build_gold_dims", [("status_key", "status_code", "mã lạ → −1 (ORD-02)"), ("is_demand / is_net_sale / …", "order_status", "")]),
    "fct_order": ("fact", "1 dòng / đơn", ["silver.orders", "silver.order_payments", "silver.customers"], "fct_order", [
        ("order_key", "orders.order_id", ""), ("order_date_key", "orders.created_at", "parse đa định dạng → giờ VN → yyyymmdd (ORD-05, ORD-09)"),
        ("customer_key", "customers.customer_unique_id", "JOIN customer_id"), ("shop_key", "orders.shop_code", ""), ("warehouse_key", "orders.depot_id", ""),
        ("status_key", "orders.status_code", ""), ("carrier_key", "orders.carrier_id", "NULL → −1"), ("province_key", "orders.province_code", ""),
        ("gross_amount", "order_items.total_amount", "Σ dòng"), ("order_discount_amount", "orders.order_discount_amount", ""),
        ("net_payment_amount", "orders.business_payment_amount", "giữ nguyên; is_amount_mismatch nếu lệch Σ dòng (ORD-06)"),
        ("platform_fee_amount", "orders.ecom_fee_amount", ""), ("ship_cost_amount", "orders.ship_fee_amount + return_fee_amount", "ABS nếu âm (ORD-07)"),
        ("net_received_amount", "orders", "net_payment − platform_fee − cod_fee − ship_cost"), ("primary_payment_type", "order_payments.payment_type", "dòng payment_sequential=1"),
        ("lead_time_pack_h / delivery_days", "orders.created_at/packed_at/delivered_at", "NULL nếu phi logic (ORD-03)"), ("is_cancelled / is_returned / is_delivered", "order_status", "")]),
    "fct_order_line": ("fact", "1 dòng / dòng sản phẩm", ["silver.order_items", "silver.orders", "silver.products"], "fct_order_line", [
        ("order_line_key", "order_items.order_product_id", ""), ("order_key", "order_items.order_id", "mồ côi → quarantine (ITM-01)"),
        ("product_key", "order_items.product_id", "không tồn tại → −1 (ITM-02)"), ("qty", "order_items.quantity", "≤0 → quarantine (ITM-03)"),
        ("list_amount", "original_price × quantity", ""), ("net_amount", "order_items.total_amount", "tính lại nếu lệch (ITM-07)"),
        ("net_received_amount", "fct_order.net_received_amount", "phân bổ theo tỷ trọng net_amount, phần lẻ dồn dòng lớn nhất"),
        ("cogs_amount", "order_items.avg_cost × quantity", "avg_cost ≤0/NULL → import_price (ITM-04)"), ("gross_profit_amount", "", "net_received − cogs")]),
    "fct_order_line_component": ("fact", "1 dòng / dòng × SKU thành phần (combo bung ra)", ["gold.fct_order_line", "silver.product_bundles"], "fct_order_line_component", [
        ("component_product_key", "product_bundles.component_product_id", "combo → thành phần; SKU đơn giữ nguyên"), ("unit_qty", "qty × component_qty", ""),
        ("alloc_net_amount", "net_amount", "phân bổ theo giá vốn thành phần")]),
    "fct_order_status_event": ("fact", "1 dòng / lần đổi trạng thái", ["silver.order_status_history"], "fct_order_status_event", [
        ("order_key", "order_id", ""), ("status_key", "status_code", ""), ("changed_at", "changed_at", "dedup (HIS-01); sắp theo thứ tự nghiệp vụ (HIS-02)"), ("minutes_in_prev_status", "", "LAG")]),
    "fct_review": ("fact", "1 dòng / đánh giá", ["silver.order_reviews", "silver.listings", "silver.orders"], "fct_review", [
        ("review_key", "comment_id", "bản modified_at mới nhất (REV-04)"), ("order_key", "order_id", "NULL → nối qua marketplace_order_sn (REV-05)"),
        ("product_key", "listings.product_id", "JOIN (shop,item,model)"), ("rating_star", "rating_star", "ngoài 1–5 → NULL (REV-01)"),
        ("comment_text_masked", "comment_text", "che SĐT/email (REV-02)"), ("sentiment / topic", "comment_text", "rule-based / model (cập nhật sau)")]),
    "fct_inventory_movement": ("fact", "1 dòng / dòng phiếu kho", ["silver.inventory_movements", "silver.movement_types"], "fct_inventory_movement", [
        ("movement_key", "bill_line_id", "dedup (INV-01)"), ("movement_date_key", "movement_date", "is_backdated nếu lùi > 3 ngày (INV-04)"),
        ("warehouse_key / related_warehouse_key", "depot_id / related_depot_id", "chuyển kho thiếu đối ứng → suy từ bill_id (INV-03)"),
        ("qty_signed", "ABS(quantity) × movement_types.direction", "INV-02"), ("value_amount", "qty × avg_cost", "")]),
    "fct_inventory_daily": ("fact", "1 dòng / ngày × kho × SKU", ["silver.inventory_snapshots_daily", "gold.fct_inventory_movement"], "fct_inventory_daily", [
        ("on_hand_qty", "snapshots.on_hand_qty", "âm → is_negative_stock (SNP-02)"), ("available_qty", "on_hand − holding", "SNP-01"),
        ("is_reconstructed", "", "ngày thiếu snapshot → dựng từ movements (SNP-03)"), ("inventory_value_amount", "on_hand × unit_cost", ""), ("is_stockout", "available ≤ 0", "")]),
    "fct_purchase_order_line": ("fact", "1 dòng / dòng PO", ["silver.purchase_orders"], "fct_purchase_order_line", [
        ("actual_lead_time_days", "received_date − order_date", "NULL nếu âm (PO-02)"), ("fill_rate", "received_qty / order_qty", "cảnh báo > 1.1 (PO-01)")]),
    "fct_listing_traffic_daily": ("fact", "1 dòng / ngày × item", ["silver.listing_traffic_daily", "silver.listings"], "fct_listing_traffic_daily", [
        ("ctr", "clicks / impressions", "NULL nếu clicks > impressions (TRF-01)"), ("conversion_rate", "placed_orders / unique_visitors", "")]),
    "fct_ads_daily": ("fact", "1 dòng / ngày × chiến dịch", ["silver.ads_spend_daily"], "fct_ads_daily", [("roas", "ad_gmv_amount / spend_amount", "spend âm → dòng refund (ADS-01)")]),
    "fct_market_price": ("fact", "1 dòng / tuần × sản phẩm thị trường", ["silver.market_prices"], "fct_market_price", [
        ("price", "price", "bỏ '.', 'đ' → int (MKT-01)"), ("discount_percent", "price/market_price", "tính lại (MKT-02)"), ("price_index_vs_own", "", "so với sản phẩm cùng danh mục của doanh nghiệp")]),
    "mart_sales_daily": ("mart", "ngày × kênh × SKU × kho", ["gold.fct_order_line_component", "gold.fct_order", "gold.dim_date"], "mart_sales_daily", [
        ("demand_qty", "unit_qty", "đơn is_demand (gồm hoàn, không gồm hủy)"), ("net_sales_qty", "unit_qty", "is_net_sale"), ("net_revenue_amount", "alloc_net_amount", ""),
        ("gross_profit_amount", "", ""), ("is_event_day", "dim_date.event_code", "")]),
    "mart_product_attribute_perf": ("mart", "tháng × thuộc tính × giá trị × danh mục", ["gold.fct_order_line", "gold.fct_review", "gold.dim_product"], "mart_product_attribute_perf", [
        ("attribute_name / attribute_value", "dim_product.color/material/shape/size/pack_qty", "unpivot"), ("qty / revenue / share_in_category", "fct_order_line", ""),
        ("avg_rating / return_rate", "fct_review / fct_order", "")]),
    "mart_inventory_health": ("mart", "ngày × kho × SKU", ["gold.fct_inventory_daily", "gold.mart_sales_daily", "silver.inventory_policy"], "mart_inventory_health", [
        ("daily_demand_qty", "mart_sales_daily", "TB 28 ngày"), ("days_of_cover", "available / daily_demand", ""), ("reorder_by_date", "", "stockout_date − lead_time − safety_days"),
        ("lost_sales_qty", "fct_order (reason 11)", "đơn hủy do hết hàng")]),
    "mart_channel_funnel": ("mart", "ngày × shop", ["gold.fct_listing_traffic_daily", "gold.fct_ads_daily", "gold.fct_order"], "mart_channel_funnel", [("impressions → clicks → orders → GMV, spend, ROAS", "", "")]),
    "mart_order_sla": ("mart", "1 dòng / đơn chưa kết thúc vượt SLA", ["gold.fct_order_status_event"], "mart_order_sla", [("stuck_hours", "now − changed_at cuối", "")]),
    "mart_customer_rfm": ("mart", "tháng × khách", ["gold.fct_order", "gold.dim_customer"], "mart_customer_rfm", [("recency / frequency / monetary / segment", "", "")]),
    "mart_demand_forecast_input": ("mart", "ngày × SKU × kho (đặc trưng cho mô hình)", ["gold.mart_sales_daily", "gold.mart_inventory_health", "gold.dim_date", "gold.fct_listing_traffic_daily", "gold.fct_market_price"], "mart_demand_forecast_input", [
        ("y = demand_qty", "", ""), ("lags 1/7/28, rolling mean", "", ""), ("event features", "dim_date", ""), ("price, discount, stockout flag, traffic, competitor price index", "", "")]),
    "fct_demand_forecast": ("fact", "tuần × SKU × kho × horizon", ["gold.mart_demand_forecast_input"], "vnb_forecast_weekly.write_forecast", [("yhat, yhat_lower, yhat_upper, model_version", "", "CẬP NHẬT SAU")]),
}

POWERBI = {"Tổng quan doanh thu": ["mart_sales_daily", "fct_order", "dim_date", "dim_channel"],
           "Sản phẩm & thuộc tính": ["mart_product_attribute_perf", "dim_product", "fct_review"],
           "Tồn kho & cảnh báo": ["mart_inventory_health", "fct_inventory_daily", "fct_purchase_order_line"],
           "Kênh & marketing": ["mart_channel_funnel", "fct_ads_daily", "fct_market_price"],
           "Vận hành & khách hàng": ["mart_order_sla", "mart_customer_rfm", "fct_review"],
           "Dự báo nhu cầu": ["fct_demand_forecast", "mart_demand_forecast_input"]}

INCR = ["orders", "order_items", "order_payments", "order_status_history", "order_reviews", "customers", "inventory_movements",
        "inventory_snapshots_daily", "purchase_orders", "stock_counts", "listing_traffic_daily", "ads_spend_daily", "market_prices"]
MASTER = ["products", "product_attributes", "product_bundles", "listings", "inventory_policy", "categories", "brands", "channels_shops",
          "warehouses", "carriers", "suppliers", "geolocation", "events_calendar", "order_status", "movement_types", "order_reasons"]
