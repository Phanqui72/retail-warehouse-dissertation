"""Tạo: sample CSV + workbook sample, issue catalog, DQ requirements."""
import os, re, sys, shutil
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
import issues as I
import spec as S

FULL, CLEAN, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
PFX = "vn_beauty_"
os.makedirs(OUT, exist_ok=True)
SAMPLE_DIR = os.path.join(OUT, "sample_csv")
os.makedirs(SAMPLE_DIR, exist_ok=True)
ORDER = list(S.DATASETS)
rd = lambda d, k: pd.read_csv(os.path.join(d, f"{PFX}{k}_dataset.csv"), low_memory=False, dtype=str, keep_default_na=False)
full = {k: rd(FULL, k) for k in ORDER}
clean = {k: pd.read_csv(os.path.join(CLEAN, f"{PFX}{k}_dataset.csv"), low_memory=False) for k in ORDER}
log = pd.read_csv(os.path.join(FULL, f"{PFX}injected_issues_log.csv"), dtype=str, keep_default_na=False)
rs = np.random.RandomState(7)

# =========================================================== 1. chọn sample nhất quán
o = full["orders"]
def ids_from_log(ds, n):
    return log[log.dataset == ds].row_key.drop_duplicates().sample(min(n, (log.dataset == ds).sum()), random_state=1).tolist()
iss_orders = ids_from_log("orders", 6)
it = full["order_items"]
iss_items = it[it.order_product_id.isin(ids_from_log("order_items", 4))].order_id.tolist()
combo_orders = it[it.product_code.str.upper().str.strip().str.startswith("CB-")].order_id.sample(2, random_state=2).tolist()
normal = []
for st in ["60", "63", "64", "72", "74", "61"]:
    normal += o[(o.status_code == st)].order_id.sample(2 if st == "60" else 1, random_state=3).tolist()
for shop in ["TTS_01", "WEB_01", "FB_01", "STORE_HN", "LZD_01", "SHP_02"]:
    normal += o[o.shop_code == shop].order_id.sample(1, random_state=4).tolist()
for y in ["2021", "2023", "2025", "2026"]:
    normal += o[o.order_date.str.startswith(y)].order_id.sample(1, random_state=5).tolist()
sel = list(dict.fromkeys([str(x) for x in iss_orders + iss_items + combo_orders + normal]))[:34]
S_ = {}
S_["orders"] = o[o.order_id.isin(sel)]
S_["order_items"] = it[it.order_id.isin(sel)]
S_["order_payments"] = full["order_payments"][full["order_payments"].order_id.isin(sel)]
h = full["order_status_history"]
hsel = sel[:9] + [k for k in ids_from_log("order_status_history", 3) if "|" in k][:0]
S_["order_status_history"] = h[h.order_id.isin(sel[:10])]
S_["customers"] = full["customers"][full["customers"].customer_id.isin(S_["orders"].customer_id)]
rv = full["order_reviews"]
rv_iss = rv[rv.comment_id.isin(ids_from_log("order_reviews", 8))]
S_["order_reviews"] = pd.concat([rv[rv.order_id.isin(sel)], rv_iss, rv.sample(20, random_state=6)]).drop_duplicates().head(40)
S_["products"] = full["products"]
S_["product_attributes"] = full["product_attributes"].head(45)
mv = full["inventory_movements"]
mv_iss = mv[mv.bill_line_id.isin(ids_from_log("inventory_movements", 5))]
mv_other = pd.concat([mv[(mv.bill_type == t) & (mv.bill_mode == m)].sample(3, random_state=8) for t, m in [("1", "1"), ("1", "2"), ("1", "3"), ("2", "3"), ("1", "4"), ("2", "4"), ("2", "5")]])
S_["inventory_movements"] = pd.concat([mv[mv.order_id.isin(sel[:8])], mv_other, mv_iss]).drop_duplicates()
sn = full["inventory_snapshots_daily"]
skus = full["products"][full["products"].product_code.isin(["MTN-GN-01", "BC-12-01"])].product_id.tolist()
win = sn[(sn.snapshot_date >= "2025-11-05") & (sn.snapshot_date <= "2025-11-14") & sn.product_id.isin(skus) & sn.depot_id.isin(["2", "3"])]
sn_iss_keys = ids_from_log("inventory_snapshots_daily", 6)
sn_iss = sn[(sn.snapshot_date + "|" + sn.depot_id + "|" + sn.product_id).isin(sn_iss_keys)]
S_["inventory_snapshots_daily"] = pd.concat([win, sn_iss]).drop_duplicates()
po = full["purchase_orders"]
S_["purchase_orders"] = pd.concat([po.sample(25, random_state=9), po[po.po_line_id.isin(ids_from_log("purchase_orders", 5))]]).drop_duplicates()
S_["inventory_policy"] = full["inventory_policy"].head(30)
S_["stock_counts"] = pd.concat([full["stock_counts"][full["stock_counts"].diff_qty != "0"].head(20), full["stock_counts"].head(10)]).drop_duplicates()
ls = full["listings"]
S_["listings"] = pd.concat([ls[ls.shop_code == "SHP_MALL"].head(15), ls[ls.shop_code == "TTS_01"].head(15), ls[ls.listing_id.str.endswith("-dup")]])
tf = full["listing_traffic_daily"]
item0 = tf[tf.shop_code == "SHP_MALL"].item_id.iloc[0]
tf_iss = tf[(tf.stat_date + "|" + tf.shop_code + "|" + tf.item_id).isin(ids_from_log("listing_traffic_daily", 5))]
S_["listing_traffic_daily"] = pd.concat([tf[(tf.item_id == item0) & (tf.stat_date >= "2025-11-01")].head(20), tf_iss]).drop_duplicates()
ad = full["ads_spend_daily"]
S_["ads_spend_daily"] = pd.concat([ad[ad.stat_date.between("2025-11-09", "2025-11-12")].head(24), ad[(ad.stat_date + "|" + ad.shop_code + "|" + ad.campaign_id).isin(ids_from_log("ads_spend_daily", 3))]]).drop_duplicates()
mk = full["market_prices"]
mk_iss = mk[(mk.snapshot_date + "|" + mk.market_item_id).isin(ids_from_log("market_prices", 8))]
S_["market_prices"] = pd.concat([mk[mk.market_item_id.isin(mk.market_item_id.unique()[:2])].tail(20), mk_iss]).drop_duplicates()
S_["events_calendar"] = full["events_calendar"][full["events_calendar"].event_year == "2025"]
for k in ["geolocation", "categories", "brands", "channels_shops", "warehouses", "carriers", "suppliers", "order_status", "movement_types", "order_reasons", "product_bundles"]:
    S_[k] = full[k]
for k in ORDER:
    S_[k].to_csv(os.path.join(SAMPLE_DIR, f"{PFX}{k}_dataset.csv"), index=False, encoding="utf-8-sig")

# =========================================================== helpers
HDR = PatternFill("solid", fgColor="1F4E78"); HFONT = Font(name="Arial", bold=True, color="FFFFFF", size=10)
BODY = Font(name="Arial", size=10); BOLD = Font(name="Arial", size=10, bold=True)
RED = PatternFill("solid", fgColor="F8CBAD"); ROWRED = PatternFill("solid", fgColor="FCE4D6")
thin = Side(style="thin", color="BFBFBF"); BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
SEV = {"Critical": "C00000", "High": "E26B0A", "Medium": "BF8F00", "Low": "548235"}


def write_table(ws, df, start_row=1, widths=None, wrap_cols=(), max_w=60):
    for j, c in enumerate(df.columns, 1):
        cell = ws.cell(row=start_row, column=j, value=c)
        cell.fill, cell.font, cell.border = HDR, HFONT, BORDER
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    for i, row in enumerate(df.itertuples(index=False), start_row + 1):
        for j, v in enumerate(row, 1):
            if isinstance(v, float) and np.isnan(v):
                v = None
            cell = ws.cell(row=i, column=j, value=v)
            cell.font, cell.border = BODY, BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=df.columns[j - 1] in wrap_cols)
    for j, c in enumerate(df.columns, 1):
        if widths and c in widths:
            w = widths[c]
        else:
            vals = [len(str(c))] + [len(str(x)) for x in df[c].head(200)]
            w = min(max(vals) + 2, max_w)
        ws.column_dimensions[get_column_letter(j)].width = max(w, 8)
    ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
    ws.auto_filter.ref = f"A{start_row}:{get_column_letter(len(df.columns))}{start_row + len(df)}"

# =========================================================== 2. workbook sample
wb = Workbook()
ws0 = wb.active; ws0.title = "README"
rows_full = {k: len(full[k]) for k in ORDER}
idx = pd.DataFrame([dict(sheet=k[:31], dataset_file=f"{PFX}{k}_dataset.csv", domain=S.DATASETS[k][0], grain=S.DATASETS[k][1],
                         primary_key=S.DATASETS[k][2], rows_in_sample=len(S_[k]), rows_in_full_dataset=rows_full[k]) for k in ORDER])
ws0["A1"] = "VN Beauty Orders Dataset — bản mẫu (sample)"; ws0["A1"].font = Font(name="Arial", size=14, bold=True)
ws0["A2"] = "Dữ liệu sinh 100% (2021-01-01 → 2026-09-30), cấu trúc thuộc tính theo hệ thống thật đã ẩn danh. Thương hiệu, NCC, đối thủ đều hư cấu."
ws0["A3"] = "Ô tô đỏ = giá trị bị tiêm lỗi cố ý (di chuột vào ô để xem mã lỗi). Dòng tô nhạt = dòng bị nhân bản / thêm vào. Danh mục lỗi xem file vn_beauty_data_issues_catalog.xlsx."
for c in ("A2", "A3"):
    ws0[c].font = BODY
write_table(ws0, idx, start_row=5, wrap_cols=("grain", "primary_key"), widths={"grain": 40, "primary_key": 32})
cellmap = {}
for r in log.itertuples(index=False):
    cellmap.setdefault((r.dataset, r.row_key), []).append((r.column, r.issue_id))
for k in ORDER:
    ws = wb.create_sheet(k[:31])
    df = S_[k].reset_index(drop=True)
    write_table(ws, df, wrap_cols=("comment_text",), widths={"comment_text": 50, "product_name": 45, "listing_name": 45, "item_name": 40})
    keys = I.KEYS.get(k)
    if not keys:
        continue
    seen = set()
    for i, row in df.iterrows():
        rk = "|".join(str(row[c]) for c in keys)
        hits = cellmap.get((k, rk), [])
        if k == "order_status_history":
            hits = hits + cellmap.get((k, str(row["order_id"]) + "|" + str(row["status_code"])), [])
        dup_row = rk in seen
        seen.add(rk)
        for col, iid in hits:
            if col == "*" or dup_row:
                for j in range(1, len(df.columns) + 1):
                    ws.cell(row=i + 2, column=j).fill = ROWRED
                ws.cell(row=i + 2, column=1).comment = Comment(f"{iid}: dòng trùng / thêm", "generator")
            elif col in df.columns:
                c = ws.cell(row=i + 2, column=list(df.columns).index(col) + 1)
                c.fill = RED
                c.comment = Comment(iid, "generator")
        if k == "products" and str(row["product_id"]).startswith("3900"):
            for j in range(1, len(df.columns) + 1):
                ws.cell(row=i + 2, column=j).fill = ROWRED
wb.save(os.path.join(OUT, "vn_beauty_orders_dataset_SAMPLE.xlsx"))

# =========================================================== 3. issue catalog
cat = pd.DataFrame(I.CATALOG, columns=I.COLS)
cnt = log.groupby("issue_id").size()
cat["rows_affected_full"] = cat.issue_id.map(cnt).fillna(0).astype(int)
cat["rate"] = [f"{r:.2%}" if r < 1 else f"{int(r)} bản ghi" for r in cat.rate]
cat = cat[["issue_id", "dataset", "column", "issue_type", "dq_dimension", "severity", "rate", "rows_affected_full", "description", "example", "detection_rule", "suggested_handling"]]
wb = Workbook(); ws = wb.active; ws.title = "README"
ws["A1"] = "Danh mục lỗi cố ý — VN Beauty Orders Dataset"; ws["A1"].font = Font(name="Arial", size=14, bold=True)
notes = ["Mỗi lỗi có mã issue_id; log chi tiết từng bản ghi bị tiêm lỗi nằm ở vn_beauty_injected_issues_log.csv (issue_id, dataset, row_key, column, original_value, injected_value).",
         "rate = tỷ lệ bản ghi của bảng bị tiêm (hoặc số bản ghi cố định với bảng nhỏ). rows_affected_full = số bản ghi bị tác động trong bộ đầy đủ.",
         "Ngoài các lỗi tiêm, dữ liệu còn 'bẩn tự nhiên': province_name_raw nhiều cách viết (TP.HCM, Sài Gòn, Ha Noi…), đơn hủy do hết hàng (reason 11), hoàn hàng, đơn còn dở dang cuối kỳ.",
         "Bảng danh mục (geolocation, categories, brands, channels_shops, warehouses, carriers, suppliers, order_status, movement_types, order_reasons, events_calendar, inventory_policy) được giữ sạch để làm chuẩn đối chiếu."]
for i, n in enumerate(notes, 3):
    ws.cell(row=i, column=1, value=n).font = BODY
summ = cat.groupby(["dataset"]).agg(issues=("issue_id", "count"), rows_affected=("rows_affected_full", "sum")).reset_index()
sev = cat.pivot_table(index="dataset", columns="severity", values="issue_id", aggfunc="count", fill_value=0).reset_index()
summ = summ.merge(sev, on="dataset")
write_table(ws, summ, start_row=8)
ws2 = wb.create_sheet("Issue catalog")
write_table(ws2, cat, wrap_cols=("description", "example", "detection_rule", "suggested_handling"),
            widths={"description": 48, "example": 28, "detection_rule": 40, "suggested_handling": 38, "issue_type": 22})
sc = list(cat.columns).index("severity") + 1
for i in range(2, len(cat) + 2):
    c = ws2.cell(row=i, column=sc); c.font = Font(name="Arial", size=10, bold=True, color=SEV[c.value])
ws3 = wb.create_sheet("Log examples")
ex = log.groupby("issue_id").head(3)
write_table(ws3, ex, widths={"original_value": 30, "injected_value": 30})
wb.save(os.path.join(OUT, "vn_beauty_data_issues_catalog.xlsx"))
shutil.copy(os.path.join(FULL, f"{PFX}injected_issues_log.csv"), os.path.join(OUT, f"{PFX}injected_issues_log.csv"))

# =========================================================== 4. DQ requirements
def dtype_of(s):
    if s.isna().all():
        return "bigint" if s.name.endswith("_id") else "varchar"
    if s.dtype == bool or set(s.dropna().unique()) <= {True, False}:
        return "boolean"
    if pd.api.types.is_integer_dtype(s) or (pd.api.types.is_float_dtype(s) and s.dropna().apply(float.is_integer).all() and s.name not in ("rating_avg",)):
        return "bigint"
    if pd.api.types.is_float_dtype(s):
        return "double"
    x = s.dropna().astype(str)
    if len(x) and x.str.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$").all():
        return "timestamp (giờ VN)"
    if len(x) and x.str.match(r"^\d{4}-\d{2}-\d{2}$").all():
        return "date"
    return "varchar"

fields = []
for k in ORDER:
    df = clean[k]
    pk = [p.strip() for p in S.DATASETS[k][2].split("+")]
    fks = {f.split("→")[0].strip(): f.split("→")[1].strip() for f in S.DATASETS[k][3].split(";") if "→" in f}
    for col in df.columns:
        s = df[col]
        t = dtype_of(s)
        nn = s.notna().mean()
        req = "Bắt buộc" if nn == 1 else f"Cho phép NULL ({(1 - nn):.0%} rỗng trong dữ liệu sạch)"
        auto = []
        if col in pk:
            auto.append("thuộc khóa chính")
        if col in fks:
            auto.append(f"FK → {fks[col]}")
        if t in ("bigint", "double") and col.endswith(("_amount", "_qty", "_price", "quantity", "_cost")) and (s.dropna() >= 0).all():
            auto.append("≥ 0")
        if t == "varchar" and s.nunique() <= 12 and len(s) > 20 and col not in pk:
            auto.append("IN (" + ", ".join(map(str, sorted(s.dropna().unique())[:12])) + ")")
        if t == "timestamp (giờ VN)":
            auto.append("regex ^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$")
        rule, sev_ = S.RULES.get((k, col), (None, None))
        crit = S.DATASETS[k][8]
        severity = sev_ or ("High" if col in pk or col in fks else ("Medium" if crit in ("Critical", "High") else "Low"))
        dims = []
        if col in pk: dims.append("Uniqueness")
        if col in fks: dims.append("Integrity")
        if nn == 1: dims.append("Completeness")
        if auto or rule: dims.append("Validity")
        fields.append(dict(dataset=k, column=col, description=S.DESC.get(col, ""), data_type=t, nullable=req,
                           key=("PK" if col in pk else ("FK" if col in fks else "")),
                           rule=("; ".join([r for r in [rule] if r] + auto)), dq_dimensions=", ".join(dict.fromkeys(dims)),
                           severity=severity, pii_class=S.PII.get(col, "Không"),
                           example=str(s.dropna().iloc[0]) if s.notna().any() else ""))
fdf = pd.DataFrame(fields)
dsdf = pd.DataFrame([dict(dataset=k, file=f"{PFX}{k}_dataset.csv", domain=v[0], grain=v[1], primary_key=v[2], foreign_keys=v[3], source_system=v[4],
                          load_pattern=v[5], refresh=v[6], freshness_sla=v[7], criticality=v[8], owner_role=v[9], rows_full=rows_full[k])
                     for k, v in S.DATASETS.items()])
wb = Workbook(); ws = wb.active; ws.title = "README"
ws["A1"] = "Yêu cầu chất lượng dữ liệu & Data Governance — VN Beauty Orders Dataset"; ws["A1"].font = Font(name="Arial", size=14, bold=True)
lines = ["Mục đích: đặc tả 'hợp đồng dữ liệu' (data contract) đầu vào để viết DQ check (Airflow data_quality / Great Expectations / dbt tests) và làm nền cho data governance.",
         "Sheet Datasets: mỗi bảng có grain, khóa, nguồn, chu kỳ nạp, SLA độ tươi, mức quan trọng, người chịu trách nhiệm (owner_role).",
         "Sheet Field rules: từ điển dữ liệu + luật cho từng cột (kiểu, NULL, miền giá trị, khóa ngoại, phân loại PII, mức nghiêm trọng).",
         "Sheet Cross-table rules: luật đối soát giữa các bảng (tiền đơn, tồn kho, PO, review…).",
         "Sheet DQ thresholds: ngưỡng đạt theo từng chiều chất lượng và hành động khi không đạt.",
         "Sheet Governance: phân loại dữ liệu, quyền truy cập, che PII, lưu trữ, lineage, quy trình xử lý sự cố.",
         "Mức nghiêm trọng: Critical = chặn publish Gold · High = cảnh báo ngay, xử lý trong 1 ngày · Medium = 3 ngày · Low = theo dõi."]
for i, n in enumerate(lines, 3):
    ws.cell(row=i, column=1, value=n).font = BODY
ws.column_dimensions["A"].width = 160
ws = wb.create_sheet("Datasets")
write_table(ws, dsdf, wrap_cols=("grain", "foreign_keys", "primary_key"), widths={"grain": 34, "foreign_keys": 60, "primary_key": 30, "load_pattern": 28})
ws = wb.create_sheet("Field rules")
write_table(ws, fdf, wrap_cols=("rule", "description", "nullable"), widths={"rule": 60, "description": 45, "nullable": 26, "example": 24})
sc = list(fdf.columns).index("severity") + 1
for i in range(2, len(fdf) + 2):
    c = ws.cell(row=i, column=sc); c.font = Font(name="Arial", size=10, bold=True, color=SEV[c.value])
ws = wb.create_sheet("Cross-table rules")
write_table(ws, pd.DataFrame(S.CROSS_RULES, columns=["rule_id", "rule_name", "tables", "rule", "dq_dimension", "severity", "target"]),
            wrap_cols=("rule",), widths={"rule": 70})
ws = wb.create_sheet("DQ thresholds")
write_table(ws, pd.DataFrame(S.THRESHOLDS, columns=["dq_dimension", "definition", "threshold", "action_on_fail"]), wrap_cols=("definition", "threshold", "action_on_fail"),
            widths={"definition": 45, "threshold": 50, "action_on_fail": 50})
ws = wb.create_sheet("Governance")
write_table(ws, pd.DataFrame(S.GOVERNANCE, columns=["topic", "policy"]), wrap_cols=("policy",), widths={"policy": 120, "topic": 28})
wb.save(os.path.join(OUT, "vn_beauty_data_quality_requirements.xlsx"))
print("done", {k: len(v) for k, v in S_.items()}, len(fdf))
