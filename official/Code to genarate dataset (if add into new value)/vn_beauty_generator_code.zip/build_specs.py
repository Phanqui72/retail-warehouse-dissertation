import os, sys
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font
import issues as I, spec as S, gold_spec as G
from build_docs_lib import write_table, BODY, SEV

CLEAN, OUT = sys.argv[1], sys.argv[2]
PFX = "vn_beauty_"
clean = {k: pd.read_csv(os.path.join(CLEAN, f"{PFX}{k}_dataset.csv"), low_memory=False) for k in G.INCR + G.MASTER}
cat = pd.DataFrame(I.CATALOG, columns=I.COLS)


def dtype_of(s):
    if s.isna().all():
        return "bigint" if s.name.endswith("_id") else "string"
    if s.dtype == bool or set(s.dropna().unique()) <= {True, False}:
        return "boolean"
    if pd.api.types.is_integer_dtype(s) or (pd.api.types.is_float_dtype(s) and s.dropna().apply(float.is_integer).all() and s.name != "rating_avg"):
        return "bigint"
    if pd.api.types.is_float_dtype(s):
        return "double"
    x = s.dropna().astype(str)
    if len(x) and x.str.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$").all():
        return "timestamp"
    if len(x) and x.str.match(r"^\d{4}-\d{2}-\d{2}$").all():
        return "date"
    return "string"

FILE_ISSUES = [
    ("FILE-01", "landing", "File đến muộn", "Timeliness", "High", "Sensor timeout / file nằm ở partition sau với hậu tố __late_dt=", "check_manifest.late_file_pickup: nạp vào đúng dt gốc; nếu đã quá giờ → chạy lại dt cũ (depends_on_past)"),
    ("FILE-02", "landing", "Lệch số dòng / md5 với manifest", "Completeness", "High", "check_manifest.row_count_match / md5_match", "quarantine_batch, yêu cầu nguồn gửi lại"),
    ("FILE-03", "landing", "Schema evolution (thêm cột)", "Consistency", "Medium", "schema_version mới trong manifest / cột lạ", "Cho phép thêm cột (Iceberg ADD COLUMN), cảnh báo Medium, cập nhật data contract"),
    ("FILE-04", "landing", "Đảo thứ tự cột", "Consistency", "Low", "header khác thứ tự chuẩn", "Đọc theo tên cột (header=True), không theo vị trí"),
    ("FILE-05", "landing", "Dòng CSV hỏng", "Validity", "Medium", "Spark PERMISSIVE → _corrupt_record IS NOT NULL", "Ghi dòng hỏng vào bronze._corrupt; > 0,1% → High"),
    ("FILE-06", "landing", "File giao trùng", "Uniqueness", "Medium", "md5 trùng file khác trong cùng dt", "Bỏ qua bản trùng, chỉ nạp file có trong manifest"),
    ("FILE-07", "landing", "Sai encoding", "Validity", "Medium", "Đọc UTF-8 lỗi / ký tự thay thế '�' vượt ngưỡng", "Thử cp1258 → chuyển UTF-8; không được thì quarantine file"),
    ("FILE-08", "landing", "Thiếu _SUCCESS / thiếu file", "Completeness", "High", "S3KeySensor timeout 6h", "Không nạp nửa vời; alert High; chạy lại khi nguồn bổ sung"),
    ("FILE-09", "landing", "Thiếu manifest", "Completeness", "Medium", "check_manifest.manifest_exists", "Chế độ degraded: nạp theo danh sách file thực có, gắn cờ, alert Medium"),
]

# =========================================================== mapping workbook
tables = []
for ds in G.INCR + G.MASTER:
    kind = "incremental" if ds in G.INCR else "master"
    tables.append(dict(layer="landing", table=f"landing/{'daily/dt=' if kind == 'incremental' else 'master/snapshot_date='}{{ds}}/{ds}.csv", grain=S.DATASETS[ds][1],
                       primary_key=S.DATASETS[ds][2], load=kind, task="(hệ thống nguồn)", sources="OMS / sàn / crawler (mô phỏng)"))
    tables.append(dict(layer="bronze", table=f"bronze.{ds}", grain="như nguồn + metadata nạp", primary_key="_dt + _source_file + _row_num",
                       load="overwrite partition _dt (idempotent)", task=f"vnb_{'daily_batch.bronze.load_bronze_' + ds if kind == 'incremental' else 'master_refresh.load_bronze_master'}",
                       sources=f"landing {ds}.csv"))
    tables.append(dict(layer="silver", table=f"silver.{ds}", grain=S.DATASETS[ds][1], primary_key=S.DATASETS[ds][2],
                       load=("SCD2" if ds == "products" else ("MERGE" if kind == "incremental" else "overwrite")),
                       task=(f"vnb_daily_batch.silver.silver_{ds}" if kind == "incremental" else "vnb_master_refresh.silver_master"), sources=f"bronze.{ds}"))
for t, (typ, grain, src, task, cols) in G.GOLD.items():
    tables.append(dict(layer="gold", table=f"gold.{t}", grain=grain, primary_key=cols[0][0], load="CTAS / MERGE theo dt", task=task, sources=", ".join(src)))
tables.append(dict(layer="ops", table="silver_quarantine.<dataset>", grain="dòng bị loại + issue_id + lý do", primary_key="_dt + row_key", load="append", task="silver.*", sources="bronze.*"))
tables.append(dict(layer="ops", table="ops.dq_results", grain="1 dòng / check / lần chạy", primary_key="run_id + check_id", load="append", task="dq_*", sources="silver.*, gold.*"))
tables.append(dict(layer="ops", table="ops.pipeline_run_log", grain="1 dòng / DAG run", primary_key="run_id", load="append", task="publish.write_run_log", sources="Airflow"))
tdf = pd.DataFrame(tables)

edges = []
for ds in G.INCR + G.MASTER:
    edges.append(("landing", f"{ds}.csv", "bronze", f"bronze.{ds}", "đọc CSV dạng chuỗi + metadata", "load_bronze"))
    edges.append(("bronze", f"bronze.{ds}", "silver", f"silver.{ds}", "ép kiểu, chuẩn hóa, dedup, MERGE, quarantine", "silver"))
    edges.append(("bronze", f"bronze.{ds}", "ops", "silver_quarantine", "bản ghi lỗi", "silver"))
for t, (typ, grain, src, task, cols) in G.GOLD.items():
    for s in src:
        edges.append((s.split(".")[0], s, "gold", f"gold.{t}", typ, task))
for page, ts in G.POWERBI.items():
    for t in ts:
        edges.append(("gold", f"gold.{t}", "bi", f"Power BI: {page}", "Import / DirectQuery qua Trino", "refresh_powerbi"))
edf = pd.DataFrame(edges, columns=["from_layer", "from_table", "to_layer", "to_table", "transformation", "task"]).drop_duplicates()

colmap = []
handling = {}
for r in I.CATALOG:
    handling.setdefault((r[1], r[2]), []).append(f"{r[10]} ({r[0]})")
for ds in G.INCR + G.MASTER:
    df = clean[ds]
    for c in df.columns:
        colmap.append(dict(layer="bronze", target_table=f"bronze.{ds}", target_column=c, source=f"landing {ds}.csv.{c}", data_type="string",
                           transformation="giữ nguyên (schema-on-read)", issue_refs=""))
    for c in ["_dt", "_source_file", "_source_md5", "_ingested_at", "_batch_id", "_schema_version", "_corrupt_record"]:
        colmap.append(dict(layer="bronze", target_table=f"bronze.{ds}", target_column=c, source="metadata", data_type="string", transformation="thêm khi nạp", issue_refs=""))
    for c in df.columns:
        t = dtype_of(df[c])
        tr = {"timestamp": "parse đa định dạng (yyyy-MM-dd HH:mm:ss | ISO-Z→+7h | dd/MM/yyyy HH:mm) → timestamp giờ VN",
              "date": "to_date", "bigint": "cast bigint (lỗi → NULL + quarantine nếu cột bắt buộc)", "double": "cast double",
              "boolean": "cast boolean", "string": "TRIM, chuẩn hóa NULL giả ('', 'null', 'N/A')"}[t]
        if c in ("product_code", "sku", "component_code", "combo_code"):
            tr += "; UPPER"
        if c == "customer_unique_id":
            tr += "; LOWER"
        h = handling.get((ds, c), []) + handling.get((ds, "*"), [])
        colmap.append(dict(layer="silver", target_table=f"silver.{ds}", target_column=c, source=f"bronze.{ds}.{c}", data_type=t,
                           transformation=tr + ("; " + " | ".join(h) if h else ""), issue_refs=", ".join(sorted({x.split("(")[-1][:-1] for x in h}))))
for t, (typ, grain, src, task, cols) in G.GOLD.items():
    for (c, s, tr) in cols:
        refs = ", ".join(sorted({w for w in tr.replace("(", " ").replace(")", " ").replace(",", " ").split() if w[:3] in {i[:3] for i in cat.issue_id}}))
        colmap.append(dict(layer="gold", target_table=f"gold.{t}", target_column=c, source=s, data_type="", transformation=tr, issue_refs=refs))
cdf = pd.DataFrame(colmap)

wb = Workbook(); ws = wb.active; ws.title = "README"
ws["A1"] = "Source-to-Target Mapping — VN Beauty Lakehouse (batch)"; ws["A1"].font = Font(name="Arial", size=14, bold=True)
for i, n in enumerate([
        "Luồng: landing CSV (daily / master) → bronze (Iceberg, giữ nguyên dạng chuỗi + metadata) → silver (ép kiểu, chuẩn hóa, dedup, MERGE/SCD2, quarantine) → gold (dim / fact / mart) → Power BI.",
        "Sheet Tables: mọi bảng theo tầng, grain, khóa, kiểu nạp, task Airflow tạo ra bảng (khớp pipeline_spec.yaml).",
        "Sheet Table lineage: cạnh from_table → to_table, dùng để vẽ data lineage.",
        "Sheet Column mapping: bronze/silver tự sinh đầy đủ theo cột; gold liệt kê cột chính và công thức. issue_refs nối tới vn_beauty_data_issues_catalog.xlsx.",
        "Lưu ý: silver.stock_counts chỉ dùng cho kiểm tra đối soát XR-08, không đi vào gold."], 3):
    ws.cell(row=i, column=1, value=n).font = BODY
ws.column_dimensions["A"].width = 150
write_table(wb.create_sheet("Tables"), tdf, wrap_cols=("sources", "grain"), widths={"sources": 60, "grain": 40, "table": 48})
write_table(wb.create_sheet("Table lineage"), edf)
write_table(wb.create_sheet("Column mapping"), cdf, wrap_cols=("transformation",), widths={"transformation": 80, "source": 40})
wb.save(os.path.join(OUT, "vn_beauty_source_to_target_mapping.xlsx"))
edf.to_csv(os.path.join(OUT, "_lineage_edges.csv"), index=False)

# =========================================================== error handling policy
classes = [
    ("E1", "Landing / file", "Thiếu file, file muộn, lệch manifest, encoding, CSV hỏng, file trùng, schema drift", "sense, validate_landing, bronze",
     "Không nạp nửa vời. Lỗi nghiêm trọng → chuyển dt vào landing/_quarantine và dừng run; lỗi nhẹ → chế độ degraded có gắn cờ", "Sensor: chờ 6h (poke 10m). Task: retry 2 lần, backoff 5m→10m", "FILE-01…09"),
    ("E2", "Bản ghi không hợp lệ (Validity / Integrity)", "Sai miền giá trị, sai kiểu, khóa ngoại không tồn tại, bản ghi mồ côi", "silver",
     "Đưa bản ghi vào silver_quarantine.<dataset> kèm issue_id + lý do; với FK thiếu ở gold → map về −1 (unknown)", "Không retry (lỗi dữ liệu, chạy lại cho kết quả như cũ)", "ORD-02/10, ITM-01/02/03, REV-01, BUN-01, INV-05…"),
    ("E3", "Trùng lặp (Uniqueness)", "Dòng trùng, khóa trùng, sự kiện lặp, crawl trùng", "silver",
     "Khử trùng tự động theo khóa + cột thứ tự (updated_at / modified_at / crawled_at); ghi số dòng bị loại vào ops.dq_results", "Không retry", "ORD-01, HIS-01, REV-04, CUS-03, INV-01, SNP-04, TRF-03, MKT-03"),
    ("E4", "Không nhất quán / lệch đối soát (Consistency / Accuracy)", "Thời gian phi logic, lệch tiền, lệch tồn, phễu vô lý", "silver, dq_silver, dq_gold",
     "Không xóa: gắn cờ is_*_anomaly và giữ nguyên giá trị gốc; sửa được thì tính lại (total_amount, discount_percent, diff_qty)", "Không retry", "ORD-03/06/09, ITM-06/07, PAY-02, HIS-02, SNP-01, PO-01/02, TRF-01, MKT-02, XR-01…XR-11"),
    ("E5", "Chuẩn hóa (Consistency nhẹ)", "Viết hoa/thường, khoảng trắng, đồng nghĩa màu, tên thuộc tính", "silver",
     "Tự chuẩn hóa bằng TRIM/UPPER/LOWER + bảng từ điển; giá trị không có trong từ điển → cảnh báo Low để bổ sung", "Không retry", "ITM-05, CUS-01, PRD-02/06, ATT-01, ORD-04"),
    ("E6", "PII / bảo mật", "SĐT, email, liên hệ trong nội dung đánh giá", "silver (trước khi ghi)",
     "Che bằng regex; nếu còn sót ở Silver/Gold (kiểm tra lại) → Critical: chặn publish", "Không retry", "REV-02"),
    ("E7", "Hạ tầng / thực thi", "Spark OOM, Trino timeout, MinIO/Catalog không phản hồi, xung đột commit Iceberg", "mọi task",
     "Retry tự động; Iceberg commit conflict → retry với backoff; quá số lần → FAILED + alert High; run sau bị chặn bởi depends_on_past", "retries 2 (task), 4 cho commit conflict, backoff lũy thừa", "-"),
    ("E8", "Cổng chất lượng (DQ gate)", "Tỷ lệ lỗi vượt ngưỡng ở cột/bảng Critical/High", "dq_silver.dq_gate, dq_gold",
     "Critical vượt ngưỡng → skip gold/publish, Power BI giữ số liệu ngày trước; High → vẫn publish nhưng gắn cảnh báo trên dashboard", "Không retry; chạy lại sau khi sửa", "theo DQ thresholds"),
    ("E9", "Trễ SLA", "Gold chưa sẵn sàng trước 06:00", "vnb_daily_batch (sla 4h)", "sla_miss_callback: alert High, ghi ops.pipeline_run_log", "-", "XR-13"),
]
cdf2 = pd.DataFrame(classes, columns=["class_id", "error_class", "examples", "detected_at", "action", "retry_policy", "issue_refs"])
stage_of = {"orders": "silver_orders", "order_items": "silver_order_items", "order_payments": "silver_order_payments", "order_status_history": "silver_order_status_history",
            "order_reviews": "silver_order_reviews", "customers": "silver_customers", "products": "silver_master", "product_attributes": "silver_master",
            "product_bundles": "silver_master", "listings": "silver_master", "inventory_movements": "silver_inventory_movements",
            "inventory_snapshots_daily": "silver_inventory_snapshots_daily", "purchase_orders": "silver_purchase_orders", "stock_counts": "silver_stock_counts",
            "listing_traffic_daily": "silver_listing_traffic_daily", "ads_spend_daily": "silver_ads_spend_daily", "market_prices": "silver_market_prices"}
cls_of = {"Uniqueness": "E3", "Validity": "E2", "Integrity": "E2", "Completeness": "E2", "Consistency": "E4", "Accuracy": "E4", "Timeliness": "E4", "Privacy": "E6"}
std = {"ITM-05", "CUS-01", "PRD-02", "PRD-06", "ATT-01", "ORD-04"}
act_of = {"E2": "quarantine / map −1", "E3": "dedup", "E4": "flag (+ tính lại nếu được)", "E5": "chuẩn hóa", "E6": "che PII; còn sót → chặn publish"}
alert = {"Critical": "email + chat ngay; chặn publish", "High": "email + chat ngay", "Medium": "daily digest", "Low": "weekly digest"}
sla = {"Critical": "4 giờ", "High": "1 ngày", "Medium": "3 ngày", "Low": "1 tuần"}
rows = []
for r in I.CATALOG:
    c = "E5" if r[0] in std else cls_of[r[4]]
    rows.append(dict(issue_id=r[0], dataset=r[1], column=r[2], issue_type=r[3], severity=r[5], error_class=c, detected_by=f"vnb_daily_batch.silver.{stage_of.get(r[1], 'silver')} + dq_silver.dq_field_rules",
                     action=act_of[c], handling_detail=r[10], destination=("silver_quarantine." + r[1]) if c == "E2" else "silver (cờ) + ops.dq_results",
                     alert=alert[r[5]], fix_sla=sla[r[5]], owner=S.DATASETS[r[1]][9]))
for f in FILE_ISSUES:
    rows.append(dict(issue_id=f[0], dataset=f[1], column="file", issue_type=f[2], severity=f[4], error_class="E1", detected_by=f[5], action=f[6],
                     handling_detail=f[6], destination="landing/_quarantine hoặc bronze._corrupt", alert=alert[f[4]], fix_sla=sla[f[4]], owner="Data Engineering"))
idf = pd.DataFrame(rows)
retry = pd.DataFrame([
    ("S3KeySensor (_SUCCESS)", "reschedule", "poke 10m", "timeout 6h", "FAILED + alert High"),
    ("check_manifest", "python", "retries 1", "5m", "branch → quarantine_batch"),
    ("Spark bronze/silver", "spark_submit", "retries 2, backoff 5m→10m", "45m", "FAILED + alert High"),
    ("Iceberg commit conflict", "trong job Spark", "retries 4, backoff 2s→16s", "-", "ném lỗi → retry task"),
    ("Trino gold SQL", "trino_sql", "retries 2, backoff 5m", "30m", "FAILED + alert High"),
    ("DQ checks", "python", "retries 1", "20m", "lỗi kỹ thuật → FAILED; lỗi dữ liệu → ghi dq_results, không fail task"),
    ("Toàn DAG", "vnb_daily_batch", "depends_on_past = true", "sla 4h", "ngày sau chờ ngày trước thành công"),
], columns=["component", "type", "retry", "timeout", "when_exhausted"])
runbook = pd.DataFrame([
    ("1", "Nhận cảnh báo", "Xem ops.dq_results / Airflow log theo run_id; xác định class E1–E9"),
    ("2", "Lỗi file (E1)", "Kiểm tra landing/_quarantine/dt=…; liên hệ nguồn gửi lại; đặt lại file vào landing/daily/dt=…; Clear task check_manifest"),
    ("3", "Lỗi dữ liệu (E2–E5)", "Xem silver_quarantine.<dataset> theo issue_id; sửa luật/bảng từ điển nếu là lỗi chuẩn hóa; nạp lại dt bằng vnb_backfill"),
    ("4", "PII (E6)", "Chặn quyền đọc bảng liên quan; cập nhật regex; chạy lại silver_order_reviews + gold.fct_review; xác nhận 0 bản ghi PII"),
    ("5", "Hạ tầng (E7)", "Kiểm tra docker compose ps / RAM; khởi động lại service; Clear task lỗi (job idempotent nên chạy lại an toàn)"),
    ("6", "Đóng sự cố", "Ghi nguyên nhân + cách sửa vào ops.pipeline_run_log (note); cập nhật danh mục lỗi nếu là loại mới"),
], columns=["step", "situation", "action"])
wb = Workbook(); ws = wb.active; ws.title = "README"
ws["A1"] = "Error Handling Policy — VN Beauty Lakehouse (batch)"; ws["A1"].font = Font(name="Arial", size=14, bold=True)
for i, n in enumerate([
        "Nguyên tắc: (1) không nạp nửa vời — dt chỉ được publish khi đủ file; (2) mọi job idempotent theo dt nên chạy lại an toàn; (3) không xóa dữ liệu lỗi — quarantine hoặc gắn cờ; (4) lỗi dữ liệu không retry, lỗi hạ tầng mới retry; (5) lỗi Critical chặn publish Gold.",
        "Sheet Error classes: 9 nhóm lỗi E1–E9 với điểm phát hiện, hành động, retry. Sheet Issue → action: từng mã lỗi (64 lỗi bản ghi + 9 lỗi file) được xử lý ở task nào, đi đâu, cảnh báo ai, SLA sửa.",
        "Sheet Retry & timeout: cấu hình retry từng thành phần (khớp pipeline_spec.yaml). Sheet Runbook: các bước xử lý khi có sự cố."], 3):
    ws.cell(row=i, column=1, value=n).font = BODY
ws.column_dimensions["A"].width = 160
write_table(wb.create_sheet("Error classes"), cdf2, wrap_cols=("examples", "action", "retry_policy", "issue_refs"), widths={"examples": 40, "action": 60, "retry_policy": 30, "issue_refs": 30})
ws2 = wb.create_sheet("Issue → action")
write_table(ws2, idf, wrap_cols=("handling_detail", "detected_by", "action"), widths={"handling_detail": 45, "detected_by": 40, "action": 30})
sc = list(idf.columns).index("severity") + 1
for i in range(2, len(idf) + 2):
    c = ws2.cell(row=i, column=sc); c.font = Font(name="Arial", size=10, bold=True, color=SEV[c.value])
write_table(wb.create_sheet("Retry & timeout"), retry, wrap_cols=("when_exhausted",), widths={"when_exhausted": 50})
write_table(wb.create_sheet("Runbook"), runbook, wrap_cols=("action",), widths={"action": 100})
wb.save(os.path.join(OUT, "vn_beauty_error_handling_policy.xlsx"))
print("ok", len(tdf), len(edf), len(cdf), len(idf))
