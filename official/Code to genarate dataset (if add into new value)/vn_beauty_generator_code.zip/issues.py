"""Danh mục lỗi cố ý + hàm tiêm lỗi. Nguồn duy nhất cho file 'data issues catalog' và log tiêm lỗi."""
import numpy as np
import pandas as pd

KEYS = dict(orders=["order_id"], order_items=["order_product_id"], order_payments=["order_id", "payment_sequential"],
            order_status_history=["order_id", "status_code"], order_reviews=["comment_id"], customers=["customer_id"], products=["product_id"],
            product_attributes=["product_id", "attribute_name"], product_bundles=["combo_product_id", "component_product_id"],
            purchase_orders=["po_line_id"], inventory_movements=["bill_line_id"], inventory_snapshots_daily=["snapshot_date", "depot_id", "product_id"],
            stock_counts=["inventory_check_id", "depot_id", "product_id"], listings=["listing_id"],
            listing_traffic_daily=["stat_date", "shop_code", "item_id"], ads_spend_daily=["stat_date", "shop_code", "campaign_id"],
            market_prices=["snapshot_date", "market_item_id"])

# issue_id, dataset, column, issue_type, dq_dimension, severity, rate, description, example, detection_rule, handling
CATALOG = [
    ("ORD-01", "orders", "*", "Bản ghi trùng hoàn toàn", "Uniqueness", "High", 0.003, "Đơn bị ghi 2 lần do extractor chạy lại cùng cửa sổ thời gian", "2 dòng giống hệt order_id=1012345", "COUNT(*) > 1 GROUP BY order_id", "Khử trùng theo order_id, giữ bản updated_at mới nhất"),
    ("ORD-02", "orders", "status_code", "Mã ngoài danh mục", "Validity", "Medium", 0.002, "Mã trạng thái 0 / 43 / 57 không có trong order_status (mã mới của hệ thống chưa map)", "status_code = 43", "status_code NOT IN (SELECT status_code FROM order_status)", "Map về -1 'Không xác định', cảnh báo để bổ sung danh mục"),
    ("ORD-03", "orders", "delivered_at", "Thời gian phi logic", "Consistency", "High", 0.001, "delivered_at sớm hơn created_at (lỗi đồng bộ giờ từ hãng vận chuyển)", "created 2024-11-11 10:00, delivered 2024-11-10 09:00", "delivered_at < created_at", "Đặt NULL + gắn cờ is_time_anomaly"),
    ("ORD-04", "orders", "province_name_raw", "Thiếu giá trị / giá trị rỗng giả", "Completeness", "Low", 0.005, "Tên tỉnh rỗng, 'null', 'N/A' hoặc chỉ khoảng trắng", "'N/A'", "TRIM(province_name_raw) IN ('', 'null', 'N/A')", "Lấy theo province_code; nếu cả hai thiếu → 'Không xác định'"),
    ("ORD-05", "orders", "created_at", "Sai định dạng / lệch múi giờ", "Consistency", "High", 0.012, "Một phần bản ghi lưu ISO-8601 UTC ('2024-05-01T03:15:00Z') hoặc 'dd/MM/yyyy HH:mm' thay vì giờ VN 'yyyy-MM-dd HH:mm:ss'", "'01/05/2024 10:15'", "Không khớp regex ^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$", "Parse đa định dạng, quy đổi UTC → Asia/Ho_Chi_Minh"),
    ("ORD-06", "orders", "business_payment_amount", "Lệch đối soát", "Accuracy", "High", 0.004, "Tiền khách trả ≠ Σ total_amount dòng − order_discount_amount + customer_ship_fee_amount", "Lệch 10.000đ", "ABS(bpa - (Σ lines - discount + ship)) > 0", "Gắn cờ is_amount_mismatch, không tự sửa"),
    ("ORD-07", "orders", "ship_fee_amount", "Giá trị âm", "Validity", "Medium", 0.001, "Phí vận chuyển âm do nhập hoàn phí sai dấu", "-25000", "ship_fee_amount < 0", "ABS() nếu nằm trong khoảng hợp lý, ngược lại NULL"),
    ("ORD-08", "orders", "carrier_id", "Thiếu khóa ngoại bắt buộc", "Completeness", "Medium", 0.005, "Đơn đã giao/đang giao nhưng không có hãng vận chuyển", "status 60, carrier_id NULL", "status_code IN (59,60,71,72,74) AND carrier_id IS NULL", "Map về carrier 'Không xác định' (-1)"),
    ("ORD-09", "orders", "order_date", "Không nhất quán dẫn xuất", "Consistency", "Medium", 0.003, "order_date lệch 1 ngày so với DATE(created_at) (tính theo UTC thay vì giờ VN)", "created 2024-11-11 06:30, order_date 2024-11-10", "order_date <> DATE(created_at)", "Tính lại order_date từ created_at giờ VN"),
    ("ORD-10", "orders", "created_at", "Ngày tương lai", "Validity", "High", 0.0002, "Ngày tạo nằm sau ngày chốt dữ liệu (2026-09-30) do sai đồng hồ máy POS", "2027-01-05 10:00:00", "created_at > snapshot_date của dataset", "Loại khỏi fact, đưa vào bảng quarantine"),
    ("ITM-01", "order_items", "order_id", "Bản ghi mồ côi", "Integrity", "High", 0.001, "Dòng hàng có order_id không tồn tại trong orders (đơn bị xóa ở nguồn)", "order_id 1999999", "LEFT JOIN orders IS NULL", "Quarantine; không đưa vào fact"),
    ("ITM-02", "order_items", "product_id", "Khóa ngoại không tồn tại", "Integrity", "High", 0.001, "SKU đã bị xóa khỏi danh mục", "product_id 39999", "product_id NOT IN products", "Map về product_key = -1 (unknown)"),
    ("ITM-03", "order_items", "quantity", "Giá trị ngoài miền", "Validity", "High", 0.001, "Số lượng 0 hoặc âm", "quantity = 0", "quantity <= 0", "Loại dòng khỏi fact, ghi log"),
    ("ITM-04", "order_items", "avg_cost", "Giá vốn bất thường", "Accuracy", "Medium", 0.005, "Giá vốn = 0 hoặc rỗng (SKU mới chưa có phiếu nhập)", "avg_cost = 0", "avg_cost IS NULL OR avg_cost <= 0 OR avg_cost > unit_price * 3", "Lấy import_price của products; gắn is_cost_anomaly"),
    ("ITM-05", "order_items", "product_code", "Sai chuẩn hóa chuỗi", "Consistency", "Low", 0.005, "product_code viết thường / có khoảng trắng thừa so với products.product_code", "' mtn-gn-01 '", "product_code <> UPPER(TRIM(product_code))", "UPPER(TRIM()) trước khi join; ưu tiên join bằng product_id"),
    ("ITM-06", "order_items", "unit_price", "Không nhất quán giá", "Consistency", "Medium", 0.002, "Giá bán lớn hơn giá niêm yết", "unit_price 59000 > original_price 49000", "unit_price > original_price", "Gắn cờ; giữ nguyên để kiểm tra lại cấu hình giá"),
    ("ITM-07", "order_items", "total_amount", "Lệch phép tính", "Accuracy", "Medium", 0.002, "total_amount ≠ quantity × unit_price − line_discount_amount", "2 × 49000 − 0 = 98000 nhưng total 95000", "total_amount <> quantity*unit_price - line_discount_amount", "Tính lại, ghi log chênh lệch"),
    ("PAY-01", "order_payments", "payment_type", "Mã ngoài danh mục", "Validity", "Low", 0.001, "payment_type = 'not_defined' (giống Olist)", "'not_defined'", "payment_type NOT IN danh mục", "Map 'unknown'"),
    ("PAY-02", "order_payments", "payment_amount", "Lệch đối soát", "Accuracy", "High", 0.003, "Σ payment (trừ platform_voucher) ≠ orders.business_payment_amount", "Thiếu dòng COD", "Đối soát theo order_id", "Gắn cờ, đối soát thủ công"),
    ("PAY-03", "order_payments", "payment_amount", "Giá trị âm / bằng 0", "Validity", "Medium", 0.001, "Số tiền thanh toán ≤ 0", "0", "payment_amount <= 0", "Loại khỏi tổng hợp doanh thu"),
    ("HIS-01", "order_status_history", "*", "Sự kiện trùng", "Uniqueness", "Low", 0.005, "Cùng order_id + status_code + changed_at xuất hiện 2 lần (webhook gửi lặp)", "2 dòng 59 giống nhau", "COUNT(*) > 1 GROUP BY order_id, status_code, changed_at", "Khử trùng"),
    ("HIS-02", "order_status_history", "changed_at", "Sai thứ tự thời gian", "Consistency", "Medium", 0.002, "Trạng thái sau có thời gian sớm hơn trạng thái trước (sự kiện đến muộn)", "60 lúc 10:00, 59 lúc 11:00", "changed_at giảm khi sắp theo thứ tự chuẩn của luồng trạng thái", "Sắp theo thứ tự nghiệp vụ, dùng ingest_time làm phụ"),
    ("HIS-03", "order_status_history", "order_id", "Thiếu lịch sử", "Completeness", "Medium", 0.002, "Đơn có trong orders nhưng không có dòng lịch sử nào", "-", "orders LEFT JOIN history IS NULL", "Dựng lại tối thiểu từ created_at/packed_at/delivered_at"),
    ("REV-01", "order_reviews", "rating_star", "Giá trị ngoài miền", "Validity", "Medium", 0.001, "Số sao 0 hoặc 6", "6", "rating_star NOT BETWEEN 1 AND 5", "Loại khỏi tính điểm trung bình"),
    ("REV-02", "order_reviews", "comment_text", "Chứa dữ liệu cá nhân (PII)", "Privacy", "Critical", 0.005, "Bình luận chứa số điện thoại / email / zalo (số hư cấu)", "'... liên hệ 0912 345 678'", "Regex SĐT VN (0|\\+84)\\d{9} hoặc email", "Che (mask) trước khi vào Silver; không lưu bản gốc ở Gold"),
    ("REV-03", "order_reviews", "created_at", "Thời gian phi logic", "Consistency", "Medium", 0.002, "Đánh giá tạo trước khi đơn được giao", "review trước delivered_at", "created_at < orders.delivered_at", "Gắn cờ is_time_anomaly"),
    ("REV-04", "order_reviews", "comment_id", "Khóa chính trùng", "Uniqueness", "High", 0.002, "Cùng comment_id nhưng nội dung khác (đã sửa đánh giá)", "-", "COUNT(*) > 1 GROUP BY comment_id", "Giữ bản modified_at mới nhất"),
    ("REV-05", "order_reviews", "order_id", "Thiếu khóa nối", "Completeness", "Medium", 0.01, "order_id rỗng, chỉ còn marketplace_order_sn", "-", "order_id IS NULL", "Nối lại qua marketplace_order_sn"),
    ("CUS-01", "customers", "customer_unique_id", "Sai chuẩn hóa chuỗi", "Consistency", "Medium", 0.003, "customer_unique_id viết hoa / có khoảng trắng → tách thành 2 khách", "'AB12… '", "customer_unique_id <> LOWER(TRIM())", "LOWER(TRIM()) trước khi đếm khách"),
    ("CUS-02", "customers", "customer_province_code", "Thiếu / sai mã", "Completeness", "Low", 0.005, "Mã tỉnh rỗng hoặc '99' không tồn tại", "'99'", "NOT IN geolocation", "Suy ra từ customer_province_name_raw"),
    ("CUS-03", "customers", "*", "Bản ghi trùng", "Uniqueness", "Low", 0.002, "Dòng khách bị lặp", "-", "COUNT(*) > 1 GROUP BY customer_id", "Khử trùng"),
    ("PRD-01", "products", "product_code", "SKU trùng do chuẩn hóa", "Uniqueness", "High", 2, "Thêm bản ghi SKU viết thường/có khoảng trắng với product_id mới (tạo trùng khi nhập lại danh mục)", "'mtn-gn-01 '", "COUNT(*) > 1 GROUP BY UPPER(TRIM(product_code))", "Gộp về product_id gốc, lập bảng mapping"),
    ("PRD-02", "products", "attr_color", "Giá trị không chuẩn hóa", "Consistency", "Medium", 0.15, "Cùng màu nhưng viết khác: 'trắng', 'White', 'Trang', 'Hong phan'", "'White'", "Giá trị không thuộc từ điển màu chuẩn", "Chuẩn hóa bằng bảng từ điển màu"),
    ("PRD-03", "products", "category_id", "Thiếu giá trị", "Completeness", "Medium", 2, "SKU không có danh mục", "NULL", "category_id IS NULL", "Gán theo parent_code; nếu không có → 'Chưa phân loại'"),
    ("PRD-04", "products", "retail_price", "Không nhất quán giá", "Accuracy", "High", 1, "Giá bán lẻ thấp hơn giá nhập", "retail 25000 < import 30000", "retail_price < import_price", "Cảnh báo cho phòng kinh doanh"),
    ("PRD-05", "products", "weight_gram", "Giá trị 0", "Validity", "Low", 2, "Khối lượng 0 gram", "0", "weight_gram <= 0", "Lấy trung vị theo parent_code"),
    ("PRD-06", "products", "product_name", "Ký tự thừa", "Consistency", "Low", 0.05, "Tên có khoảng trắng kép, emoji, ký tự đặc biệt", "'Mút  tán nền ✨'", "Regex ký tự không thuộc chữ/số/dấu câu", "Làm sạch chuỗi"),
    ("BUN-01", "product_bundles", "component_product_id", "Khóa ngoại không tồn tại", "Integrity", "High", 1, "Thành phần combo trỏ tới SKU không có", "39998", "NOT IN products", "Loại thành phần, cảnh báo"),
    ("BUN-02", "product_bundles", "component_qty", "Giá trị ngoài miền", "Validity", "Medium", 1, "Số lượng thành phần = 0", "0", "component_qty <= 0", "Cảnh báo, mặc định 1"),
    ("ATT-01", "product_attributes", "attribute_name", "Không chuẩn hóa tên thuộc tính", "Consistency", "Low", 0.03, "'Color', 'MÀU', ' color' thay vì 'color'", "'Color'", "attribute_name NOT IN ('color','material','shape','size','pack_qty')", "LOWER(TRIM()) + bảng ánh xạ"),
    ("INV-01", "inventory_movements", "bill_line_id", "Khóa chính trùng", "Uniqueness", "High", 0.0005, "Dòng phiếu kho bị nạp 2 lần", "-", "COUNT(*) > 1 GROUP BY bill_line_id", "Khử trùng"),
    ("INV-02", "inventory_movements", "quantity", "Sai dấu", "Validity", "High", 0.001, "quantity âm (hướng nhập/xuất đã nằm ở bill_type)", "-5", "quantity <= 0", "ABS(quantity), hướng lấy từ movement_types.direction"),
    ("INV-03", "inventory_movements", "related_depot_id", "Thiếu giá trị bắt buộc", "Completeness", "Medium", 0.01, "Phiếu chuyển kho không có kho đối ứng", "bill_mode 3, related NULL", "bill_mode = 3 AND related_depot_id IS NULL", "Suy ra từ bill_id cặp xuất/nhập"),
    ("INV-04", "inventory_movements", "movement_date", "Ghi lùi ngày", "Timeliness", "Medium", 0.002, "movement_date sớm hơn DATE(created_at) > 3 ngày (nhập liệu bù)", "movement 2024-03-01, created 2024-03-10", "DATE(created_at) - movement_date > 3", "Giữ movement_date cho tồn kho, gắn cờ is_backdated"),
    ("INV-05", "inventory_movements", "product_id", "Khóa ngoại không tồn tại", "Integrity", "High", 0.0005, "SKU không có trong products", "39997", "NOT IN products", "Quarantine"),
    ("SNP-01", "inventory_snapshots_daily", "available_qty", "Không nhất quán", "Consistency", "High", 0.001, "available_qty > on_hand_qty", "on_hand 10, available 15", "available_qty > on_hand_qty", "available = on_hand - holding"),
    ("SNP-02", "inventory_snapshots_daily", "on_hand_qty", "Giá trị âm", "Validity", "High", 0.0005, "Tồn âm do xuất trước khi phiếu nhập được ghi", "-3", "on_hand_qty < 0", "Gắn cờ is_negative_stock; tái dựng từ movements"),
    ("SNP-03", "inventory_snapshots_daily", "snapshot_date", "Thiếu ngày", "Completeness", "Medium", 3, "Mất toàn bộ snapshot của vài ngày (job snapshot lỗi)", "Không có ngày 2024-07-14", "Lịch ngày liên tục LEFT JOIN snapshot IS NULL", "Tái dựng từ movements hoặc forward-fill có gắn cờ"),
    ("SNP-04", "inventory_snapshots_daily", "*", "Bản ghi trùng", "Uniqueness", "Medium", 0.0005, "Trùng (snapshot_date, depot_id, product_id)", "-", "COUNT(*) > 1 GROUP BY khóa", "Khử trùng"),
    ("PO-01", "purchase_orders", "received_qty", "Vượt số lượng đặt", "Validity", "Medium", 0.01, "Nhận nhiều hơn số đặt", "order 100, received 130", "received_qty > order_qty * 1.1", "Cảnh báo mua hàng"),
    ("PO-02", "purchase_orders", "received_date", "Thời gian phi logic", "Consistency", "Medium", 0.005, "Ngày nhận trước ngày đặt", "-", "received_date < order_date", "Gắn cờ, loại khỏi tính lead time"),
    ("PO-03", "purchase_orders", "received_date", "Thiếu giá trị", "Completeness", "Medium", 0.005, "po_status = 'received' nhưng received_date rỗng", "-", "po_status='received' AND received_date IS NULL", "Lấy từ phiếu nhập tương ứng (po_id)"),
    ("CNT-01", "stock_counts", "diff_qty", "Lệch phép tính", "Accuracy", "Low", 0.01, "diff_qty ≠ counted_qty − system_qty", "-", "diff_qty <> counted_qty - system_qty", "Tính lại"),
    ("LST-01", "listings", "product_id", "Mapping mơ hồ", "Integrity", "Medium", 1, "Một (shop, item_id, model_id) map tới 2 SKU khác nhau", "-", "COUNT(DISTINCT product_id) > 1 GROUP BY shop, item, model", "Chọn bản ghi mới nhất; cảnh báo vận hành sàn"),
    ("TRF-01", "listing_traffic_daily", "clicks", "Không nhất quán phễu", "Consistency", "Low", 0.001, "clicks > impressions", "-", "clicks > impressions", "Gắn cờ; loại khỏi tính CTR"),
    ("TRF-02", "listing_traffic_daily", "stat_date", "Thiếu ngày", "Completeness", "Low", 0.002, "Mất dòng ngày của một số item (API sàn lỗi)", "-", "Lịch ngày × item LEFT JOIN IS NULL", "Để trống, không nội suy"),
    ("TRF-03", "listing_traffic_daily", "*", "Bản ghi trùng", "Uniqueness", "Low", 0.0005, "Trùng (stat_date, shop_code, item_id)", "-", "COUNT(*) > 1", "Khử trùng"),
    ("ADS-01", "ads_spend_daily", "spend_amount", "Giá trị âm", "Validity", "Medium", 0.0005, "Chi phí âm (hoàn tiền quảng cáo ghi sai)", "-120000", "spend_amount < 0", "Tách thành dòng refund"),
    ("ADS-02", "ads_spend_daily", "clicks", "Không nhất quán phễu", "Consistency", "Low", 0.001, "clicks > impressions", "-", "clicks > impressions", "Gắn cờ"),
    ("MKT-01", "market_prices", "price", "Sai kiểu dữ liệu", "Validity", "Medium", 0.01, "Giá dạng chuỗi có định dạng VN: '189.000đ'", "'189.000đ'", "price không phải số", "Bỏ ký tự, đổi về số nguyên"),
    ("MKT-02", "market_prices", "discount_percent", "Lệch phép tính", "Accuracy", "Low", 0.02, "discount_percent ≠ ROUND((1 - price/market_price) × 100)", "-", "ABS(diff) > 2", "Tính lại từ price và market_price"),
    ("MKT-03", "market_prices", "*", "Bản ghi trùng", "Uniqueness", "Low", 0.005, "Crawler chạy 2 lần cùng ngày", "-", "COUNT(*) > 1 GROUP BY snapshot_date, market_item_id", "Giữ crawled_at mới nhất"),
    ("MKT-04", "market_prices", "stock_qty", "Thiếu giá trị", "Completeness", "Low", 0.02, "Không lấy được tồn kho (trang đổi giao diện)", "NULL", "stock_qty IS NULL", "Để trống"),
    ("MKT-05", "market_prices", "rating_avg", "Giá trị ngoài miền", "Validity", "Low", 0.001, "Điểm đánh giá > 5 do parse nhầm số lượt", "48.0", "rating_avg NOT BETWEEN 0 AND 5", "Đặt NULL"),
]
COLS = ["issue_id", "dataset", "column", "issue_type", "dq_dimension", "severity", "rate", "description", "example", "detection_rule", "suggested_handling"]


def inject(T, rng, random):
    log = []
    pick = lambda df, rate: (rng.choice(df.index.to_numpy(), size=max(1, int(len(df) * rate) if rate < 1 else int(rate)), replace=False)
                             if len(df) else np.array([], int))

    def key(ds, df, i):
        return "|".join(str(df.at[i, k]) for k in KEYS.get(ds, [df.columns[0]]))

    def setv(iid, ds, df, idx, col, fn):
        for i in idx:
            old = df.at[i, col]
            new = fn(i, old)
            if df[col].dtype != object and not isinstance(new, (int, float, np.integer, np.floating)) or new is None:
                df[col] = df[col].astype(object)
            df.at[i, col] = new
            log.append((iid, ds, key(ds, df, i), col, old, new))

    def dup(iid, ds, rate):
        df = T[ds]
        idx = pick(df, rate)
        for i in idx:
            log.append((iid, ds, key(ds, df, i), "*", None, "duplicated"))
        T[ds] = pd.concat([df, df.loc[idx]], ignore_index=True)

    o, it, pay, his, rev, cus, pr = (T[k] for k in ("orders", "order_items", "order_payments", "order_status_history", "order_reviews", "customers", "products"))
    # ---------------- orders
    setv("ORD-02", "orders", o, pick(o, .002), "status_code", lambda i, v: int(rng.choice([0, 43, 57])))
    d = o[o.delivered_at.notna()]
    setv("ORD-03", "orders", o, pick(d, .001), "delivered_at",
         lambda i, v: (pd.Timestamp(o.at[i, "created_at"]) - pd.Timedelta(hours=int(rng.integers(2, 48)))).strftime("%Y-%m-%d %H:%M:%S"))
    setv("ORD-04", "orders", o, pick(o, .005), "province_name_raw", lambda i, v: random.choice(["", "null", "N/A", "   "]))
    idx5 = pick(o, .012)

    def f5(i, v):
        t = pd.Timestamp(v)
        return (t - pd.Timedelta(hours=7)).strftime("%Y-%m-%dT%H:%M:%SZ") if rng.random() < .6 else t.strftime("%d/%m/%Y %H:%M")
    setv("ORD-05", "orders", o, idx5, "created_at", f5)
    setv("ORD-06", "orders", o, pick(o, .004), "business_payment_amount", lambda i, v: int(v) + int(rng.choice([-20000, -10000, 5000, 10000])))
    nz = o[o.ship_fee_amount > 0]
    setv("ORD-07", "orders", o, pick(nz, .01), "ship_fee_amount", lambda i, v: -int(v))
    d = o[o.status_code.isin([59, 60, 71, 72, 74]) & o.carrier_id.notna()]
    setv("ORD-08", "orders", o, pick(d, .005), "carrier_id", lambda i, v: None)
    setv("ORD-09", "orders", o, pick(o, .003), "order_date", lambda i, v: (pd.Timestamp(v) - pd.Timedelta(days=1)).date().isoformat())
    setv("ORD-10", "orders", o, pick(o, .0002), "created_at", lambda i, v: "2027-01-05 10:00:00")
    # ---------------- order_items
    idx = pick(it, .001)
    setv("ITM-01", "order_items", it, idx, "order_id", lambda i, v: 1_999_000 + int(rng.integers(0, 999)))
    setv("ITM-02", "order_items", it, pick(it, .001), "product_id", lambda i, v: 39999)
    setv("ITM-03", "order_items", it, pick(it, .001), "quantity", lambda i, v: int(rng.choice([0, -1])))
    setv("ITM-04", "order_items", it, pick(it, .005), "avg_cost", lambda i, v: random.choice([0, None]))
    setv("ITM-05", "order_items", it, pick(it, .005), "product_code", lambda i, v: random.choice([f" {v.lower()} ", v.lower(), f"{v} "]))
    setv("ITM-06", "order_items", it, pick(it, .002), "unit_price", lambda i, v: int(it.at[i, "original_price"]) + 10000)
    setv("ITM-07", "order_items", it, pick(it, .002), "total_amount", lambda i, v: int(v) - 3000)
    # ---------------- payments
    setv("PAY-01", "order_payments", pay, pick(pay, .001), "payment_type", lambda i, v: "not_defined")
    setv("PAY-02", "order_payments", pay, pick(pay, .003), "payment_amount", lambda i, v: int(v * .9))
    setv("PAY-03", "order_payments", pay, pick(pay, .001), "payment_amount", lambda i, v: 0)
    # ---------------- history
    idx = pick(his, .002)

    def f_h2(i, v):
        return (pd.Timestamp(v) - pd.Timedelta(hours=int(rng.integers(3, 30)))).strftime("%Y-%m-%d %H:%M:%S")
    his2 = his[his.status_code.isin([59, 60, 72])]
    setv("HIS-02", "order_status_history", his, pick(his2, .002), "changed_at", f_h2)
    miss = rng.choice(o.order_id.unique(), size=max(1, int(o.order_id.nunique() * .002)), replace=False)
    for m in miss:
        log.append(("HIS-03", "order_status_history", str(m), "order_id", None, "deleted"))
    T["order_status_history"] = his[~his.order_id.isin(miss)].reset_index(drop=True)
    dup("HIS-01", "order_status_history", .005)
    # ---------------- reviews
    if len(rev):
        setv("REV-01", "order_reviews", rev, pick(rev, .001), "rating_star", lambda i, v: int(rng.choice([0, 6])))
        phones = lambda: f"0{rng.choice([9, 3, 7, 8])}{rng.integers(10**7, 10**8 - 1)}"
        txt = rev[rev.comment_text.notna()]
        setv("REV-02", "order_reviews", rev, pick(txt, .005), "comment_text",
             lambda i, v: random.choice([f"{v}. Ai cần mua sỉ liên hệ {phones()} nha", f"{v} - zalo {phones()}",
                                         f"{v}. Mail mình: khachhang{rng.integers(100, 999)}@gmail.example"]))
        setv("REV-03", "order_reviews", rev, pick(rev, .002), "created_at",
             lambda i, v: (pd.Timestamp(v) - pd.Timedelta(days=int(rng.integers(8, 20)))).strftime("%Y-%m-%d %H:%M:%S"))
        setv("REV-05", "order_reviews", rev, pick(rev, .01), "order_id", lambda i, v: None)
        idx = pick(rev, .002)
        extra = rev.loc[idx].copy()
        extra["comment_text"] = [f"(đã sửa) {t}" if isinstance(t, str) else "(đã sửa)" for t in extra.comment_text]
        extra["modified_at"] = [(pd.Timestamp(t) + pd.Timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S") for t in extra.modified_at]
        for i in idx:
            log.append(("REV-04", "order_reviews", key("order_reviews", rev, i), "comment_id", None, "duplicated_edit"))
        T["order_reviews"] = pd.concat([rev, extra], ignore_index=True)
    # ---------------- customers
    setv("CUS-01", "customers", cus, pick(cus, .003), "customer_unique_id", lambda i, v: random.choice([v.upper(), f"{v} "]))
    setv("CUS-02", "customers", cus, pick(cus, .005), "customer_province_code", lambda i, v: random.choice([None, "99"]))
    dup("CUS-03", "customers", .002)
    # ---------------- products
    base = pr[pr.product_type_code == 1].sample(2, random_state=1)
    new = base.copy()
    new["product_id"] = [39001, 39002]
    new["product_code"] = [f"{c.lower()} " for c in base.product_code]
    for _, r in new.iterrows():
        log.append(("PRD-01", "products", str(r.product_id), "product_code", None, r.product_code))
    colored = pr[pr.attr_color.notna()]
    VAR = {"Trắng": ["trắng", "White", "Trang"], "Hồng phấn": ["Hong phan", "hồng phấn"], "Hồng": ["hong", "Pink"], "Đen": ["đen", "Black"],
           "Bạc": ["Silver", "bạc"], "Be": ["Beige", "be"], "Vàng hồng": ["Rose gold", "vàng hồng"]}
    setv("PRD-02", "products", pr, pick(colored, .15), "attr_color", lambda i, v: random.choice(VAR.get(v, [str(v).lower()])))
    setv("PRD-03", "products", pr, pick(pr, 2), "category_id", lambda i, v: None)
    cheap = pr[(pr.product_type_code == 1) & (pr.retail_price < 60000)]
    setv("PRD-04", "products", pr, pick(cheap, 1), "retail_price", lambda i, v: int(pr.at[i, "import_price"] * .8))
    setv("PRD-05", "products", pr, pick(pr, 2), "weight_gram", lambda i, v: 0)
    setv("PRD-06", "products", pr, pick(pr, .05), "product_name", lambda i, v: random.choice([v.replace(" ", "  ", 1), f"{v} ✨", f" {v}"]))
    T["products"] = pd.concat([pr, new], ignore_index=True)
    # ---------------- bundles, attributes
    b = T["product_bundles"]
    setv("BUN-01", "product_bundles", b, pick(b, 1), "component_product_id", lambda i, v: 39998)
    setv("BUN-02", "product_bundles", b, pick(b, 1), "component_qty", lambda i, v: 0)
    a = T["product_attributes"]
    setv("ATT-01", "product_attributes", a, pick(a[a.attribute_name == "color"], .03), "attribute_name", lambda i, v: random.choice(["Color", "MÀU", " color"]))
    # ---------------- inventory
    mv = T["inventory_movements"]
    setv("INV-02", "inventory_movements", mv, pick(mv, .001), "quantity", lambda i, v: -int(v))
    tr_ = mv[mv.bill_mode == 3]
    setv("INV-03", "inventory_movements", mv, pick(tr_, .01), "related_depot_id", lambda i, v: None)
    setv("INV-04", "inventory_movements", mv, pick(mv, .002), "movement_date",
         lambda i, v: (pd.Timestamp(v) - pd.Timedelta(days=int(rng.integers(4, 12)))).date().isoformat())
    setv("INV-05", "inventory_movements", mv, pick(mv, .0005), "product_id", lambda i, v: 39997)
    dup("INV-01", "inventory_movements", .0005)
    sn = T["inventory_snapshots_daily"]
    setv("SNP-01", "inventory_snapshots_daily", sn, pick(sn, .001), "available_qty", lambda i, v: int(sn.at[i, "on_hand_qty"]) + int(rng.integers(3, 20)))
    setv("SNP-02", "inventory_snapshots_daily", sn, pick(sn, .0005), "on_hand_qty", lambda i, v: -int(rng.integers(1, 6)))
    dates = rng.choice(sn.snapshot_date.unique(), size=3, replace=False)
    for dd in dates:
        log.append(("SNP-03", "inventory_snapshots_daily", str(dd), "snapshot_date", None, "deleted_day"))
    T["inventory_snapshots_daily"] = sn[~sn.snapshot_date.isin(dates)].reset_index(drop=True)
    dup("SNP-04", "inventory_snapshots_daily", .0005)
    po = T["purchase_orders"]
    rec = po[po.received_qty.notna()]
    setv("PO-01", "purchase_orders", po, pick(rec, .01), "received_qty", lambda i, v: int(po.at[i, "order_qty"] * 1.3))
    setv("PO-02", "purchase_orders", po, pick(rec, .005), "received_date",
         lambda i, v: (pd.Timestamp(po.at[i, "order_date"]) - pd.Timedelta(days=3)).date().isoformat())
    setv("PO-03", "purchase_orders", po, pick(rec, .005), "received_date", lambda i, v: None)
    sc = T["stock_counts"]
    if len(sc):
        setv("CNT-01", "stock_counts", sc, pick(sc, .01), "diff_qty", lambda i, v: int(v) + 2)
    ls = T["listings"]
    i0 = pick(ls[ls.model_id > 0], 1)[0]
    extra = ls.loc[[i0]].copy()
    other = int(T["products"][T["products"].product_type_code == 1].product_id.sample(1, random_state=3).iloc[0])
    extra["product_id"] = other
    extra["listing_id"] = extra.listing_id + "-dup"
    log.append(("LST-01", "listings", str(extra.listing_id.iloc[0]), "product_id", int(ls.at[i0, "product_id"]), other))
    T["listings"] = pd.concat([ls, extra], ignore_index=True)
    tf = T["listing_traffic_daily"]
    setv("TRF-01", "listing_traffic_daily", tf, pick(tf, .001), "clicks", lambda i, v: int(tf.at[i, "impressions"]) + int(rng.integers(1, 50)))
    drop = pick(tf, .002)
    for i in drop:
        log.append(("TRF-02", "listing_traffic_daily", key("listing_traffic_daily", tf, i), "stat_date", None, "deleted"))
    T["listing_traffic_daily"] = tf.drop(index=drop).reset_index(drop=True)
    dup("TRF-03", "listing_traffic_daily", .0005)
    ad = T["ads_spend_daily"]
    setv("ADS-01", "ads_spend_daily", ad, pick(ad, .0005), "spend_amount", lambda i, v: -abs(int(v)) or -120000)
    setv("ADS-02", "ads_spend_daily", ad, pick(ad, .001), "clicks", lambda i, v: int(ad.at[i, "impressions"]) + 10)
    mk = T["market_prices"]
    setv("MKT-01", "market_prices", mk, pick(mk, .01), "price", lambda i, v: f"{int(v):,}đ".replace(",", "."))
    setv("MKT-02", "market_prices", mk, pick(mk, .02), "discount_percent", lambda i, v: int(v) + int(rng.choice([-10, 7, 15])))
    setv("MKT-04", "market_prices", mk, pick(mk, .02), "stock_qty", lambda i, v: None)
    setv("MKT-05", "market_prices", mk, pick(mk, .001), "rating_avg", lambda i, v: float(v) * 10)
    dup("MKT-03", "market_prices", .005)
    dup("ORD-01", "orders", .003)
    # xáo trộn thứ tự dòng các bảng có dòng trùng để lỗi không nằm cuối file
    for ds in ("orders", "customers", "inventory_movements", "inventory_snapshots_daily", "order_status_history", "market_prices", "listing_traffic_daily"):
        df = T[ds]
        sort_cols = KEYS[ds][:1]
        T[ds] = df.sort_values(sort_cols, kind="stable").reset_index(drop=True)
    return log
