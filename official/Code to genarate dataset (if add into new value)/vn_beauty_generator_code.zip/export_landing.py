"""Chuyển bộ dữ liệu đầy đủ thành 'landing zone' mô phỏng extract batch hằng ngày.

landing/
  daily/dt=YYYY-MM-DD/<dataset>.csv  + _manifest.json + _SUCCESS     (dữ liệu phát sinh/cập nhật trong ngày dt, giờ VN)
  master/snapshot_date=2026-09-30/<dataset>.csv + _manifest.json      (danh mục: full snapshot)
Lỗi cấp file (FILE-xx) được tiêm và ghi vào landing_file_issues_log.csv.
"""
import hashlib, json, os, shutil, sys
from datetime import datetime, timedelta
import numpy as np
import pandas as pd

SRC, OUT = sys.argv[1], sys.argv[2]
PFX = "vn_beauty_"
rng = np.random.default_rng(11)
shutil.rmtree(OUT, ignore_errors=True)
rd = lambda k: pd.read_csv(os.path.join(SRC, f"{PFX}{k}_dataset.csv"), dtype=str, keep_default_na=False, low_memory=False)


def parse_ts(s):
    s = s.fillna("")
    out = pd.to_datetime(s, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    iso = pd.to_datetime(s.where(s.str.endswith("Z")), format="%Y-%m-%dT%H:%M:%SZ", errors="coerce") + pd.Timedelta(hours=7)
    dmy = pd.to_datetime(s.where(s.str.contains("/")), format="%d/%m/%Y %H:%M", errors="coerce")
    d = pd.to_datetime(s.where(s.str.len() == 10), format="%Y-%m-%d", errors="coerce")
    return out.fillna(iso).fillna(dmy).fillna(d)


END = pd.Timestamp("2026-09-30")
parts = {}   # dt -> {dataset: df}
def add(ds, df, dt_series):
    dts = dt_series.dt.date.astype(str)
    dts = dts.where(dt_series.notna() & (dt_series <= END + pd.Timedelta(days=1)), END.date().isoformat())  # ngày tương lai / lỗi → ngày chốt
    for dt, g in df.groupby(dts.values):
        parts.setdefault(dt, {}).setdefault(ds, []).append(g)

# ---------------- orders: phiên bản lúc tạo + phiên bản cuối (upsert ở Silver)
o = rd("orders"); h = rd("order_status_history")
o_ct = parse_ts(o.created_at); o_up = parse_ts(o.updated_at)
h["_t"] = parse_ts(h.changed_at)
h_first_day = h.merge(pd.DataFrame({"order_id": o.order_id, "_cd": o_ct.dt.date}).drop_duplicates("order_id"), on="order_id")
h_first_day = h_first_day[h_first_day._t.dt.date == h_first_day._cd].sort_values("_t").groupby("order_id").tail(1)
init_status = dict(zip(h_first_day.order_id, h_first_day.status_code))
multi = (o_up.dt.date != o_ct.dt.date) & o_ct.notna() & o_up.notna()
v1 = o[multi].copy()
v1["status_code"] = v1.order_id.map(init_status).fillna("54")
for c in ("packed_at", "delivered_at", "delivered_date"):
    v1[c] = ""
v1["updated_at"] = v1.created_at
v1["reason_code"] = np.where(v1.status_code.isin(["63", "64"]), v1.reason_code, "")
v1.loc[~v1.status_code.isin(["40", "59", "60"]), "carrier_id"] = ""
add("orders", v1, o_ct[multi])
add("orders", o, o_up.fillna(o_ct))
it = rd("order_items")
oc = dict(zip(o.order_id, o_ct))
it_t = pd.to_datetime(it.order_id.map(oc))
it_t = it_t.fillna(parse_ts(it.order_updated_at))
it2 = it.copy(); it2["order_updated_at"] = [x if pd.isna(t) else t.strftime("%Y-%m-%d %H:%M:%S") for x, t in zip(it.order_updated_at, it_t)]
add("order_items", it2, it_t)
pay = rd("order_payments"); add("order_payments", pay, pd.to_datetime(pay.order_id.map(oc)).fillna(END))
add("order_status_history", h.drop(columns="_t"), h._t)
cu = rd("customers")
first = pd.DataFrame({"customer_id": o.customer_id, "t": o_ct}).drop_duplicates("customer_id")
add("customers", cu, pd.to_datetime(cu.customer_id.map(dict(zip(first.customer_id, first.t)))).fillna(END))
rv = rd("order_reviews")
rv_t = parse_ts(rv.created_at)
edited = rv.duplicated("comment_id", keep="first")
add("order_reviews", rv[~edited], rv_t[~edited])
add("order_reviews", rv[edited], parse_ts(rv.modified_at)[edited])
mv = rd("inventory_movements"); add("inventory_movements", mv, parse_ts(mv.created_at))
sn = rd("inventory_snapshots_daily"); add("inventory_snapshots_daily", sn, parse_ts(sn.snapshot_date))
po = rd("purchase_orders")
po_open = po.copy(); po_open["po_status"] = "open"; po_open["received_date"] = ""; po_open["received_qty"] = ""
add("purchase_orders", po_open, parse_ts(po.order_date))
rec = po[po.received_date != ""]
add("purchase_orders", rec, parse_ts(rec.received_date).where(lambda x: x >= parse_ts(rec.order_date), parse_ts(rec.order_date) + pd.Timedelta(days=1)))
sc = rd("stock_counts"); add("stock_counts", sc, parse_ts(sc.count_date))
tf = rd("listing_traffic_daily"); add("listing_traffic_daily", tf, parse_ts(tf.stat_date))
ad = rd("ads_spend_daily"); add("ads_spend_daily", ad, parse_ts(ad.stat_date))
mk = rd("market_prices"); add("market_prices", mk, parse_ts(mk.snapshot_date))

MASTER = ["products", "product_attributes", "product_bundles", "categories", "brands", "channels_shops", "warehouses", "carriers", "suppliers",
          "geolocation", "inventory_policy", "listings", "events_calendar", "order_status", "movement_types", "order_reasons"]

# ---------------- ghi file
flog = []
def md5(path):
    return hashlib.md5(open(path, "rb").read()).hexdigest()


def write_dir(d, frames, dt, kind):
    os.makedirs(d, exist_ok=True)
    files = []
    for ds, df in frames.items():
        p = os.path.join(d, f"{ds}.csv")
        df.to_csv(p, index=False, encoding="utf-8")
        files.append(dict(dataset=ds, file=f"{ds}.csv", rows=len(df), bytes=os.path.getsize(p), md5=md5(p), schema_version="v1"))
    man = dict(batch_type=kind, dt=dt, source="oms_extract_sim", generated_at=(pd.Timestamp(dt) + pd.Timedelta(days=1, hours=1, minutes=30)).strftime("%Y-%m-%dT%H:%M:%S+07:00"), files=files)
    json.dump(man, open(os.path.join(d, "_manifest.json"), "w"), ensure_ascii=False, indent=1)
    open(os.path.join(d, "_SUCCESS"), "w").close()
    return man


dts = sorted(parts)
for dt in dts:
    frames = {ds: pd.concat(v) for ds, v in parts[dt].items()}
    write_dir(os.path.join(OUT, "daily", f"dt={dt}"), frames, dt, "daily_incremental")
m = {k: rd(k) for k in MASTER}
write_dir(os.path.join(OUT, "master", "snapshot_date=2026-09-30"), m, "2026-09-30", "master_full_snapshot")
# bản danh mục cũ để minh họa SCD / thay đổi giá
old = m["products"].copy()
old = old[parse_ts(old.created_at) <= pd.Timestamp("2023-12-31")]
old["retail_price"] = (old.retail_price.astype(float) / 1.05).round(-3).astype(int).astype(str)
old["product_status_code"] = "1"
write_dir(os.path.join(OUT, "master", "snapshot_date=2023-12-31"), {"products": old}, "2023-12-31", "master_full_snapshot")

# ---------------- lỗi cấp file
D = lambda dt: os.path.join(OUT, "daily", f"dt={dt}")
def lg(iid, dt, f, desc):
    flog.append(dict(issue_id=iid, dt=dt, file=f, description=desc))

# FILE-01 file đến muộn: orders ngày 2024-11-12 nằm ở thư mục ngày 2024-11-14
src = os.path.join(D("2024-11-12"), "orders.csv")
shutil.move(src, os.path.join(D("2024-11-14"), "orders__late_dt=2024-11-12.csv"))
lg("FILE-01", "2024-11-12", "orders.csv", "File đến muộn 2 ngày: nằm ở dt=2024-11-14 với tên orders__late_dt=2024-11-12.csv; manifest ngày 12 vẫn liệt kê file")
# FILE-02 file rỗng nhưng manifest báo có dòng
p = os.path.join(D("2023-03-08"), "order_items.csv")
hdr = open(p, encoding="utf-8").readline()
open(p, "w", encoding="utf-8").write(hdr)
lg("FILE-02", "2023-03-08", "order_items.csv", "File chỉ còn header (0 dòng) trong khi _manifest.json ghi rows > 0 → lệch số dòng & md5")
# FILE-03 schema drift: thêm cột voucher_code từ 2025-07-01, đổi thứ tự cột 1 ngày
for dt in [d for d in dts if d >= "2025-07-01"]:
    p = os.path.join(D(dt), "orders.csv")
    if os.path.exists(p):
        df = pd.read_csv(p, dtype=str, keep_default_na=False)
        df["voucher_code"] = np.where(df.order_discount_amount.replace("", "0").astype(float) > 0, "VB" + df.order_id.str[-4:], "")
        df.to_csv(p, index=False)
        man = json.load(open(os.path.join(D(dt), "_manifest.json")))
        for f in man["files"]:
            if f["dataset"] == "orders":
                f.update(schema_version="v2", bytes=os.path.getsize(p), md5=md5(p))
        json.dump(man, open(os.path.join(D(dt), "_manifest.json"), "w"), ensure_ascii=False, indent=1)
lg("FILE-03", "2025-07-01..", "orders.csv", "Schema evolution: từ 2025-07-01 orders có thêm cột voucher_code (schema_version v2 trong manifest)")
p = os.path.join(D("2025-03-15"), "customers.csv")
df = pd.read_csv(p, dtype=str, keep_default_na=False); df[df.columns[::-1]].to_csv(p, index=False)
lg("FILE-04", "2025-03-15", "customers.csv", "Thứ tự cột bị đảo ngược (header vẫn đúng tên) → phải đọc theo tên cột, không theo vị trí; md5 lệch manifest")
# FILE-05 dòng hỏng (thiếu dấu ngoặc kép)
p = os.path.join(D("2024-06-20"), "order_reviews.csv")
lines = open(p, encoding="utf-8").read().splitlines()
for k in (3, 7):
    if len(lines) > k:
        lines[k] = lines[k].replace('"', "") + ',"dòng bị cắt'
open(p, "w", encoding="utf-8").write("\n".join(lines) + "\n")
lg("FILE-05", "2024-06-20", "order_reviews.csv", "2 dòng CSV hỏng: mất dấu ngoặc kép, dư cột / ngoặc mở không đóng → dùng mode PERMISSIVE + _corrupt_record")
# FILE-06 giao trùng file
shutil.copy(os.path.join(D("2023-06-18"), "orders.csv"), os.path.join(D("2023-06-18"), "orders (1).csv"))
lg("FILE-06", "2023-06-18", "orders (1).csv", "Cùng một file được giao 2 lần với tên khác → phải chặn bằng md5 / idempotent theo dt")
# FILE-07 sai encoding
p = os.path.join(D("2022-10-20"), "customers.csv")
txt = open(p, encoding="utf-8").read()
open(p, "wb").write(txt.encode("cp1258", errors="replace"))
lg("FILE-07", "2022-10-20", "customers.csv", "File lưu bằng Windows-1258 thay vì UTF-8 → tên tỉnh tiếng Việt lỗi font khi đọc UTF-8")
# FILE-08 thiếu _SUCCESS (job extract chết giữa chừng), thiếu file inventory_snapshots
os.remove(os.path.join(D("2025-02-03"), "_SUCCESS"))
os.remove(os.path.join(D("2025-02-03"), "inventory_snapshots_daily.csv"))
lg("FILE-08", "2025-02-03", "_SUCCESS, inventory_snapshots_daily.csv", "Không có _SUCCESS và thiếu file snapshot → sensor phải chờ, hết timeout thì cảnh báo, không nạp nửa vời")
# FILE-09 không có manifest
os.remove(os.path.join(D("2026-01-09"), "_manifest.json"))
lg("FILE-09", "2026-01-09", "_manifest.json", "Thiếu manifest → không kiểm được số dòng / md5; xử lý theo chế độ 'degraded' có cảnh báo")
pd.DataFrame(flog).to_csv(os.path.join(OUT, "landing_file_issues_log.csv"), index=False, encoding="utf-8")
n_files = sum(len(fs) for _, _, fs in os.walk(OUT))
print("partitions", len(dts), "files", n_files)
